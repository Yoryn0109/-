param(
  [string]$Output = (Join-Path $PSScriptRoot "dist\PriceLens")
)

$ErrorActionPreference = "Stop"
$version = "45.1.0"
$arch = "win32-x64"
$url = "https://github.com/electron/electron/releases/download/v$version/electron-v$version-$arch.zip"
$tmp = Join-Path $env:TEMP "pricelens-electron-build"
$zip = Join-Path $tmp "electron.zip"
$extract = Join-Path $tmp "electron"

Write-Host "Downloading Electron $version..."
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
Invoke-WebRequest -Uri $url -OutFile $zip

Write-Host "Extracting..."
Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force

if (Test-Path $Output) { Remove-Item $Output -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Output | Out-Null
Copy-Item -Path (Join-Path $extract "*") -Destination $Output -Recurse -Force

$appDir = Join-Path $Output "resources\app"
if (Test-Path $appDir) { Remove-Item $appDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $appDir | Out-Null
Copy-Item -Path (Join-Path $PSScriptRoot "app\*") -Destination $appDir -Recurse -Force

$defaultApp = Join-Path $Output "resources\default_app.asar"
if (Test-Path $defaultApp) { Remove-Item $defaultApp -Force }

$exe = Join-Path $Output "electron.exe"
if (Test-Path $exe) {
  Rename-Item -LiteralPath $exe -NewName "价探.exe"
}

Write-Host ""
Write-Host "Build complete:"
Write-Host (Join-Path $Output "价探.exe")
Write-Host ""
Write-Host "If Windows warns about an unsigned app, choose the option to run it anyway."
