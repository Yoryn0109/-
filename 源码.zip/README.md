# 价探 PriceLens · Windows 桌面比价工具

基于 Electron 的 Windows 桌面比价程序，当前版本包含：

- 三平台同屏：京东 / 淘宝 / 拼多多；
- 默认后台加载三个网页，保留「显示三平台」开关；
- 比价搜索：先尝试点击评分/好评排序，再读取当前页；
- 综合性价比推荐：评分 45% + 销量/评价数 25% + 价格 20% + 官方/旗舰店 10%；
- 演示比价：读取本机数据库最近一次记录；
- 数据库：查看最近一次三平台真实商品和综合推荐；
- 数据保存在本机 Chromium localStorage，不依赖远程服务器。

## 为什么仓库里没有 exe

完整可运行包约 158 MB，其中 Electron 运行时（`electron.exe`）本身约 250 MB，压缩后仍然远超 GitHub 普通仓库的单文件限制。

所以本仓库只放**源码**，运行需要的 Electron 运行时由构建脚本下载。

## 构建

需要 Windows 和 PowerShell 5.1 以上，不需要 Node.js。

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

脚本会：

1. 从 GitHub 下载官方 Electron `45.1.0 win32-x64`；
2. 解压到 `dist\PriceLens`；
3. 用本仓库的 `app` 替换 `resources\app`；
4. 将 `electron.exe` 重命名为 `价探.exe`。

构建完成后运行：

```text
dist\PriceLens\价探.exe
```

## 目录

```text
app\
  main.js          Electron 主进程
  preload.js       预加载桥接
  package.json
  app\             界面源码
build.ps1          构建脚本
```

## 使用

1. 首次启动点「显示三平台」；
2. 在三个面板完成登录 / 京东验证 / 拼多多扫码；
3. 点「隐藏三平台」；
4. 输入关键词，点「比价搜索」；
5. 在「演示比价」和「数据库」查看结果。

## 说明

- 只读取当前页已经显示的商品；
- 不自动翻页、不自动登录；
- 京东安全验证和拼多多登录必须人工完成；
- 页面结构或平台风控变化时，提取可能失败，程序会显示原因。

## 上传 GitHub

推荐把本目录作为仓库源码上传，不要提交构建出来的 `dist` 目录。

如果要在 GitHub 提供可运行包，请使用 **Releases** 上传完整 zip；GitHub Release 附件支持大文件。普通仓库网页单文件上传通常限制 25 MB。
