(() => {
  "use strict";

  const STORAGE_KEY = "pricelens-compare-results-v1";
  const META = {
    jd: { name: "京东", color: "#df2f28" },
    taobao: { name: "淘宝", color: "#f25c1d" },
    pdd: { name: "拼多多", color: "#d9364a" }
  };

  const workspace = document.getElementById("workspaceView");
  const demoView = document.getElementById("demoView");
  const realView = document.getElementById("realView");
  const recordsView = document.getElementById("recordsView");
  const navWorkspace = document.getElementById("navWorkspace");
  const navDemo = document.getElementById("navDemo");
  const navReal = document.getElementById("navReal");

  const demoQuery = document.getElementById("demoQuery");
  const demoCount = document.getElementById("demoCount");
  const demoLowest = document.getElementById("demoLowest");
  const demoLowestNote = document.getElementById("demoLowestNote");
  const demoCards = document.getElementById("demoCards");
  const demoBars = document.getElementById("demoBars");
  const demoChart = document.getElementById("demoChart");
  const demoEmpty = document.getElementById("demoEmpty");
  const demoEmptyBtn = document.getElementById("demoEmptyBtn");
  const demoRefreshBtn = document.getElementById("demoRefreshBtn");

  const realQuery = document.getElementById("realQuery");
  const realCount = document.getElementById("realCount");
  const realLowest = document.getElementById("realLowest");
  const realLowestNote = document.getElementById("realLowestNote");
  const realColumns = document.getElementById("realColumns");
  const realEmpty = document.getElementById("realEmpty");
  const realSub = document.getElementById("realSub");
  const realGoBtn = document.getElementById("realGoBtn");
  const realEmptyBtn = document.getElementById("realEmptyBtn");
  const buttons = [navWorkspace, navDemo, navReal];

  if (!workspace || !demoView || !realView || !navWorkspace) return;

  function formatPrice(value) {
    return `¥${Number(value).toFixed(2)}`;
  }

  function formatTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "未知时间";
    return date.toLocaleString("zh-CN", {
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function readDatabase() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list)
        ? list.filter((item) => item && item.platforms && typeof item.platforms === "object")
        : [];
    } catch {
      return [];
    }
  }

  function scoreResult(result) {
    if (!result || !window.PriceLensScore) return [];
    return window.PriceLensScore.scorePlatforms(result.platforms);
  }

  function topByPlatform(all) {
    const top = {};
    all.forEach((item) => {
      if (!top[item.platform]) top[item.platform] = item;
    });
    return top;
  }

  function showScreen(name) {
    workspace.hidden = name !== "workspace";
    demoView.hidden = name !== "demo";
    realView.hidden = name !== "real";
    if (recordsView) recordsView.hidden = true;
    buttons.forEach((button) => button.classList.toggle("is-active", button.dataset.screen === name));
    if (name === "demo") renderDemo();
    if (name === "real") renderReal();
  }

  function renderDemo() {
    const database = readDatabase();
    const result = database[0] || null;
    const all = scoreResult(result);
    const recommended = all[0] || null;
    const top = topByPlatform(all);

    if (!result || !all.length) {
      demoQuery.textContent = "—";
      demoCount.textContent = "0";
      demoLowest.textContent = "—";
      demoLowestNote.textContent = "数据库还没有数据";
      demoCards.replaceChildren();
      demoBars.replaceChildren();
      demoCards.hidden = true;
      demoChart.hidden = true;
      demoEmpty.hidden = false;
      return;
    }

    demoEmpty.hidden = true;
    demoCards.hidden = false;
    demoChart.hidden = false;
    demoQuery.textContent = result.query || "—";
    demoCount.textContent = String(all.length);
    demoLowest.textContent = recommended ? formatPrice(recommended.price) : "—";
    demoLowestNote.textContent = recommended
      ? `综合分 ${recommended.score} · ${window.PriceLensScore.metricText(recommended)}`
      : "没有可推荐商品";

    demoCards.replaceChildren();
    ["jd", "taobao", "pdd"].forEach((platform) => {
      const meta = META[platform];
      const item = top[platform];
      const card = document.createElement("article");
      card.className = `demo-card${recommended && item && item.url === recommended.url ? " is-lowest" : ""}`;
      card.style.setProperty("--brand-color", meta.color);

      if (!item) {
        card.classList.add("is-empty");
        const empty = document.createElement("p");
        empty.className = "real-empty-text";
        empty.textContent = "这个平台在最新数据库记录里没有商品。";
        card.append(empty);
        demoCards.append(card);
        return;
      }

      if (recommended && item.url === recommended.url) {
        const badge = document.createElement("span");
        badge.className = "demo-lowest-badge";
        badge.textContent = "综合推荐";
        card.append(badge);
      }

      const topRow = document.createElement("div");
      topRow.className = "demo-card-top";
      const platformName = document.createElement("span");
      platformName.className = "demo-platform";
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      platformName.append(dot, document.createTextNode(meta.name));
      const tag = document.createElement("span");
      tag.className = "demo-tag";
      tag.textContent = "数据库";
      if (recommended && item.url === recommended.url) tag.hidden = true;
      topRow.append(platformName, tag);

      const price = document.createElement("div");
      price.className = "demo-price";
      price.innerHTML = `<small>¥</small>${Number(item.price).toFixed(2)}`;

      const metaRow = document.createElement("div");
      metaRow.className = "demo-meta";
      const shop = document.createElement("span");
      shop.className = "demo-shop";
      shop.textContent = item.shop || "店铺未提取";
      const sales = document.createElement("span");
      sales.className = "demo-sales";
      sales.textContent = item.sales
        ? `已售 ${window.PriceLensScore.formatCount(item.sales)}`
        : window.PriceLensScore.metricText(item);
      metaRow.append(shop, sales);

      const scoreRow = document.createElement("div");
      scoreRow.className = "demo-score-row";
      const score = document.createElement("span");
      score.className = "demo-score-pill";
      score.textContent = `综合分 ${item.score}`;
      const metric = document.createElement("span");
      metric.className = "demo-score-metric";
      metric.textContent = window.PriceLensScore.metricText(item);
      scoreRow.append(score, metric);

      const foot = document.createElement("div");
      foot.className = "demo-card-foot";
      const record = document.createElement("span");
      record.textContent = `保存于 ${formatTime(result.capturedAt)}`;
      const source = document.createElement("span");
      source.textContent = "本机数据库";
      foot.append(record, source);

      card.append(topRow, price, metaRow, scoreRow, foot);
      demoCards.append(card);
    });

    demoBars.replaceChildren();
    const offerRows = ["jd", "taobao", "pdd"]
      .map((platform) => top[platform])
      .filter(Boolean);
    const max = Math.max(...offerRows.map((item) => item.price), 1);
    offerRows.forEach((item) => {
      const row = document.createElement("div");
      row.className = "demo-bar-row";
      row.style.setProperty("--brand-color", META[item.platform].color);

      const label = document.createElement("span");
      label.className = "demo-bar-label";
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      label.append(dot, document.createTextNode(META[item.platform].name));

      const track = document.createElement("div");
      track.className = "demo-bar-track";
      const fill = document.createElement("div");
      fill.className = "demo-bar-fill";
      fill.style.width = `${Math.max(8, (item.price / max) * 100)}%`;
      track.append(fill);

      const price = document.createElement("span");
      price.className = "demo-bar-price";
      price.textContent = formatPrice(item.price);

      row.append(label, track, price);
      demoBars.append(row);
    });
  }

  function renderReal() {
    const database = readDatabase();
    const result = database[0] || null;
    const all = scoreResult(result);
    const recommended = all[0] || null;

    realQuery.textContent = result ? result.query || "—" : "—";
    realCount.textContent = String(all.length);
    realLowest.textContent = recommended ? formatPrice(recommended.price) : "—";
    realLowestNote.textContent = recommended
      ? `综合分 ${recommended.score} · ${window.PriceLensScore.metricText(recommended)}`
      : "数据库中还没有数据";
    realSub.textContent = result
      ? `数据库最近一次记录：${formatTime(result.capturedAt)} · 共 ${database.length} 次比价记录`
      : "数据库为空。先在「三平台同屏」点一次「比价搜索」。";

    realColumns.replaceChildren();
    realEmpty.hidden = Boolean(result && all.length);
    realColumns.hidden = !(result && all.length);

    if (!result || !all.length) return;

    ["jd", "taobao", "pdd"].forEach((platform) => {
      const meta = META[platform];
      const state = (result.states && result.states[platform]) || {};
      const items = all.filter((item) => item.platform === platform);

      const column = document.createElement("section");
      column.className = "real-column";
      column.style.setProperty("--brand-color", meta.color);

      const head = document.createElement("header");
      head.className = "real-column-head";
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      const name = document.createElement("strong");
      name.textContent = meta.name;
      const count = document.createElement("span");
      count.textContent = `${items.length} 条`;
      head.append(dot, name, count);
      column.append(head);

      const list = document.createElement("div");
      list.className = "real-list";
      if (!items.length) {
        const empty = document.createElement("p");
        empty.className = "real-empty-text";
        empty.textContent = state.reason || "数据库里这个平台没有商品记录。";
        list.append(empty);
      } else {
        items.forEach((item) => {
          const isRecommended = recommended && item.url === recommended.url;
          const card = document.createElement("article");
          card.className = `real-card${isRecommended ? " is-recommended" : ""}`;

          const top = document.createElement("div");
          top.className = "real-card-top";
          const price = document.createElement("strong");
          price.className = "real-price";
          price.textContent = formatPrice(item.price);
          const shop = document.createElement("span");
          shop.className = "real-shop";
          shop.textContent = item.shop || "店铺未提取";
          top.append(price, shop);

          const title = document.createElement("div");
          title.className = "real-title";
          title.textContent = item.title;
          title.title = item.title;

          const scoreRow = document.createElement("div");
          scoreRow.className = "real-score-row";
          const score = document.createElement("span");
          score.className = "real-score";
          score.textContent = isRecommended ? `综合推荐 · 综合分 ${item.score}` : `综合分 ${item.score}`;
          const metric = document.createElement("span");
          metric.className = "real-score-metric";
          metric.textContent = window.PriceLensScore.metricText(item);
          scoreRow.append(score, metric);

          card.append(top, title, scoreRow);
          list.append(card);
        });
      }
      column.append(list);
      realColumns.append(column);
    });
  }

  navWorkspace.addEventListener("click", () => showScreen("workspace"));
  navDemo.addEventListener("click", () => showScreen("demo"));
  navReal.addEventListener("click", () => showScreen("real"));
  if (demoRefreshBtn) demoRefreshBtn.addEventListener("click", renderDemo);
  if (demoEmptyBtn) demoEmptyBtn.addEventListener("click", () => showScreen("workspace"));
  if (realGoBtn) realGoBtn.addEventListener("click", () => showScreen("workspace"));
  if (realEmptyBtn) realEmptyBtn.addEventListener("click", () => showScreen("workspace"));

  renderDemo();
  renderReal();
  showScreen("workspace");
})();
