(() => {
  "use strict";

  const PLATFORM_META = {
    jd: { name: "京东", color: "#df2f28" },
    taobao: { name: "淘宝", color: "#f25c1d" },
    pdd: { name: "拼多多", color: "#d9364a" }
  };
  const STORAGE_KEY = "pricelens-compare-results-v1";

  const refs = {
    button: document.getElementById("compareBtn"),
    dialog: document.getElementById("compareDialog"),
    close: document.getElementById("compareCloseBtn"),
    query: document.getElementById("compareQuery"),
    count: document.getElementById("compareCount"),
    lowest: document.getElementById("compareLowest"),
    lowestNote: document.getElementById("compareLowestNote"),
    sub: document.getElementById("compareSub"),
    columns: document.getElementById("compareColumns"),
    empty: document.getElementById("compareEmpty"),
    searchInput: document.getElementById("searchInput"),
    autoSort: document.getElementById("autoSortToggle")
  };

  const views = {
    jd: document.getElementById("jdView"),
    taobao: document.getElementById("taobaoView"),
    pdd: document.getElementById("pddView")
  };

  if (!refs.button || !refs.dialog || !views.jd) return;

  let lastResult = null;

  function meta(key) {
    return PLATFORM_META[key] || PLATFORM_META.jd;
  }

  function formatPrice(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `¥${n.toFixed(2)}` : "—";
  }

  function formatTime(value) {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleString("zh-CN", {
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function saveResult(result) {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      const history = raw ? JSON.parse(raw) : [];
      const list = Array.isArray(history) ? history : [];
      list.unshift(result);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list.slice(0, 10)));
    } catch {
      // Local storage may be unavailable; the on-screen result still works.
    }
  }

  function autoSortInPage(platform) {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const visible = (node) => {
      if (!node || !node.isConnected) return false;
      const style = window.getComputedStyle(node);
      const rect = node.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
    };
    const pageUrl = location.href;
    if (/login|passport|risk_handler|verify|captcha/i.test(pageUrl)) {
      return { clicked: false, reason: "当前是登录/验证页" };
    }

    const priority = new Map([
      ["评分最高", 14],
      ["评分", 13],
      ["好评优先", 12],
      ["好评", 11],
      ["口碑", 10],
      ["评价", 9],
      ["推荐", 7],
      ["综合", 6]
    ]);
    const interesting = Array.from(document.querySelectorAll("a, button, [role='button'], li, span, div"))
      .filter((node) => {
        const text = clean(node.innerText || node.textContent).replace(/[↓↑⇅↕]/g, "").trim();
        if (!priority.has(text)) return false;
        if (!visible(node)) return false;
        if (node.children.length > 4) return false;
        return true;
      })
      .map((node) => {
        let score = 0;
        if (node.matches("a, button, [role='button']")) score += 4;
        const context = `${node.className || ""} ${node.id || ""} ${node.parentElement ? node.parentElement.className : ""}`.toLowerCase();
        if (/sort|order|sorter|filter|rank/.test(context)) score += 5;
        const text = clean(node.innerText || "").replace(/[↓↑⇅↕]/g, "");
        score += priority.get(text) || 0;
        return { node, score };
      })
      .sort((left, right) => right.score - left.score);

    if (!interesting.length) {
      return { clicked: false, reason: "没有找到评分/好评排序按钮" };
    }

    let target = interesting[0].node;
    if (!target.matches("a, button, [role='button']")) {
      const inner = target.querySelector("a, button, [role='button']");
      if (inner) target = inner;
    }

    try {
      target.click();
      return { clicked: true, reason: `已点击：${clean(target.innerText || "评分")}`, platform };
    } catch (error) {
      return { clicked: false, reason: `点击失败：${error.message}` };
    }
  }

  function openDialog() {
    if (typeof refs.dialog.showModal === "function") {
      if (!refs.dialog.open) refs.dialog.showModal();
    } else {
      refs.dialog.setAttribute("open", "");
    }
  }

  function closeDialog() {
    if (typeof refs.dialog.close === "function") refs.dialog.close();
    else refs.dialog.removeAttribute("open");
  }

  function extractCards(platform) {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim().slice(0, 160);
    const parsePrice = (value) => {
      const match = String(value || "").replace(/,/g, "").match(/(\d+(?:\.\d{1,2})?)/);
      if (!match) return 0;
      const price = Number(match[1]);
      return Number.isFinite(price) && price > 0.5 && price < 1000000 ? Math.round(price * 100) / 100 : 0;
    };
    const priceFromText = (text) => {
      const matches = String(text || "").match(/[¥￥]\s*\d[\d,]*(?:\.\d{1,2})?/g);
      if (!matches || !matches.length) return 0;
      return parsePrice(matches[0]);
    };
    const absolute = (href) => {
      try { return new URL(href, location.href).href; } catch { return ""; }
    };
    const textOf = (node, selectors) => {
      if (!node) return "";
      for (const selector of selectors) {
        const found = node.querySelector(selector);
        if (found) {
          const value = clean(found.getAttribute("title") || found.getAttribute("aria-label") || found.innerText || found.textContent);
          if (value) return value;
        }
      }
      return "";
    };
    const parseCompact = (value) => {
      const text = String(value || "").replace(/,/g, "");
      const match = text.match(/([\d.]+)\s*(万|亿)?/);
      if (!match) return 0;
      const number = Number(match[1]);
      if (!Number.isFinite(number)) return 0;
      if (match[2] === "万") return number * 10000;
      if (match[2] === "亿") return number * 100000000;
      return number;
    };
    const readMetrics = (card) => {
      const text = clean(card.innerText || card.textContent || "").slice(0, 900);
      const ratingMatch = text.match(/(\d(?:\.\d)?)\s*分/);
      const ratingValue = ratingMatch ? Number(ratingMatch[1]) : 0;
      const rating = ratingValue > 0 && ratingValue <= 5 ? ratingValue : 0;

      const salesMatch =
        text.match(/(?:已售|销量|已拼|人付款|人已买|人收货)\s*([\d.]+)\s*(万|亿)?/) ||
        text.match(/([\d.]+)\s*(万|亿)?\+?\s*(?:人付款|人已买|人收货|已售|销量)/);
      const sales = salesMatch ? parseCompact(`${salesMatch[1]}${salesMatch[2] || ""}`) : 0;

      const commentMatch = text.match(/([\d.]+)\s*(万|亿)?\+?\s*(?:条)?(?:评价|评论)/);
      const comments = commentMatch ? parseCompact(`${commentMatch[1]}${commentMatch[2] || ""}`) : 0;

      const dataRating = card.getAttribute("data-rating") || card.getAttribute("data-score");
      const dataSales = card.getAttribute("data-sales") || card.getAttribute("data-sold");
      const ratingFromData = Number(dataRating);
      return {
        rating: rating || (ratingFromData > 0 && ratingFromData <= 5 ? ratingFromData : 0),
        sales: sales || parseCompact(dataSales),
        comments,
        official: /自营|官方|旗舰|百亿补贴|品牌/.test(text)
      };
    };
    const findCard = (anchor) => {
      let node = anchor;
      for (let depth = 0; depth < 6 && node; depth += 1) {
        if (node.matches && node.matches("li, article, [class*='item'], [class*='goods'], [class*='card']")) return node;
        node = node.parentElement;
      }
      return anchor.closest("li, article") || anchor.parentElement || anchor;
    };

    const pageUrl = location.href;
    const pageText = clean(document.body ? document.body.innerText : "").slice(0, 3000);
    const blocked =
      /login|passport|risk_handler|verify|captcha/i.test(pageUrl) ||
      (pageText.length < 1200 && /(登录|验证码|安全验证|扫码登录|手机登录)/.test(pageText));

    if (blocked) {
      const reason = platform === "jd"
        ? "京东需要登录或完成安全验证"
        : platform === "pdd"
          ? "拼多多需要登录或扫码验证"
          : "淘宝需要登录或完成验证";
      return { items: [], blocked: true, reason };
    }

    const configs = {
      jd: {
        cardSelectors: ["#J_goodsList li.gl-item", ".gl-item", "#J_goodsList [data-sku]", "li[data-sku]", ".gl-i-wrap"],
        linkSelectors: [".p-name a", "a[href*='item.jd.com']"],
        titleSelectors: [".p-name em", ".p-name", "img[alt]"],
        priceSelectors: [".p-price i", ".p-price strong", ".p-price", "[class*='price']"],
        shopSelectors: [".p-shop a", ".p-shop", "[class*='shop']"]
      },
      taobao: {
        cardSelectors: [".items .item", "div.item"],
        linkSelectors: [".pic a", ".title a", "a[href*='item.taobao.com']", "a[href*='detail.tmall.com']"],
        titleSelectors: [".title", ".row-2", "img[alt]"],
        priceSelectors: [".price strong", ".price", "[class*='price']"],
        shopSelectors: [".shop a", ".shopname", "[class*='shop']"]
      },
      pdd: {
        cardSelectors: [
          "[data-goods-id]", "[data-goods_id]", "[data-goodsId]",
          "a[href*='goods.html']", "a[href*='goods_id']",
          ".goods-item", ".goods-card", "[class*='goods-item']",
          "[class*='goods-list'] [class*='item']", "[class*='goodsList'] [class*='item']"
        ],
        linkSelectors: ["a[href*='goods.html']", "a[href*='goods_id']"],
        titleSelectors: ["[class*='title']", "[class*='name']", "img[alt]"],
        priceSelectors: ["[class*='price']", ".price"],
        shopSelectors: ["[class*='mall']", "[class*='shop']"]
      }
    };

    const patterns = {
      jd: /item\.jd\.com\//i,
      taobao: /item\.taobao\.com\/|detail\.tmall\.com\/|item\.tmall\.com\//i,
      pdd: /goods\.html|goods_id=|yangkeduo\.com\/.*goods/i
    };

    const config = configs[platform] || configs.jd;
    const items = [];
    const seen = new Set();

    function productUrl(card, link) {
      let raw = link ? link.getAttribute("href") || "" : "";
      if (raw) {
        const absoluteUrl = absolute(raw);
        if (absoluteUrl) return absoluteUrl;
      }
      const attributes = ["data-goods-id", "data-goods_id", "data-goodsId", "data-sku", "data-skuid", "data-id"];
      const dataNode = card.matches && card.matches("[data-goods-id], [data-goods_id], [data-goodsId], [data-sku], [data-skuid], [data-id]")
        ? card
        : card.querySelector("[data-goods-id], [data-goods_id], [data-goodsId], [data-sku], [data-skuid], [data-id]");
      for (const name of attributes) {
        const value = dataNode ? dataNode.getAttribute(name) : "";
        if (value && /^\d{4,}$/.test(value)) {
          if (platform === "jd") return `https://item.jd.com/${value}.html`;
          if (platform === "pdd") return `https://mobile.yangkeduo.com/goods.html?goods_id=${value}`;
        }
      }
      const html = card.outerHTML || "";
      const match = html.match(/(?:goods_id|goodsId|skuId|sku)[=:'"]+(\d{5,})/i);
      if (match) {
        if (platform === "jd") return `https://item.jd.com/${match[1]}.html`;
        if (platform === "pdd") return `https://mobile.yangkeduo.com/goods.html?goods_id=${match[1]}`;
      }
      return "";
    }

    function readCard(card, link) {
      if (!card) return;
      const dataTitle =
        card.getAttribute("data-title") ||
        card.getAttribute("data-goods-name") ||
        card.getAttribute("data-goodsName") ||
        "";
      let title = clean(dataTitle) || textOf(card, config.titleSelectors);
      if (!title && link) title = clean(link.getAttribute("title") || link.getAttribute("aria-label") || link.innerText || "");
      if (!title) {
        const image = card.querySelector("img");
        title = clean(image ? image.getAttribute("alt") : "");
      }
      if (!title) {
        const lines = String(card.innerText || "").split("\n").map(clean).filter(Boolean);
        title = lines.find((line) => line.length >= 7 && !/[¥￥]/.test(line) && !/已售|评价|人付款|退货|包邮/.test(line)) || "";
      }
      if (!title || title.length < 4) return;

      let price = 0;
      for (const selector of config.priceSelectors) {
        const node = card.querySelector(selector);
        if (!node) continue;
        price = parsePrice(node.innerText || node.textContent);
        if (price) break;
      }
      if (!price) {
        const priceNode = card.querySelector("[data-price], [data-price-value], [data-sale-price]");
        const dataPrice = priceNode
          ? priceNode.getAttribute("data-price") || priceNode.getAttribute("data-price-value") || priceNode.getAttribute("data-sale-price")
          : card.getAttribute("data-price") || card.getAttribute("data-price-value");
        price = parsePrice(dataPrice);
      }
      if (!price) price = priceFromText(card.innerText || card.textContent);
      if (!price) return;

      const url = productUrl(card, link) || pageUrl;
      const key = url === pageUrl ? `${title}|${price}` : url;
      if (seen.has(key)) return;
      seen.add(key);
      const shop =
        card.getAttribute("data-mall-name") ||
        card.getAttribute("data-shop-name") ||
        textOf(card, config.shopSelectors) ||
        "店铺未提取";
      const metrics = readMetrics(card);
      items.push({ title, price, shop, url, platform, ...metrics });
    }

    config.cardSelectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((card) => {
        if (items.length >= 24) return;
        let link = null;
        for (const linkSelector of config.linkSelectors) {
          link = card.matches && card.matches(linkSelector) ? card : card.querySelector(linkSelector);
          if (link) break;
        }
        if (!link) link = card.querySelector("a[href]");
        readCard(card, link);
      });
    });

    if (items.length < 4) {
      const candidates = Array.from(document.querySelectorAll(
        platform === "pdd"
          ? "[data-goods-id], [data-goods_id], [data-goodsId], [class*='goods'], [class*='item']"
          : platform === "jd"
            ? "li.gl-item, [data-sku], [class*='item']"
            : ".item, [class*='item']"
      )).slice(0, 300);
      candidates.forEach((card) => {
        if (items.length >= 24) return;
        if (!/[¥￥]\s*\d/.test(card.innerText || "")) return;
        readCard(card, card.querySelector("a[href]"));
      });
    }

    // 京东/拼多多改版后经常把商品卡片渲染成嵌套 div，既没有稳定 class，也没有 a 链接。
    // 最后再按“包含价格且长度像一张卡片”的文本块兜底，不依赖平台 class。
    if (items.length < 4) {
      const textCards = Array.from(document.querySelectorAll("div, li, article, section, a"))
        .filter((node) => {
          const text = String(node.innerText || "").trim();
          return text.length > 15 && text.length < 620 && /[¥￥]\s*\d/.test(text);
        })
        .sort((left, right) => String(left.innerText || "").length - String(right.innerText || "").length)
        .slice(0, 700);
      textCards.forEach((card) => {
        if (items.length >= 24) return;
        const link = card.querySelector("a[href*='goods'], a[href*='item'], a[href]");
        readCard(card, link);
      });
    }

    if (items.length < 4) {
      document.querySelectorAll("a[href]").forEach((link) => {
        if (items.length >= 24) return;
        const href = absolute(link.getAttribute("href") || "");
        if (!patterns[platform] || !patterns[platform].test(href)) return;
        readCard(findCard(link), link);
      });
    }

    return { items: items.sort((left, right) => left.price - right.price).slice(0, 24), blocked: false, reason: "" };
  }

  async function runCompare() {
    const query = (refs.searchInput && refs.searchInput.value.trim()) || "当前页面";
    const originalHTML = refs.button.innerHTML;
    refs.button.disabled = true;
    refs.button.innerHTML = '<span class="compare-button-icon" aria-hidden="true">¥</span>读取中…';

    try {
      const platforms = {};
      const states = {};
      let total = 0;

      for (const platform of ["jd", "taobao", "pdd"]) {
        try {
          let sortResult = null;
          if (refs.autoSort && refs.autoSort.checked) {
            try {
              const sortCode = `(${autoSortInPage.toString()})(${JSON.stringify(platform)})`;
              sortResult = await views[platform].executeJavaScript(sortCode, true);
              if (sortResult && sortResult.clicked) {
                await new Promise((resolve) => setTimeout(resolve, 900));
              }
            } catch {
              sortResult = { clicked: false, reason: "排序按钮读取失败" };
            }
          }

          const code = `(${extractCards.toString()})(${JSON.stringify(platform)})`;
          let result = await views[platform].executeJavaScript(code, true);
          let items = Array.isArray(result && result.items) ? result.items : [];
          // 京东/拼多多的商品卡片是异步补渲染的，第一次为空时等页面稳定再读一次。
          if (!items.length && !(result && result.blocked)) {
            await new Promise((resolve) => setTimeout(resolve, 900));
            result = await views[platform].executeJavaScript(code, true);
            items = Array.isArray(result && result.items) ? result.items : [];
          }
          platforms[platform] = items;
          states[platform] = {
            blocked: Boolean(result && result.blocked),
            reason: (result && result.reason) || "",
            sorted: Boolean(sortResult && sortResult.clicked),
            sortReason: (sortResult && sortResult.reason) || ""
          };
          total += items.length;
        } catch (error) {
          platforms[platform] = [];
          states[platform] = { blocked: false, reason: "读取失败，请确认页面已加载" };
        }
      }

      const scorer = window.PriceLensScore;
      const scored = scorer ? scorer.scorePlatforms(platforms) : [];
      lastResult = {
        id: `compare-${Date.now()}`,
        query,
        capturedAt: new Date().toISOString(),
        platforms,
        states,
        recommended: scored.length ? scored[0] : null,
        scoreVersion: 1
      };
      saveResult(lastResult);
      renderResult(lastResult);
      openDialog();
    } finally {
      refs.button.disabled = false;
      refs.button.innerHTML = originalHTML;
    }
  }

  function renderResult(result) {
    refs.columns.replaceChildren();
    if (!result) {
      refs.empty.hidden = false;
      refs.columns.hidden = true;
      return;
    }

    const order = ["jd", "taobao", "pdd"];
    const states = result.states || {};
    const scorer = window.PriceLensScore;
    if (scorer) scorer.scorePlatforms(result.platforms);
    const all = order.flatMap((platform) =>
      (Array.isArray(result.platforms[platform]) ? result.platforms[platform] : []).map((item) => ({ ...item, platform }))
    ).sort((left, right) => {
      if ((right.score || 0) !== (left.score || 0)) return (right.score || 0) - (left.score || 0);
      return left.price - right.price;
    });
    const recommended = all[0] || null;

    refs.query.textContent = result.query || "—";
    refs.count.textContent = String(all.length);
    refs.lowest.textContent = recommended ? formatPrice(recommended.price) : "—";
    refs.lowestNote.textContent = recommended
      ? `综合分 ${recommended.score || "—"} · ${scorer ? scorer.metricText(recommended) : "评分/销量"} · ${meta(recommended.platform).name}`
      : "没有读取到商品";
    const sortedCount = order.filter((platform) => states[platform] && states[platform].sorted).length;
    refs.sub.textContent = `读取时间 ${formatTime(result.capturedAt)} · 综合评分=评分45%+销量25%+价格20%+店铺10% · ${sortedCount ? `已尝试评分排序 ${sortedCount} 个平台` : "未点击平台排序"} · 不翻页`;
    refs.empty.hidden = true;
    refs.columns.hidden = false;

    order.forEach((platform) => {
      const info = meta(platform);
      const state = states[platform] || {};
      const items = (Array.isArray(result.platforms[platform]) ? result.platforms[platform] : [])
        .slice()
        .sort((left, right) => {
          if ((right.score || 0) !== (left.score || 0)) return (right.score || 0) - (left.score || 0);
          return left.price - right.price;
        });

      const section = document.createElement("section");
      section.className = "compare-platform";
      section.style.setProperty("--brand-color", info.color);

      const head = document.createElement("header");
      head.className = "compare-platform-head";
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      const name = document.createElement("strong");
      name.textContent = info.name;
      const count = document.createElement("span");
      count.textContent = `${items.length} 条`;
      head.append(dot, name, count);
      section.append(head);

      const list = document.createElement("div");
      list.className = "compare-list";
      if (items.length === 0) {
        const empty = document.createElement("p");
        empty.className = "compare-empty-text";
        empty.textContent = state.reason || "当前页没有读取到商品。请确认已登录、页面已经显示搜索结果。";
        list.append(empty);
      } else {
        items.forEach((item) => {
          const isRecommended = Boolean(
            recommended &&
            item.url === recommended.url &&
            item.title === recommended.title &&
            item.price === recommended.price
          );
          const card = document.createElement("div");
          card.className = `compare-card${isRecommended ? " is-recommended" : ""}`;

          if (isRecommended) {
            const badge = document.createElement("span");
            badge.className = "compare-recommend-badge";
            badge.textContent = "综合推荐";
            card.append(badge);
          }

          const top = document.createElement("div");
          top.className = "compare-card-top";
          const price = document.createElement("span");
          price.className = "compare-card-price";
          price.textContent = formatPrice(item.price);
          const shop = document.createElement("span");
          shop.className = "compare-card-shop";
          shop.textContent = item.shop || "店铺未提取";
          top.append(price, shop);

          const title = document.createElement("div");
          title.className = "compare-card-title";
          title.textContent = item.title;
          title.title = item.title;

          const scoreRow = document.createElement("div");
          scoreRow.className = "compare-card-score-row";
          const score = document.createElement("span");
          score.className = "compare-card-score";
          score.textContent = `综合分 ${item.score != null ? item.score : "—"}`;
          const metrics = document.createElement("span");
          metrics.className = "compare-card-metrics";
          const metricParts = [];
          if (scorer) metricParts.push(scorer.metricText(item));
          if (item.sales && item.rating) metricParts.push(`已售 ${scorer ? scorer.formatCount(item.sales) : item.sales}`);
          if (item.official) metricParts.push("官方/自营");
          metrics.textContent = metricParts.join(" · ");
          scoreRow.append(score, metrics);

          const metaRow = document.createElement("div");
          metaRow.className = "compare-card-meta";
          const source = document.createElement("span");
          source.textContent = "当前页真实价格";
          const open = document.createElement("button");
          open.className = "compare-card-link";
          open.type = "button";
          open.textContent = "打开商品";
          open.addEventListener("click", () => {
            if (window.priceLensDesktop && typeof window.priceLensDesktop.openExternal === "function") {
              window.priceLensDesktop.openExternal(item.url);
            } else {
              window.open(item.url, "_blank", "noopener");
            }
          });
          metaRow.append(source, open);
          card.append(top, title, scoreRow, metaRow);
          list.append(card);
        });
      }
      section.append(list);

      const foot = document.createElement("footer");
      foot.className = "compare-platform-foot";
      foot.textContent = state.blocked ? state.reason : "按综合性价比排序，不只看价格";
      section.append(foot);
      refs.columns.append(section);
    });
  }

  refs.button.addEventListener("click", runCompare);
  refs.close.addEventListener("click", closeDialog);
  refs.dialog.addEventListener("click", (event) => {
    const rect = refs.dialog.getBoundingClientRect();
    const outside =
      event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom;
    if (outside) closeDialog();
  });

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const history = raw ? JSON.parse(raw) : [];
    if (Array.isArray(history) && history[0]) {
      lastResult = history[0];
      renderResult(lastResult);
    }
  } catch {
    // Ignore malformed history.
  }
})();
