(() => {
  "use strict";

  const PLATFORM_META = {
    jd: { name: "京东", color: "#df2f28" },
    taobao: { name: "淘宝", color: "#f25c1d" },
    pdd: { name: "拼多多", color: "#d9364a" },
    douyin: { name: "抖音商城", color: "#1c252c" },
    other: { name: "其他平台", color: "#5f6d64" }
  };

  const PLATFORM_URLS = {
    jd: (q) => `https://search.jd.com/Search?keyword=${encodeURIComponent(q)}&enc=utf-8`,
    taobao: (q) => `https://s.taobao.com/search?q=${encodeURIComponent(q)}`,
    pdd: (q) => `https://mobile.yangkeduo.com/search_result.html?search_key=${encodeURIComponent(q)}`
  };

  const FALLBACK_KEY = "pricelens-desktop-records-v1";
  const bridge = window.priceLensDesktop || null;

  const els = {
    tabs: Array.from(document.querySelectorAll("[data-view]")),
    workspaceView: document.getElementById("workspaceView"),
    recordsView: document.getElementById("recordsView"),
    searchForm: document.getElementById("searchForm"),
    searchInput: document.getElementById("searchInput"),
    tabCount: document.getElementById("tabCount"),
    captureDialog: document.getElementById("captureDialog"),
    captureForm: document.getElementById("captureForm"),
    closeDialogBtn: document.getElementById("closeDialogBtn"),
    cancelCaptureBtn: document.getElementById("cancelCaptureBtn"),
    capturePlatform: document.getElementById("capturePlatform"),
    captureProduct: document.getElementById("captureProduct"),
    capturePrice: document.getElementById("capturePrice"),
    captureOriginal: document.getElementById("captureOriginal"),
    captureShop: document.getElementById("captureShop"),
    captureUrl: document.getElementById("captureUrl"),
    captureNote: document.getElementById("captureNote"),
    variantName1: document.getElementById("variantName1"),
    variantValue1: document.getElementById("variantValue1"),
    variantName2: document.getElementById("variantName2"),
    variantValue2: document.getElementById("variantValue2"),
    statRecords: document.getElementById("statRecords"),
    statProducts: document.getElementById("statProducts"),
    statLowest: document.getElementById("statLowest"),
    statLowestNote: document.getElementById("statLowestNote"),
    emptyRecords: document.getElementById("emptyRecords"),
    tableWrap: document.getElementById("tableWrap"),
    recordBody: document.getElementById("recordBody"),
    backToWorkspaceBtn: document.getElementById("backToWorkspaceBtn"),
    clearRecordsBtn: document.getElementById("clearRecordsBtn"),
    dataPathBtn: document.getElementById("dataPathBtn"),
    toast: document.getElementById("toast"),
    toastText: document.getElementById("toastText")
  };

  const views = {
    jd: document.getElementById("jdView"),
    taobao: document.getElementById("taobaoView"),
    pdd: document.getElementById("pddView")
  };

  const hosts = {
    jd: document.getElementById("jdHost"),
    taobao: document.getElementById("taobaoHost"),
    pdd: document.getElementById("pddHost")
  };

  let records = [];
  let toastTimer = null;

  function showToast(message) {
    window.clearTimeout(toastTimer);
    els.toastText.textContent = message;
    els.toast.hidden = false;
    window.requestAnimationFrame(() => els.toast.classList.add("is-visible"));
    toastTimer = window.setTimeout(() => {
      els.toast.classList.remove("is-visible");
      window.setTimeout(() => { els.toast.hidden = true; }, 180);
    }, 2800);
  }

  function meta(key) {
    return PLATFORM_META[key] || PLATFORM_META.other;
  }

  function formatPrice(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `¥${n.toFixed(2)}` : "—";
  }

  function formatTime(value) {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return "—";
    return d.toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  }

  function variantsLabel(record) {
    return (Array.isArray(record.variants) ? record.variants : [])
      .map((v) => `${v.name} ${v.value}`)
      .join(" · ");
  }

  function randomId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return `desktop-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  async function loadRecords() {
    try {
      if (bridge) {
        const loaded = await bridge.loadRecords();
        return Array.isArray(loaded) ? loaded : [];
      }
      const raw = window.localStorage.getItem(FALLBACK_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.warn(error);
      return [];
    }
  }

  async function persistRecords() {
    if (bridge) {
      await bridge.saveRecords(records);
      return;
    }
    window.localStorage.setItem(FALLBACK_KEY, JSON.stringify(records));
  }

  function showView(view) {
    const isRecords = view === "records";
    els.workspaceView.hidden = isRecords;
    els.recordsView.hidden = !isRecords;
    els.tabs.forEach((tab) => tab.classList.toggle("is-active", tab.dataset.view === view));
    if (isRecords) renderRecords();
  }

  function updateHost(platform, url) {
    try { hosts[platform].textContent = new URL(url).host; }
    catch { hosts[platform].textContent = "加载中…"; }
  }

  function bindWebview(platform, view) {
    view.addEventListener("did-navigate", (event) => updateHost(platform, event.url));
    view.addEventListener("did-navigate-in-page", (event) => updateHost(platform, event.url));
    view.addEventListener("did-fail-load", () => { hosts[platform].textContent = "加载失败"; });
    try { updateHost(platform, view.getURL()); } catch { /* not attached yet */ }
  }

  function searchPlatforms(query) {
    const keyword = String(query || "").trim();
    if (!keyword) { els.searchInput.focus(); showToast("请先输入商品关键词"); return; }
    Object.entries(views).forEach(([platform, view]) => {
      const url = PLATFORM_URLS[platform](keyword);
      updateHost(platform, url);
      if (typeof view.loadURL === "function") {
        view.loadURL(url).catch(() => { hosts[platform].textContent = "加载失败"; });
      } else {
        view.src = url;
      }
    });
    showToast("已打开三个平台的搜索结果");
  }

  async function capturePage(platform, button) {
    const view = views[platform];
    if (!view) return;
    const oldText = button.textContent;
    button.disabled = true;
    button.textContent = "读取中…";
    try {
      const code = `(${extractPage.toString()})(${JSON.stringify(platform)})`;
      const data = await view.executeJavaScript(code, true);
      openDialog(platform, data || {});
    } catch (error) {
      console.warn(error);
      showToast("读取失败：请先等页面加载完成，并在面板里登录");
    } finally {
      button.disabled = false;
      button.textContent = oldText;
    }
  }

  function extractPage(platform) {
    const clean = (value) => String(value || "").replace(/\s+/g, " ").trim();
    const textOf = (selector) => {
      const node = document.querySelector(selector);
      return node ? clean(node.innerText || node.textContent) : "";
    };
    const metaContent = (name) => {
      const node = document.querySelector(`meta[property="${name}"], meta[name="${name}"]`);
      return node ? clean(node.getAttribute("content")) : "";
    };
    const parsePrice = (value) => {
      const match = String(value || "").replace(/,/g, "").match(/(\d+(?:\.\d{1,2})?)/);
      if (!match) return 0;
      const price = Number(match[1]);
      return Number.isFinite(price) && price > 0.5 && price < 1000000 ? price : 0;
    };

    const configs = {
      jd: {
        titles: [".sku-name", ".itemInfo-wrap .sku-name", "h1"],
        prices: [".summary-price .price", ".p-price .price", ".price", ".jd-price"],
        shops: [".shopName", ".J-hove-wrap .name a", ".popbox-inner .name", ".name a"],
        selected: [".item.selected", ".sku-item.selected", "[class*='selected']"]
      },
      taobao: {
        titles: ["h1", ".tb-main-title", "[class*='title']"],
        prices: [".tm-price", ".tb-rmb-num", "[class*='price']"],
        shops: [".shop-name", ".slogo-shopname", "[class*='shopName']", "[class*='shop-name']"],
        selected: [".sku-item.selected", "[class*='selected']"]
      },
      pdd: {
        titles: ["h1", "[class*='goodsName']", "[class*='goods-name']"],
        prices: [".price", "[class*='price']"],
        shops: [".mall-name", "[class*='mall']"],
        selected: ["[class*='selected']"]
      }
    };

    const config = configs[platform] || configs.jd;
    const prices = [];
    let originalPrice = 0;
    const addPrice = (value, source, priority) => {
      const price = parsePrice(value);
      if (!price) return;
      if (!prices.some((item) => item.value === price)) prices.push({ value: price, source, priority });
    };

    Array.from(document.querySelectorAll('script[type="application/ld+json"]')).forEach((node) => {
      try {
        const data = JSON.parse(node.textContent || "{}");
        (Array.isArray(data) ? data : [data]).forEach((item) => {
          const offers = item && (item.offers || item.offer);
          if (!offers) return;
          (Array.isArray(offers) ? offers : [offers]).forEach((offer) => {
            if (offer && (offer.price || offer.lowPrice)) addPrice(offer.price || offer.lowPrice, "json-ld", 1);
          });
        });
      } catch { /* ignore */ }
    });

    addPrice(metaContent("product:price:amount"), "meta", 0);
    addPrice(metaContent("og:price:amount"), "meta", 0);
    config.prices.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        const raw = clean(node.innerText || node.textContent);
        if (raw && raw.length < 80) addPrice(raw, selector, 2);
      });
    });

    const pageText = clean(document.body ? document.body.innerText : "").slice(0, 12000);
    (pageText.match(/[¥￥]\s*\d[\d,]*(?:\.\d{1,2})?/g) || []).slice(0, 8)
      .forEach((item) => addPrice(item, "visible", 3));

    prices.sort((a, b) => a.priority - b.priority || a.value - b.value);
    const price = prices[0] ? prices[0].value : 0;

    [".price-original", ".origin-price", ".old-price", ".line-through"].forEach((selector) => {
      if (originalPrice) return;
      const value = parsePrice(textOf(selector));
      if (value && value > price) originalPrice = value;
    });

    const title =
      config.titles.map(textOf).find((value) => value.length > 4) ||
      metaContent("og:title") ||
      clean(document.title).replace(/[-_|].*$/, "").trim();

    const shop = config.shops.map(textOf).find((value) => value.length > 1) || metaContent("og:site_name") || "";
    const selectedValues = [];
    config.selected.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        const value = clean(node.innerText || node.textContent);
        if (value && value.length <= 32 && !/[¥￥]/.test(value) && !selectedValues.includes(value)) {
          selectedValues.push(value);
        }
      });
    });

    const capacityPattern = /^\d+(?:\.\d+)?\s*(?:GB|TB|G|T)$/i;
    const colorPattern = /(黑|白|银|灰|金|蓝|绿|紫|粉|红|橙|黄|青|钛)/;
    const variants = selectedValues.slice(0, 2).map((value, index) => {
      if (capacityPattern.test(value)) return { name: "容量", value };
      if (colorPattern.test(value)) return { name: "颜色", value };
      return { name: index === 0 ? "规格1" : "规格2", value };
    });

    return {
      title,
      pageTitle: clean(document.title),
      price,
      priceCandidates: prices.slice(0, 8),
      originalPrice: originalPrice > price ? originalPrice : 0,
      shop,
      variants,
      url: location.href,
      host: location.host
    };
  }

  function openDialog(platform, data) {
    els.capturePlatform.value = platform;
    els.captureProduct.value = data.title || data.pageTitle || "";
    els.capturePrice.value = data.price ? String(data.price) : "";
    els.captureOriginal.value = data.originalPrice ? String(data.originalPrice) : "";
    els.captureShop.value = data.shop || "";
    els.captureUrl.value = data.url || "";
    els.captureNote.value = "页面价，未叠加账号券";

    const variants = Array.isArray(data.variants) ? data.variants : [];
    els.variantName1.value = (variants[0] && variants[0].name) || "容量";
    els.variantValue1.value = (variants[0] && variants[0].value) || "";
    els.variantName2.value = (variants[1] && variants[1].name) || "颜色";
    els.variantValue2.value = (variants[1] && variants[1].value) || "";

    if (typeof els.captureDialog.showModal === "function") {
      if (!els.captureDialog.open) els.captureDialog.showModal();
    } else {
      els.captureDialog.setAttribute("open", "");
    }
    window.setTimeout(() => els.capturePrice.focus(), 60);
  }

  function closeDialog() {
    if (typeof els.captureDialog.close === "function") els.captureDialog.close();
    else els.captureDialog.removeAttribute("open");
  }

  function readForm() {
    const product = els.captureProduct.value.trim();
    const price = Number(els.capturePrice.value);
    const original = Number(els.captureOriginal.value);

    if (!product) { els.captureProduct.focus(); showToast("请填写商品名称"); return null; }
    if (!Number.isFinite(price) || price <= 0) { els.capturePrice.focus(); showToast("请填写大于 0 的价格"); return null; }

    const variants = [];
    const n1 = els.variantName1.value.trim() || "规格1";
    const v1 = els.variantValue1.value.trim();
    const n2 = els.variantName2.value.trim() || "规格2";
    const v2 = els.variantValue2.value.trim();
    if (v1) variants.push({ name: n1, value: v1 });
    if (v2) variants.push({ name: n2, value: v2 });

    return {
      id: randomId(),
      platform: els.capturePlatform.value,
      product,
      price: Math.round(price * 100) / 100,
      originalPrice: Number.isFinite(original) && original > price ? Math.round(original * 100) / 100 : null,
      variants,
      shop: els.captureShop.value.trim(),
      note: els.captureNote.value.trim(),
      url: els.captureUrl.value.trim(),
      capturedAt: new Date().toISOString(),
      source: "desktop-capture"
    };
  }

  async function saveCapture() {
    const record = readForm();
    if (!record) return;
    records.unshift(record);
    try {
      await persistRecords();
      closeDialog();
      renderRecords();
      showToast(`已保存 ${meta(record.platform).name} 价格 ${formatPrice(record.price)}`);
    } catch (error) {
      records.shift();
      showToast(`保存失败：${error.message || "无法写入本机数据"}`);
    }
  }

  function renderRecords() {
    els.tabCount.textContent = String(records.length);
    const productMap = new Map();
    records.forEach((record) => {
      const current = productMap.get(record.product);
      if (!current || Number(record.price) < Number(current.price)) productMap.set(record.product, record);
    });
    els.statRecords.textContent = String(records.length);
    els.statProducts.textContent = String(productMap.size);

    const lowest = records.reduce((best, record) => (!best || Number(record.price) < Number(best.price) ? record : best), null);
    if (lowest) {
      els.statLowest.textContent = formatPrice(lowest.price);
      els.statLowestNote.textContent = `${meta(lowest.platform).name} · ${lowest.product}`;
    } else {
      els.statLowest.textContent = "—";
      els.statLowestNote.textContent = "还没有记录";
    }

    els.emptyRecords.hidden = records.length > 0;
    els.tableWrap.hidden = records.length === 0;
    els.recordBody.replaceChildren();

    const lowestByProduct = new Map();
    records.forEach((record) => {
      const current = lowestByProduct.get(record.product);
      if (!current || Number(record.price) < Number(current.price)) lowestByProduct.set(record.product, record);
    });

    records.slice().sort((a, b) => new Date(b.capturedAt) - new Date(a.capturedAt)).forEach((record) => {
      const info = meta(record.platform);
      const tr = document.createElement("tr");

      const tdTime = document.createElement("td");
      tdTime.textContent = formatTime(record.capturedAt);
      tr.append(tdTime);

      const tdPlatform = document.createElement("td");
      const tag = document.createElement("span");
      tag.className = "platform-tag";
      tag.style.setProperty("--tag-color", info.color);
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      tag.append(dot, document.createTextNode(info.name));
      tdPlatform.append(tag);
      tr.append(tdPlatform);

      const tdProduct = document.createElement("td");
      const product = document.createElement("div");
      product.className = "record-product";
      product.textContent = record.product;
      product.title = record.product;
      tdProduct.append(product);
      tr.append(tdProduct);

      const tdVariant = document.createElement("td");
      tdVariant.className = "record-variant";
      tdVariant.textContent = variantsLabel(record) || "默认规格";
      tr.append(tdVariant);

      const tdShop = document.createElement("td");
      tdShop.textContent = record.shop || "—";
      tr.append(tdShop);

      const tdPrice = document.createElement("td");
      const price = document.createElement("span");
      price.className = "record-price";
      if (lowestByProduct.get(record.product)?.id === record.id) price.classList.add("is-lowest");
      price.textContent = formatPrice(record.price);
      tdPrice.append(price);
      tr.append(tdPrice);

      const tdAction = document.createElement("td");
      const actions = document.createElement("div");
      actions.className = "row-actions";
      if (record.url) {
        const open = document.createElement("button");
        open.className = "row-action";
        open.type = "button";
        open.textContent = "打开";
        open.addEventListener("click", () => openExternal(record.url));
        actions.append(open);
      }
      const remove = document.createElement("button");
      remove.className = "row-action danger";
      remove.type = "button";
      remove.textContent = "删除";
      remove.addEventListener("click", () => removeRecord(record.id));
      actions.append(remove);
      tdAction.append(actions);
      tr.append(tdAction);

      els.recordBody.append(tr);
    });
  }

  async function removeRecord(id) {
    const record = records.find((item) => item.id === id);
    if (!record) return;
    if (!window.confirm(`删除这条记录？\n${record.product} · ${formatPrice(record.price)}`)) return;
    records = records.filter((item) => item.id !== id);
    try {
      await persistRecords();
      renderRecords();
      showToast("已删除一条记录");
    } catch {
      showToast("删除失败");
    }
  }

  async function clearRecords() {
    if (!records.length) return;
    if (!window.confirm(`清空全部 ${records.length} 条采集记录？此操作无法撤销。`)) return;
    records = [];
    try {
      await persistRecords();
      renderRecords();
      showToast("采集记录已清空");
    } catch {
      showToast("清空失败");
    }
  }

  async function openExternal(url) {
    if (!/^https?:\/\//i.test(String(url || ""))) return;
    try {
      if (bridge) await bridge.openExternal(url);
      else window.open(url, "_blank", "noopener");
    } catch {
      showToast("无法打开链接");
    }
  }

  async function showDataPath() {
    try {
      const path = bridge ? await bridge.dataPath() : FALLBACK_KEY;
      window.alert(`采集记录保存在：\n${path}`);
    } catch {
      showToast("无法获取数据位置");
    }
  }

  function bindEvents() {
    els.tabs.forEach((tab) => tab.addEventListener("click", () => showView(tab.dataset.view)));
    els.searchForm.addEventListener("submit", (event) => { event.preventDefault(); searchPlatforms(els.searchInput.value); });
    document.querySelectorAll("[data-capture]").forEach((button) => {
      button.addEventListener("click", () => capturePage(button.dataset.capture, button));
    });
    document.querySelectorAll("[data-refresh]").forEach((button) => {
      button.addEventListener("click", () => { const view = views[button.dataset.refresh]; if (view) view.reload(); });
    });
    els.captureForm.addEventListener("submit", (event) => { event.preventDefault(); saveCapture(); });
    els.closeDialogBtn.addEventListener("click", closeDialog);
    els.cancelCaptureBtn.addEventListener("click", closeDialog);
    els.captureDialog.addEventListener("click", (event) => {
      const rect = els.captureDialog.getBoundingClientRect();
      const outside = event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom;
      if (outside) closeDialog();
    });
    els.backToWorkspaceBtn.addEventListener("click", () => showView("workspace"));
    els.clearRecordsBtn.addEventListener("click", clearRecords);
    els.dataPathBtn.addEventListener("click", showDataPath);
  }

  async function init() {
    records = await loadRecords();
    bindEvents();
    Object.entries(views).forEach(([platform, view]) => bindWebview(platform, view));
    renderRecords();
    showView("workspace");
  }

  init().catch((error) => {
    console.error(error);
    showToast("桌面界面初始化失败");
  });
})();
