const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("priceLensDesktop", {
  loadRecords: () => ipcRenderer.invoke("records:load"),
  saveRecords: (records) => ipcRenderer.invoke("records:save", records),
  openExternal: (url) => ipcRenderer.invoke("shell:openExternal", url),
  dataPath: () => ipcRenderer.invoke("app:dataPath")
});
