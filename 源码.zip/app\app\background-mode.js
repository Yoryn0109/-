(() => {
  "use strict";

  const STORAGE_KEY = "pricelens-background-mode";
  const panes = document.getElementById("platformPanes");
  const panel = document.getElementById("backgroundPanel");
  const toggle = document.getElementById("togglePanesBtn");
  const showBtn = document.getElementById("backgroundShowBtn");

  if (!panes || !panel || !toggle) return;

  function readPreference() {
    try {
      return window.localStorage.getItem(STORAGE_KEY) !== "off";
    } catch {
      return true;
    }
  }

  function writePreference(background) {
    try {
      window.localStorage.setItem(STORAGE_KEY, background ? "on" : "off");
    } catch {
      // Ignore storage failures; the current session still works.
    }
  }

  function setBackground(background) {
    panes.classList.toggle("is-background", background);
    panel.hidden = !background;
    toggle.textContent = background ? "显示三平台" : "隐藏三平台";
    writePreference(background);
  }

  toggle.addEventListener("click", () => {
    setBackground(!panes.classList.contains("is-background"));
  });

  if (showBtn) {
    showBtn.addEventListener("click", () => setBackground(false));
  }

  window.PriceLensBackground = {
    show: () => setBackground(false),
    hide: () => setBackground(true),
    isHidden: () => panes.classList.contains("is-background")
  };

  setBackground(readPreference());
})();
