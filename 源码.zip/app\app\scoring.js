(() => {
  "use strict";

  const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));

  function parseCompactNumber(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : 0;
    const text = String(value || "").replace(/,/g, "").trim();
    if (!text) return 0;
    const match = text.match(/([\d.]+)\s*(万|亿)?/);
    if (!match) return 0;
    const base = Number(match[1]);
    if (!Number.isFinite(base)) return 0;
    if (match[2] === "万") return base * 10000;
    if (match[2] === "亿") return base * 100000000;
    return base;
  }

  function normalizeItem(item) {
    const rating = Number(item.rating) || 0;
    const sales = parseCompactNumber(item.sales);
    const comments = parseCompactNumber(item.comments || item.reviews);
    return {
      ...item,
      rating: rating > 0 && rating <= 5 ? rating : 0,
      sales,
      comments,
      official: Boolean(item.official)
    };
  }

  function scorePlatforms(platforms) {
    if (!platforms || typeof platforms !== "object") return [];
    const all = [];
    Object.keys(platforms).forEach((platform) => {
      const list = Array.isArray(platforms[platform]) ? platforms[platform] : [];
      list.forEach((raw) => {
        const item = normalizeItem(raw);
        // 写回原对象，保证 compare.js 保存/渲染的 platforms 里也带 score。
        Object.assign(raw, item, { platform });
        all.push(raw);
      });
    });

    if (!all.length) return [];

    const prices = all.map((item) => item.price).filter((price) => Number.isFinite(price) && price > 0);
    const minPrice = prices.length ? Math.min(...prices) : 0;
    const maxPrice = prices.length ? Math.max(...prices) : 0;
    const spread = Math.max(0, maxPrice - minPrice);

    all.forEach((item) => {
      const ratingScore = item.rating > 0
        ? clamp(item.rating / 5)
        : item.comments > 0
          ? clamp(Math.log10(item.comments + 1) / 5)
          : 0.5;
      const salesScore = item.sales > 0
        ? clamp(Math.log10(item.sales + 1) / 5)
        : item.comments > 0
          ? clamp(Math.log10(item.comments + 1) / 5)
          : 0.5;
      const priceScore = spread > 0
        ? clamp(1 - (item.price - minPrice) / spread)
        : 0.5;
      const officialScore = item.official ? 1 : 0.35;

      item.score = Math.round(
        (ratingScore * 0.45 + salesScore * 0.25 + priceScore * 0.2 + officialScore * 0.1) * 100
      );
      item.scoreParts = {
        rating: Math.round(ratingScore * 100),
        sales: Math.round(salesScore * 100),
        price: Math.round(priceScore * 100),
        official: Math.round(officialScore * 100)
      };
    });

    all.sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (left.price !== right.price) return left.price - right.price;
      return right.sales - left.sales;
    });
    return all;
  }

  function platformScores(platforms) {
    const all = scorePlatforms(platforms);
    const byPlatform = { jd: [], taobao: [], pdd: [] };
    all.forEach((item) => {
      if (!byPlatform[item.platform]) byPlatform[item.platform] = [];
      byPlatform[item.platform].push(item);
    });
    return byPlatform;
  }

  function best(all) {
    if (!Array.isArray(all) || !all.length) return null;
    return all[0];
  }

  function metricText(item) {
    if (!item) return "暂无";
    if (item.rating > 0) return `评分 ${item.rating.toFixed(1)}`;
    if (item.comments > 0) return `评价 ${formatCount(item.comments)}`;
    if (item.sales > 0) return `已售 ${formatCount(item.sales)}`;
    return "暂无评分/销量";
  }

  function formatCount(value) {
    const number = Number(value) || 0;
    if (number >= 100000000) return `${(number / 100000000).toFixed(1)}亿`;
    if (number >= 10000) return `${(number / 10000).toFixed(1)}万`;
    return String(Math.round(number));
  }

  window.PriceLensScore = {
    scorePlatforms,
    platformScores,
    best,
    metricText,
    formatCount
  };
})();
