(() => {
  "use strict";

  const panes = document.getElementById("platformPanes");
  const preparing = document.getElementById("preparingPanel");
  const views = {
    jd: document.getElementById("jdView"),
    taobao: document.getElementById("taobaoView"),
    pdd: document.getElementById("pddView")
  };

  if (!panes || !preparing || !views.jd) return;

  document.body.classList.add("login-checking");
  let checking = false;
  let poll = null;
  let firstCheckDone = false;

  function inspectPage(platform) {
    const visible = (node) => {
      if (!node || !node.isConnected) return false;
      const style = window.getComputedStyle(node);
      const rect = node.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
    };
    const href = location.href;
    if (/login|passport|signin|risk_handler|verify|captcha/i.test(href)) {
      return false;
    }

    const text = String(document.body ? document.body.innerText : "").slice(0, 15000);

    if (platform === "pdd" && /(手机登录|扫码登录|验证码登录)/.test(text)) {
      return false;
    }

    // If the page already contains product cards, it is usable even when the
    // platform still shows a "please login" link in its header. JD/Taobao
    // search results are readable without login; PDD still needs login.
    const productSelectors = {
      jd: "#J_goodsList li.gl-item, .gl-item, #J_goodsList [data-sku], li[data-sku]",
      taobao: ".items .item, #mainsrp-itemlist .item, div.item",
      pdd: "[data-goods-id], [data-goods_id], [data-goodsId], a[href*='goods.html'], .goods-item, [class*='goods']"
    };
    const productCount = document.querySelectorAll(productSelectors[platform] || "").length;
    const priceCount = (text.match(/[¥￥]\s*\d/g) || []).length;
    if (productCount >= 1 || priceCount >= 2) return true;

    if (platform === "pdd" && /(手机登录|扫码登录|验证码登录|请登录)/.test(text)) {
      return false;
    }

    if (platform === "jd") {
      if (/你好，请登录|请登录/.test(text) && !/我的京东|退出登录|京东会员/.test(text)) return false;
      const logged = document.querySelector("#ttbar-login .nickname, #ttbar-login .user-info, #ttbar-login a[href*='home.jd.com'], .user-info");
      if (logged && visible(logged)) return true;
    }

    if (platform === "taobao") {
      if (/亲，请登录|请登录/.test(text) && !/我的淘宝|退出登录|千牛/.test(text)) return false;
      const logged = document.querySelector(".site-nav-user, #J_SiteNavLogin .site-nav-login-info-nick, a[href*='i.taobao.com']");
      if (logged && visible(logged)) return true;
    }

    const loginButton = Array.from(document.querySelectorAll("a, button"))
      .find((node) => /^(登录|请登录|立即登录)$/.test(String(node.innerText || "").trim()) && visible(node));
    if (loginButton && !/退出登录|我的京东|我的淘宝/.test(text)) return false;

    return text.length > 20;
  }

  function highlightPlatform(platform) {
    const map = { jd: "pane-jd", taobao: "pane-taobao", pdd: "pane-pdd" };
    panes.querySelectorAll(".pane").forEach((pane) => pane.classList.remove("is-login-target"));
    if (platform && map[platform]) {
      const target = panes.querySelector(`.${map[platform]}`);
      if (target) {
        target.classList.add("is-login-target");
        target.scrollIntoView({ block: "nearest", inline: "nearest" });
      }
    }
  }

  function showPanes(platform) {
    panes.classList.remove("is-hidden");
    preparing.hidden = true;
    document.body.classList.remove("login-checking");
    document.body.classList.add("panes-visible");
    highlightPlatform(platform);
    if (!poll) poll = window.setInterval(checkAll, 2500);
  }

  function hidePanes() {
    panes.classList.add("is-hidden");
    preparing.hidden = true;
    document.body.classList.remove("login-checking");
    document.body.classList.remove("panes-visible");
    highlightPlatform(null);
    if (poll) {
      window.clearInterval(poll);
      poll = null;
    }
  }

  async function checkPlatform(platform) {
    const view = views[platform];
    if (!view) return false;
    try {
      const code = `(${inspectPage.toString()})(${JSON.stringify(platform)})`;
      return Boolean(await view.executeJavaScript(code, true));
    } catch {
      return false;
    }
  }

  async function checkAll() {
    if (checking) return;
    checking = true;
    try {
      const states = await Promise.all(
        Object.entries(views).map(async ([platform, view]) => {
          try {
            const code = `(${inspectPage.toString()})(${JSON.stringify(platform)})`;
            return Boolean(await view.executeJavaScript(code, true));
          } catch {
            // Not ready yet: unknown, do not reveal pages yet.
            return null;
          }
        })
      );

      if (states.some((state) => state === false)) {
        firstCheckDone = true;
        showPanes();
      } else if (states.every((state) => state === true)) {
        firstCheckDone = true;
        hidePanes();
      }
    } finally {
      checking = false;
    }
  }

  Object.values(views).forEach((view) => {
    if (!view) return;
    view.addEventListener("dom-ready", () => {
      window.setTimeout(checkAll, 700);
    });
    view.addEventListener("did-finish-load", () => {
      window.setTimeout(checkAll, 500);
    });
  });

  window.PriceLensLogin = {
    reveal: (platform) => showPanes(platform),
    hide: () => hidePanes(),
    check: (platform) => checkPlatform(platform),
    isHidden: () => panes.classList.contains("is-hidden")
  };

  window.setTimeout(checkAll, 1600);
  window.setTimeout(checkAll, 5000);
  window.setTimeout(() => {
    if (!firstCheckDone) showPanes();
  }, 9000);
})();
