(() => {
  "use strict";

  const STORAGE_KEY = "pricelens-compare-results-v1";
  const META = {
    jd: { name: "京东", color: "#df2f28" },
    taobao: { name: "淘宝", color: "#f25c1d" },
    pdd: { name: "拼多多", color: "#d9364a" }
  };

  const workspace = document.getElementById("workspaceView");
  const demoView = document.getElementById("demoView");
  const demoQuery = document.getElementById("demoQuery");
  const demoCount = document.getElementById("demoCount");
  const demoLowest = document.getElementById("demoLowest");
  const demoLowestNote = document.getElementById("demoLowestNote");
  const demoRecommendLabel = document.getElementById("demoRecommendLabel");
  const demoCards = document.getElementById("demoCards");
  const demoBars = document.getElementById("demoBars");
  const demoChart = document.getElementById("demoChart");
  const demoEmpty = document.getElementById("demoEmpty");
  const demoRefreshBtn = document.getElementById("demoRefreshBtn");

  const detailBackdrop = document.getElementById("detailBackdrop");
  const detailPanel = document.getElementById("platformDetail");
  const detailTitle = document.getElementById("detailTitle");
  const detailSub = document.getElementById("detailSub");
  const detailList = document.getElementById("detailList");
  const detailClose = document.getElementById("detailClose");
  const smartFilterBtn = document.getElementById("smartFilterBtn");
  const smartPanel = document.getElementById("smartPanel");
  const smartCategory = document.getElementById("smartCategory");
  const smartGroups = document.getElementById("smartGroups");
  const smartReset = document.getElementById("smartReset");

  if (!workspace || !demoView || !demoCards) return;

  const detailState = {
    items: [],
    recommended: null,
    mode: "score",
    category: "商品",
    groups: [],
    filters: {}
  };

  function formatPrice(value) {
    return `¥${Number(value).toFixed(2)}`;
  }

  function formatTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "未知时间";
    return date.toLocaleString("zh-CN", {
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function readDatabase() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list)
        ? list.filter((item) => item && item.platforms && typeof item.platforms === "object")
        : [];
    } catch {
      return [];
    }
  }

  function modeOf(result) {
    return result && ["score", "price", "sales"].includes(result.mode) ? result.mode : "score";
  }

  function labelOf(mode) {
    return window.PriceLensScore ? window.PriceLensScore.modeLabel(mode) : "推荐";
  }

  function prepareResult(result) {
    if (!result || !window.PriceLensScore) {
      return { all: [], sorted: [], recommended: null, mode: "score" };
    }
    const all = window.PriceLensScore.scorePlatforms(result.platforms);
    const mode = modeOf(result);
    const sorted = window.PriceLensScore.sortForMode(all, mode);
    return { all, sorted, recommended: sorted[0] || null, mode };
  }

  function topByPlatform(sorted) {
    const top = {};
    sorted.forEach((item) => {
      if (!top[item.platform]) top[item.platform] = item;
    });
    return top;
  }

  function openExternal(url) {
    if (!url) return;
    if (window.priceLensDesktop && typeof window.priceLensDesktop.openExternal === "function") {
      window.priceLensDesktop.openExternal(url);
    } else {
      window.open(url, "_blank", "noopener");
    }
  }

  function closeDetail() {
    if (detailPanel) detailPanel.hidden = true;
    if (detailBackdrop) detailBackdrop.hidden = true;
    document.body.classList.remove("detail-open");
  }

  const COLOR_WORDS = [
    "星宇橙色", "星宇橙", "深空黑色", "深空黑", "深蓝色", "深蓝",
    "远峰蓝色", "远峰蓝", "玫瑰金色", "玫瑰金", "午夜色", "星光色",
    "沙漠色", "原色钛金属", "钛金属色", "暗紫色", "雅川青", "雪域白",
    "曜石黑", "冰晶蓝", "流光金", "银色", "金色", "黑色", "白色",
    "蓝色", "紫色", "红色", "粉色", "绿色", "橙色", "黄色", "灰色",
    "青色", "米色", "棕色"
  ].sort((left, right) => right.length - left.length);

  const BRAND_RULES = [
    ["苹果", /iphone|苹果|apple/i],
    ["华为", /华为|huawei/i],
    ["小米", /小米|xiaomi/i],
    ["红米", /红米|redmi/i],
    ["OPPO", /oppo/i],
    ["vivo", /vivo/i],
    ["荣耀", /荣耀|honor/i],
    ["三星", /三星|samsung/i],
    ["一加", /一加|oneplus/i],
    ["realme", /realme|真我/i],
    ["iQOO", /iqoo/i],
    ["魅族", /魅族|meizu/i],
    ["努比亚", /努比亚|nubia/i]
  ];

  function detectCategory(title) {
    const text = String(title || "");
    if (/手机|iphone|苹果\s*\d|华为|小米|红米|oppo|vivo|荣耀|三星|一加|realme|iqoo|魅族|努比亚|\d{2,4}\s*(?:gb|tb).*(?:pro|max|plus|mini)/i.test(text)) return "手机";
    if (/笔记本|macbook|thinkpad|游戏本|拯救者|轻薄本/i.test(text)) return "笔记本";
    if (/平板|ipad|matepad/i.test(text)) return "平板";
    if (/耳机|airpods|蓝牙耳机|头戴式|入耳式/i.test(text)) return "耳机";
    if (/衣|裤|鞋|裙|外套|卫衣|t恤|衬衫/i.test(text)) return "服饰";
    if (/面包|零食|食品|饮料|牛奶|咖啡|茶|饼干|蛋糕/i.test(text)) return "食品";
    return "商品";
  }

  function detectBrand(title) {
    const text = String(title || "");
    const found = BRAND_RULES.find(([, pattern]) => pattern.test(text));
    return found ? found[0] : "";
  }

  function normalizeVersion(value) {
    const text = String(value || "").toLowerCase().replace(/\s+/g, " ").trim();
    if (text === "pro max") return "Pro Max";
    if (text === "pro") return "Pro";
    if (text === "plus") return "Plus";
    if (text === "ultra") return "Ultra";
    if (text === "mini") return "mini";
    if (text === "max") return "Max";
    return value;
  }

  function extractSmart(item) {
    const text = String(item.title || "");
    const category = detectCategory(text);
    const brand = detectBrand(text);

    let model = "";
    const iphone = text.match(/(?:iphone|苹果)\s*(?:iphone)?\s*(\d{1,2})\s*(pro\s*max|pro|plus|mini|air)?/i);
    if (iphone) {
      model = `iPhone ${iphone[1]}${iphone[2] ? ` ${normalizeVersion(iphone[2])}` : ""}`;
    }

    const versionMatch = text.match(/\b(pro\s*max|pro|plus|ultra|mini|max)\b/i);
    const version = versionMatch ? normalizeVersion(versionMatch[1]) : "";

    let storage = "";
    const capacities = [...text.matchAll(/(\d{1,4})\s*(tb|gb|g)\b/gi)];
    if (capacities.length) {
      const last = capacities[capacities.length - 1];
      const unit = last[2].toLowerCase() === "tb" ? "TB" : "GB";
      storage = `${last[1]}${unit}`;
    }

    let color = "";
    for (const word of COLOR_WORDS) {
      if (text.includes(word)) {
        color = word;
        break;
      }
    }

    let size = "";
    const sizeMatch = text.match(/(?:尺码|鞋码)?\s*(XXXL|XXL|XL|L|M|S)\b/i);
    if (sizeMatch) size = sizeMatch[1].toUpperCase();

    let weight = "";
    const weightMatch = text.match(/(\d+(?:\.\d+)?)\s*(kg|g|斤|克|ml|l)\b/i);
    if (weightMatch) weight = `${weightMatch[1]}${weightMatch[2].toLowerCase()}`;

    let flavor = "";
    const flavorMatch = text.match(/([\u4e00-\u9fa5]{1,6}味)/);
    if (flavorMatch) flavor = flavorMatch[1];

    return { category, brand, model, version, storage, color, size, weight, flavor };
  }

  function categoryForItems(items) {
    const counts = {};
    items.forEach((item) => {
      const category = extractSmart(item).category;
      counts[category] = (counts[category] || 0) + 1;
    });
    return Object.entries(counts).sort((left, right) => right[1] - left[1])[0]?.[0] || "商品";
  }

  function groupDefinitions(category) {
    if (category === "手机") {
      return [["brand", "品牌"], ["model", "型号"], ["storage", "内存 / 容量"], ["color", "颜色"], ["version", "版本"]];
    }
    if (category === "笔记本" || category === "平板") {
      return [["brand", "品牌"], ["storage", "内存 / 容量"], ["color", "颜色"]];
    }
    if (category === "耳机") {
      return [["brand", "品牌"], ["color", "颜色"], ["version", "版本"]];
    }
    if (category === "服饰") {
      return [["color", "颜色"], ["size", "尺码"]];
    }
    if (category === "食品") {
      return [["weight", "规格"], ["flavor", "口味"]];
    }
    return [["brand", "品牌"], ["color", "颜色"], ["storage", "规格"], ["version", "版本"]];
  }

  function buildGroups(items, category) {
    return groupDefinitions(category)
      .map(([key, label]) => {
        const counts = new Map();
        items.forEach((item) => {
          const value = item._smart ? item._smart[key] : "";
          if (value) counts.set(value, (counts.get(value) || 0) + 1);
        });
        const values = [...counts.entries()]
          .sort((left, right) => right[1] - left[1])
          .map(([value, count]) => ({ value, count }));
        return { key, label, values };
      })
      .filter((group) => group.values.length > 0);
  }

  function detailMatches(item) {
    return Object.entries(detailState.filters).every(([key, value]) => {
      return !value || (item._smart && item._smart[key] === value);
    });
  }

  function renderDetailList() {
    const total = detailState.items.length;
    const filtered = detailState.items.filter(detailMatches);
    detailSub.textContent = detailState.capturedAt
      ? `${labelOf(detailState.mode)} · ${filtered.length}/${total} 件商品 · ${formatTime(detailState.capturedAt)}`
      : "还没有数据";
    detailList.replaceChildren();

    if (!filtered.length) {
      const empty = document.createElement("p");
      empty.className = "detail-empty";
      empty.textContent = total ? "没有符合当前分类的商品，试试重置分类。" : "这个平台本次没有读取到商品。";
      detailList.append(empty);
      return;
    }

    filtered.forEach((item) => {
      const card = document.createElement("article");
      card.className = "detail-item";

      if (detailState.recommended && item.url === detailState.recommended.url) {
        const badge = document.createElement("span");
        badge.className = "detail-badge";
        badge.textContent = labelOf(detailState.mode);
        card.append(badge);
      }

      const top = document.createElement("div");
      top.className = "detail-item-top";
      const price = document.createElement("strong");
      price.className = "detail-price";
      price.textContent = formatPrice(item.price);
      const rating = document.createElement("span");
      rating.className = "detail-rating";
      rating.textContent = window.PriceLensScore.metricText(item);
      top.append(price, rating);

      const title = document.createElement("h3");
      title.className = "detail-item-title";
      title.textContent = item.title;
      title.title = item.title;

      const shop = document.createElement("p");
      shop.className = "detail-shop";
      const score = item.score != null ? `综合分 ${item.score} · ` : "";
      const sales = item.sales ? `已售 ${window.PriceLensScore.formatCount(item.sales)} · ` : "";
      shop.textContent = `${score}${sales}店铺：${item.shop || "未提取"}`;

      const actions = document.createElement("div");
      actions.className = "detail-actions";
      const shopLink = document.createElement("button");
      shopLink.type = "button";
      shopLink.className = "ghost-button detail-link";
      shopLink.textContent = "进入店铺";
      shopLink.disabled = !item.shopUrl;
      shopLink.addEventListener("click", () => openExternal(item.shopUrl));
      const productLink = document.createElement("button");
      productLink.type = "button";
      productLink.className = "ghost-button detail-link";
      productLink.textContent = "查看商品";
      productLink.addEventListener("click", () => openExternal(item.url));
      actions.append(shopLink, productLink);

      card.append(top, title, shop, actions);
      detailList.append(card);
    });
  }

  function renderSmartGroups() {
    smartCategory.textContent = `识别类型：${detailState.category}`;
    smartGroups.replaceChildren();

    if (!detailState.groups.length) {
      const empty = document.createElement("p");
      empty.className = "smart-empty";
      empty.textContent = "未识别到可分类的型号、内存、颜色等属性，可以直接查看全部商品。";
      smartGroups.append(empty);
      return;
    }

    detailState.groups.forEach((group) => {
      const wrap = document.createElement("div");
      wrap.className = "smart-group";
      const label = document.createElement("div");
      label.className = "smart-group-label";
      label.textContent = group.label;

      const chips = document.createElement("div");
      chips.className = "smart-chips";
      const all = document.createElement("button");
      all.type = "button";
      all.className = `smart-chip${detailState.filters[group.key] ? "" : " is-active"}`;
      all.textContent = "全部";
      all.addEventListener("click", () => {
        delete detailState.filters[group.key];
        renderSmartGroups();
        renderDetailList();
      });
      chips.append(all);

      group.values.forEach(({ value, count }) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = `smart-chip${detailState.filters[group.key] === value ? " is-active" : ""}`;
        chip.append(document.createTextNode(value));
        const countNode = document.createElement("small");
        countNode.textContent = String(count);
        chip.append(countNode);
        chip.addEventListener("click", () => {
          if (detailState.filters[group.key] === value) delete detailState.filters[group.key];
          else detailState.filters[group.key] = value;
          renderSmartGroups();
          renderDetailList();
        });
        chips.append(chip);
      });

      wrap.append(label, chips);
      smartGroups.append(wrap);
    });
  }

  function openDetail(platform) {
    const result = readDatabase()[0] || null;
    const { sorted, recommended, mode } = prepareResult(result);
    const meta = META[platform];
    const items = sorted
      .filter((item) => item.platform === platform)
      .map((item) => ({ ...item, _smart: extractSmart(item) }));

    detailState.items = items;
    detailState.recommended = recommended;
    detailState.mode = mode;
    detailState.capturedAt = result ? result.capturedAt : null;
    detailState.category = categoryForItems(items);
    detailState.groups = buildGroups(items, detailState.category);
    detailState.filters = {};

    detailTitle.textContent = meta ? meta.name : "平台明细";
    smartPanel.hidden = true;
    if (smartFilterBtn) smartFilterBtn.disabled = !items.length;
    renderSmartGroups();
    renderDetailList();

    detailPanel.hidden = false;
    detailBackdrop.hidden = false;
    document.body.classList.add("detail-open");
  }

  function renderDemo() {
    const result = readDatabase()[0] || null;
    const { all, sorted, recommended, mode } = prepareResult(result);
    const top = topByPlatform(sorted);

    demoRecommendLabel.textContent = labelOf(mode);

    if (!result || !all.length) {
      demoQuery.textContent = "—";
      demoCount.textContent = "0";
      demoLowest.textContent = "—";
      demoLowestNote.textContent = "还没有数据";
      demoCards.replaceChildren();
      demoBars.replaceChildren();
      demoCards.hidden = true;
      demoChart.hidden = true;
      demoEmpty.hidden = false;
      return;
    }

    demoEmpty.hidden = true;
    demoCards.hidden = false;
    demoChart.hidden = false;
    demoQuery.textContent = result.query || "—";
    demoCount.textContent = String(all.length);
    demoLowest.textContent = recommended ? formatPrice(recommended.price) : "—";
    demoLowestNote.textContent = recommended
      ? `综合分 ${recommended.score} · ${window.PriceLensScore.metricText(recommended)}`
      : "没有可推荐商品";

    demoCards.replaceChildren();
    ["jd", "taobao", "pdd"].forEach((platform) => {
      const meta = META[platform];
      const item = top[platform];
      const card = document.createElement("article");
      card.className = `demo-card${recommended && item && item.url === recommended.url ? " is-lowest" : ""}`;
      card.style.setProperty("--brand-color", meta.color);

      if (!item) {
        card.classList.add("is-empty");
        const empty = document.createElement("p");
        empty.className = "real-empty-text";
        empty.textContent = "这个平台本次没有商品。";
        card.append(empty);
        demoCards.append(card);
        return;
      }

      if (recommended && item.url === recommended.url) {
        const badge = document.createElement("span");
        badge.className = "demo-lowest-badge";
        badge.textContent = labelOf(mode);
        card.append(badge);
      }

      const topRow = document.createElement("div");
      topRow.className = "demo-card-top";
      const platformName = document.createElement("span");
      platformName.className = "demo-platform";
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      platformName.append(dot, document.createTextNode(meta.name));
      const tag = document.createElement("span");
      tag.className = "demo-tag";
      tag.textContent = "本次";
      if (recommended && item.url === recommended.url) tag.hidden = true;
      topRow.append(platformName, tag);

      const price = document.createElement("div");
      price.className = "demo-price";
      price.innerHTML = `<small>¥</small>${Number(item.price).toFixed(2)}`;

      const metaRow = document.createElement("div");
      metaRow.className = "demo-meta";
      const shop = document.createElement("span");
      shop.className = "demo-shop";
      shop.textContent = item.shop || "店铺未提取";
      const sales = document.createElement("span");
      sales.className = "demo-sales";
      sales.textContent = item.sales
        ? `已售 ${window.PriceLensScore.formatCount(item.sales)}`
        : window.PriceLensScore.metricText(item);
      metaRow.append(shop, sales);

      const scoreRow = document.createElement("div");
      scoreRow.className = "demo-score-row";
      const score = document.createElement("span");
      score.className = "demo-score-pill";
      score.textContent = `综合分 ${item.score}`;
      const metric = document.createElement("span");
      metric.className = "demo-score-metric";
      metric.textContent = window.PriceLensScore.metricText(item);
      scoreRow.append(score, metric);

      const foot = document.createElement("div");
      foot.className = "demo-card-foot";
      const record = document.createElement("span");
      record.textContent = `保存于 ${formatTime(result.capturedAt)}`;
      const detail = document.createElement("span");
      detail.textContent = "点击查看明细";
      foot.append(record, detail);

      card.classList.add("is-clickable");
      card.tabIndex = 0;
      card.setAttribute("role", "button");
      card.setAttribute("aria-label", `查看${meta.name}商品明细`);
      card.addEventListener("click", () => openDetail(platform));
      card.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          openDetail(platform);
        }
      });

      card.append(topRow, price, metaRow, scoreRow, foot);
      demoCards.append(card);
    });

    demoBars.replaceChildren();
    const offers = ["jd", "taobao", "pdd"].map((platform) => top[platform]).filter(Boolean);
    const max = Math.max(...offers.map((item) => item.price), 1);
    offers.forEach((item) => {
      const row = document.createElement("div");
      row.className = "demo-bar-row";
      row.style.setProperty("--brand-color", META[item.platform].color);

      const label = document.createElement("span");
      label.className = "demo-bar-label";
      const dot = document.createElement("i");
      dot.setAttribute("aria-hidden", "true");
      label.append(dot, document.createTextNode(META[item.platform].name));

      const track = document.createElement("div");
      track.className = "demo-bar-track";
      const fill = document.createElement("div");
      fill.className = "demo-bar-fill";
      fill.style.width = `${Math.max(8, (item.price / max) * 100)}%`;
      track.append(fill);

      const price = document.createElement("span");
      price.className = "demo-bar-price";
      price.textContent = formatPrice(item.price);

      row.append(label, track, price);
      demoBars.append(row);
    });
  }

  if (demoRefreshBtn) demoRefreshBtn.addEventListener("click", renderDemo);
  if (detailClose) detailClose.addEventListener("click", closeDetail);
  if (detailBackdrop) detailBackdrop.addEventListener("click", closeDetail);
  if (smartFilterBtn) {
    smartFilterBtn.addEventListener("click", () => {
      smartPanel.hidden = !smartPanel.hidden;
      if (!smartPanel.hidden) renderSmartGroups();
    });
  }
  if (smartReset) {
    smartReset.addEventListener("click", () => {
      detailState.filters = {};
      renderSmartGroups();
      renderDetailList();
    });
  }
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && detailPanel && !detailPanel.hidden) closeDetail();
  });

  window.addEventListener("pricelens:data-updated", renderDemo);
  window.addEventListener("pricelens:data-cleared", renderDemo);

  window.PriceLensOverview = {
    refresh: renderDemo
  };

  renderDemo();
})();
