(() => {
  "use strict";

  const KEY = "pricelens-compare-results-v1";

  function clearDatabase() {
    try {
      window.localStorage.removeItem(KEY);
    } catch {
      // Ignore storage failures.
    }
  }

  // Startup clear: guarantees no old prices are shown after a crash or forced exit.
  clearDatabase();

  window.addEventListener("beforeunload", clearDatabase);
  window.addEventListener("pagehide", clearDatabase);
  window.addEventListener("unload", clearDatabase);
})();
