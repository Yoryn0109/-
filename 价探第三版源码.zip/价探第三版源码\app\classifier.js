(() => {
  "use strict";

  const COLORS = [
    "星宇橙色", "星宇橙", "深空黑色", "深空黑", "深蓝色", "深蓝",
    "远峰蓝色", "远峰蓝", "玫瑰金色", "玫瑰金", "午夜色", "星光色",
    "沙漠色", "原色钛金属", "钛金属色", "暗紫色", "雅川青", "雪域白",
    "曜石黑", "冰晶蓝", "流光金", "银色", "金色", "黑色", "白色",
    "蓝色", "紫色", "红色", "粉色", "绿色", "橙色", "黄色", "灰色",
    "青色", "米色", "棕色"
  ];

  const BRANDS = [
    ["苹果", /iphone|苹果|apple/i],
    ["华为", /华为|huawei/i],
    ["小米", /小米|xiaomi/i],
    ["红米", /红米|redmi/i],
    ["OPPO", /oppo/i],
    ["vivo", /vivo/i],
    ["荣耀", /荣耀|honor/i],
    ["三星", /三星|samsung/i],
    ["一加", /一加|oneplus/i],
    ["realme", /realme|真我/i],
    ["iQOO", /iqoo/i],
    ["魅族", /魅族|meizu/i],
    ["努比亚", /努比亚|nubia/i]
  ];

  function detectCategory(query) {
    if (/手机|iphone|苹果\s*\d|华为|小米|红米|oppo|vivo|荣耀|三星|一加|realme|iqoo|魅族|努比亚|mate|pura/i.test(query)) return "手机";
    if (/笔记本|macbook|thinkpad|游戏本|拯救者|轻薄本|book/i.test(query)) return "笔记本";
    if (/平板|ipad|matepad/i.test(query)) return "平板";
    if (/耳机|airpods|蓝牙耳机|头戴式|入耳式/i.test(query)) return "耳机";
    if (/衣|裤|鞋|裙|外套|卫衣|t恤|衬衫/i.test(query)) return "服饰";
    if (/面包|零食|食品|饮料|牛奶|咖啡|茶|饼干|蛋糕/i.test(query)) return "食品";
    return "商品";
  }

  function detectBrand(query) {
    const found = BRANDS.find(([, pattern]) => pattern.test(query));
    return found ? found[0] : "";
  }

  const ACCESSORY_RE = /手机壳|保护壳|保护套|钢化膜|贴膜|水凝膜|镜头膜|数据线|充电线|充电器|充电头|充电宝|移动电源|手机支架|车载支架|挂绳|指环|转接头|转换器|耳机|表带|防尘塞|卡托|取卡针|贴纸|保护膜|外壳|后盖|维修|配件|适用|兼容|收纳包/i;

  function isRelevantItem(item, category, query) {
    const title = String(item && item.title || "");
    const price = Number(item && item.price) || 0;

    if (category === "手机") {
      if (ACCESSORY_RE.test(title)) return false;
      const proMax = /pro\s*max|promax/i.test(query);
      const iphone = /iphone|苹果/i.test(query);
      const floor = proMax ? 3000 : iphone ? 1200 : 300;
      if (price < floor) return false;
      return /iphone|苹果|手机|华为|小米|红米|oppo|vivo|荣耀|三星|一加|realme|iqoo|魅族|努比亚|5g|全网通|双卡/i.test(title);
    }

    if (category === "笔记本") {
      if (/电脑包|鼠标|键盘膜|贴膜|支架|充电器|电源适配器|内存条|硬盘盒|扩展坞/i.test(title)) return false;
      if (price < 800) return false;
      return /笔记本|macbook|thinkpad|游戏本|轻薄本|book/i.test(title);
    }

    if (category === "平板") {
      if (/保护壳|保护套|钢化膜|贴膜|触控笔|键盘|支架|充电器/i.test(title)) return false;
      if (price < 300) return false;
      return /平板|ipad|matepad/i.test(title);
    }

    if (category === "耳机") {
      if (/耳机套|耳罩|保护套|数据线|充电线|配件/i.test(title)) return false;
      if (price < 15) return false;
      return /耳机|airpods|蓝牙|降噪/i.test(title);
    }

    return true;
  }

  function filterItems(items, category, query) {
    return (Array.isArray(items) ? items : []).filter((item) => isRelevantItem(item, category, query));
  }

  function unique(values) {
    return [...new Set(values.filter(Boolean))];
  }

  function addGroup(groups, key, label, values) {
    const clean = unique(values);
    if (clean.length) groups.push({ key, label, values: clean });
  }

  function inferStorage(query) {
    const matches = [...query.matchAll(/(\d{1,4})\s*(tb|gb|g)\b/gi)];
    if (!matches.length) return "";
    const last = matches[matches.length - 1];
    return `${last[1]}${last[2].toLowerCase() === "tb" ? "TB" : "GB"}`;
  }

  function inferColor(query) {
    return COLORS.find((color) => query.includes(color)) || "";
  }

  function inferModel(query, category) {
    if (category !== "手机") return "";
    const iphone = query.match(/(?:iphone|苹果)\s*(?:iphone)?\s*(\d{1,2})\s*(pro\s*max|pro|plus|mini|air)?/i);
    if (iphone) {
      const suffix = iphone[2]
        ? iphone[2].replace(/\s+/g, " ").replace(/\b\w/g, (char) => char.toUpperCase())
        : "";
      return `iPhone ${iphone[1]}${suffix ? ` ${suffix}` : ""}`;
    }
    return "";
  }

  const IPHONE_DATA = {
    "17": {
      models: ["iPhone 17", "iPhone Air", "iPhone 17 Pro", "iPhone 17 Pro Max"],
      storage: {
        base: ["256GB", "512GB"],
        air: ["256GB", "512GB", "1TB"],
        pro: ["256GB", "512GB", "1TB"],
        promax: ["256GB", "512GB", "1TB", "2TB"]
      },
      colors: {
        base: ["薰衣草紫色", "鼠尾草绿色", "雾蓝色", "白色", "黑色"],
        air: ["天蓝色", "浅金色", "云白色", "深空黑色"],
        pro: ["银色", "星宇橙色", "深蓝色"],
        promax: ["银色", "星宇橙色", "深蓝色"]
      }
    },
    "16": {
      models: ["iPhone 16", "iPhone 16 Plus", "iPhone 16 Pro", "iPhone 16 Pro Max"],
      storage: {
        base: ["128GB", "256GB", "512GB"],
        plus: ["128GB", "256GB", "512GB"],
        pro: ["128GB", "256GB", "512GB", "1TB"],
        promax: ["256GB", "512GB", "1TB"]
      },
      colors: {
        base: ["黑色", "白色", "粉色", "深青色", "群青色"],
        plus: ["黑色", "白色", "粉色", "深青色", "群青色"],
        pro: ["黑色钛金属", "白色钛金属", "自然钛金属", "沙漠色钛金属"],
        promax: ["黑色钛金属", "白色钛金属", "自然钛金属", "沙漠色钛金属"]
      }
    },
    "15": {
      models: ["iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max"],
      storage: {
        base: ["128GB", "256GB", "512GB"],
        plus: ["128GB", "256GB", "512GB"],
        pro: ["128GB", "256GB", "512GB", "1TB"],
        promax: ["256GB", "512GB", "1TB"]
      },
      colors: {
        base: ["黑色", "蓝色", "绿色", "黄色", "粉色"],
        plus: ["黑色", "蓝色", "绿色", "黄色", "粉色"],
        pro: ["黑色钛金属", "白色钛金属", "蓝色钛金属", "自然钛金属"],
        promax: ["黑色钛金属", "白色钛金属", "蓝色钛金属", "自然钛金属"]
      }
    },
    "14": {
      models: ["iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro", "iPhone 14 Pro Max"],
      storage: {
        base: ["128GB", "256GB", "512GB"],
        plus: ["128GB", "256GB", "512GB"],
        pro: ["128GB", "256GB", "512GB", "1TB"],
        promax: ["128GB", "256GB", "512GB", "1TB"]
      },
      colors: {
        base: ["蓝色", "紫色", "黄色", "午夜色", "星光色", "红色"],
        plus: ["蓝色", "紫色", "黄色", "午夜色", "星光色", "红色"],
        pro: ["深空黑色", "银色", "金色", "暗紫色"],
        promax: ["深空黑色", "银色", "金色", "暗紫色"]
      }
    }
  };

  function iphoneVariant(text) {
    if (/pro\s*max/i.test(text)) return "promax";
    if (/\bpro\b/i.test(text)) return "pro";
    if (/\bair\b/i.test(text)) return "air";
    if (/\bplus\b/i.test(text)) return "plus";
    return "base";
  }

  function phoneGroups(query, selected) {
    const groups = [];
    const iphone = query.match(/(?:iphone|苹果)\s*(?:iphone)?\s*(\d{1,2})\s*(pro\s*max|pro|plus|air|mini)?/i);

    if (iphone) {
      const generation = iphone[1];
      const knowledge = IPHONE_DATA[generation];
      const variant = iphoneVariant(query);

      if (knowledge) {
        addGroup(groups, "model", "型号", knowledge.models);
        addGroup(groups, "storage", "内存 / 容量", knowledge.storage[variant] || knowledge.storage.base);
        addGroup(groups, "color", "颜色", knowledge.colors[variant] || knowledge.colors.base);
      } else {
        addGroup(groups, "model", "型号", [`iPhone ${generation}`, `iPhone ${generation} Pro`, `iPhone ${generation} Pro Max`]);
        addGroup(groups, "storage", "内存 / 容量", ["128GB", "256GB", "512GB", "1TB"]);
        addGroup(groups, "color", "颜色", COLORS.slice(0, 12));
      }

      const model = inferModel(query, "手机");
      if (model && groups.some((group) => group.key === "model" && group.values.includes(model))) {
        selected.model = model;
      }
      const storage = inferStorage(query);
      if (storage && groups.some((group) => group.key === "storage" && group.values.includes(storage))) {
        selected.storage = storage;
      }
      const color = inferColor(query);
      if (color && groups.some((group) => group.key === "color" && group.values.includes(color))) {
        selected.color = color;
      }
      return groups;
    }

    const brand = detectBrand(query);
    addGroup(groups, "brand", "品牌", ["华为", "小米", "红米", "OPPO", "vivo", "荣耀", "三星", "一加", "realme", "iQOO"]);
    if (brand) selected.brand = brand;
    addGroup(groups, "storage", "内存 / 容量", ["128GB", "256GB", "512GB", "1TB"]);
    addGroup(groups, "color", "颜色", COLORS.slice(0, 14));
    return groups;
  }

  function laptopGroups(query, selected) {
    const groups = [];
    const brand = detectBrand(query);
    addGroup(groups, "brand", "品牌", ["苹果", "联想", "华为", "小米", "惠普", "戴尔", "华硕", "机械革命"]);
    if (brand) selected.brand = brand;
    addGroup(groups, "memory", "内存", ["16GB", "32GB", "64GB"]);
    addGroup(groups, "storage", "硬盘", ["512GB", "1TB", "2TB"]);
    addGroup(groups, "size", "屏幕", ["14英寸", "15.6英寸", "16英寸"]);
    addGroup(groups, "color", "颜色", ["银色", "灰色", "黑色", "白色"]);
    return groups;
  }

  function tabletGroups(query, selected) {
    const groups = [];
    const brand = detectBrand(query);
    addGroup(groups, "brand", "品牌", ["苹果", "华为", "小米", "三星", "联想"]);
    if (brand) selected.brand = brand;
    addGroup(groups, "storage", "内存 / 容量", ["128GB", "256GB", "512GB", "1TB"]);
    addGroup(groups, "size", "尺寸", ["11英寸", "12.9英寸", "13英寸"]);
    addGroup(groups, "color", "颜色", ["银色", "灰色", "黑色", "蓝色"]);
    return groups;
  }

  function headphoneGroups(query, selected) {
    const groups = [];
    const brand = detectBrand(query);
    addGroup(groups, "brand", "品牌", ["苹果", "华为", "小米", "索尼", "漫步者", "Bose"]);
    if (brand) selected.brand = brand;
    addGroup(groups, "type", "类型", ["入耳式", "头戴式", "降噪", "无线"]);
    addGroup(groups, "color", "颜色", ["黑色", "白色", "银色", "蓝色", "粉色"]);
    return groups;
  }

  function clothingGroups(query) {
    const groups = [];
    addGroup(groups, "size", "尺码", ["S", "M", "L", "XL", "XXL", "XXXL"]);
    addGroup(groups, "color", "颜色", ["黑色", "白色", "蓝色", "灰色", "红色", "粉色", "绿色"]);
    return groups;
  }

  function foodGroups(query, selected) {
    const groups = [];
    addGroup(groups, "weight", "规格", ["500g", "1kg", "2kg", "整箱"]);
    addGroup(groups, "flavor", "口味", ["原味", "巧克力", "奶油", "香辣", "甜味", "咸味"]);
    return groups;
  }

  function buildPlan(query) {
    const text = String(query || "").trim();
    const category = detectCategory(text);
    const selected = {};
    let groups = [];
    if (category === "手机") groups = phoneGroups(text, selected);
    else if (category === "笔记本") groups = laptopGroups(text, selected);
    else if (category === "平板") groups = tabletGroups(text, selected);
    else if (category === "耳机") groups = headphoneGroups(text, selected);
    else if (category === "服饰") groups = clothingGroups(text);
    else if (category === "食品") groups = foodGroups(text, selected);
    else {
      const color = inferColor(text);
      if (color) selected.color = color;
      addGroup(groups, "color", "颜色", COLORS.slice(0, 12));
    }

    // Remove duplicate/covered selections from inferred state.
    Object.keys(selected).forEach((key) => {
      if (!groups.some((group) => group.key === key)) delete selected[key];
    });
    return { query: text, category, groups, selected };
  }

  function extractItemAttrs(title) {
    const text = String(title || "");
    const category = detectCategory(text);
    const brand = detectBrand(text);

    let model = "";
    const iphone = text.match(/(?:iphone|苹果)\s*(?:iphone)?\s*(\d{1,2})\s*(pro\s*max|pro|plus|mini|air)?/i);
    if (iphone) {
      const suffix = iphone[2]
        ? iphone[2].replace(/\s+/g, " ").replace(/\b\w/g, (char) => char.toUpperCase())
        : "";
      model = `iPhone ${iphone[1]}${suffix ? ` ${suffix}` : ""}`;
    }

    let version = "";
    const versionMatch = text.match(/\b(pro\s*max|pro|plus|ultra|mini|max)\b/i);
    if (versionMatch) {
      version = versionMatch[1].replace(/\s+/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
    }

    let storage = "";
    const capacities = [...text.matchAll(/(\d{1,4})\s*(tb|gb|g)\b/gi)];
    if (capacities.length) {
      const last = capacities[capacities.length - 1];
      storage = `${last[1]}${last[2].toLowerCase() === "tb" ? "TB" : "GB"}`;
    }

    const color = COLORS.find((word) => text.includes(word)) || "";

    let size = "";
    const sizeMatch = text.match(/(XXXL|XXL|XL|L|M|S)\b/i);
    if (sizeMatch) size = sizeMatch[1].toUpperCase();

    let weight = "";
    const weightMatch = text.match(/(\d+(?:\.\d+)?)\s*(kg|g|斤|克|ml|l)\b/i);
    if (weightMatch) weight = `${weightMatch[1]}${weightMatch[2].toLowerCase()}`;

    let flavor = "";
    const flavorMatch = text.match(/([\u4e00-\u9fa5]{1,6}味)/);
    if (flavorMatch) flavor = flavorMatch[1];

    return { category, brand, model, version, storage, color, size, weight, flavor };
  }

  function groupDefsFor(category) {
    if (category === "手机") {
      return [["brand", "品牌"], ["model", "型号"], ["storage", "内存 / 容量"], ["color", "颜色"], ["version", "版本"]];
    }
    if (category === "笔记本") {
      return [["brand", "品牌"], ["storage", "内存 / 硬盘"], ["size", "屏幕"], ["color", "颜色"]];
    }
    if (category === "平板") {
      return [["brand", "品牌"], ["storage", "内存 / 容量"], ["size", "尺寸"], ["color", "颜色"]];
    }
    if (category === "耳机") {
      return [["brand", "品牌"], ["version", "类型"], ["color", "颜色"]];
    }
    if (category === "服饰") {
      return [["size", "尺码"], ["color", "颜色"]];
    }
    if (category === "食品") {
      return [["weight", "规格"], ["flavor", "口味"]];
    }
    return [["brand", "品牌"], ["color", "颜色"], ["storage", "规格"], ["version", "版本"]];
  }

  function buildFromItems(query, items) {
    const text = String(query || "").trim();
    const extracted = (items || [])
      .filter((item) => item && item.title)
      .map((item) => extractItemAttrs(item.title));

    const categoryCounts = {};
    extracted.forEach((item) => {
      categoryCounts[item.category] = (categoryCounts[item.category] || 0) + 1;
    });
    const mostCommonItemCategory = Object.entries(categoryCounts)
      .sort((left, right) => right[1] - left[1])[0]?.[0] || "商品";
    const queryCategory = detectCategory(text);
    const category = queryCategory !== "商品" ? queryCategory : mostCommonItemCategory;

    const groups = groupDefsFor(category)
      .map(([key, label]) => {
        const counts = new Map();
        extracted.forEach((item) => {
          const value = item[key];
          if (value) counts.set(value, (counts.get(value) || 0) + 1);
        });
        return {
          key,
          label,
          values: [...counts.entries()]
            .sort((left, right) => right[1] - left[1])
            .map(([value, count]) => ({ value, count }))
        };
      })
      .filter((group) => group.values.length > 0);

    const selected = {};
    groups.forEach((group) => {
      const matched = group.values.find((value) => text.toLowerCase().includes(value.value.toLowerCase()));
      if (matched) selected[group.key] = matched.value;
    });

    return { query: text, category, groups, selected };
  }

  function exactInBase(base, value) {
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`(^|\\s)${escaped}(\\s|$)`, "i").test(base);
  }

  function modelExactInBase(base, value) {
    const baseLower = base.toLowerCase();
    const valueLower = value.toLowerCase();
    const index = baseLower.indexOf(valueLower);
    if (index < 0) return false;
    const after = baseLower.slice(index + valueLower.length);
    return !/^\s*(pro|max|plus|mini|air)\b/.test(after);
  }

  function stripColors(base) {
    let result = base;
    COLORS.forEach((color) => {
      result = result.split(color).join(" ");
    });
    return result.replace(/\s+/g, " ").trim();
  }

  function buildSearchQuery(baseQuery, selections) {
    let base = String(baseQuery || "").trim();
    const extras = [];
    const seen = new Set();

    Object.entries(selections || {}).forEach(([key, value]) => {
      const text = String(value || "").trim();
      if (!text || text === "不限" || seen.has(text)) return;
      seen.add(text);

      if (key === "brand") {
        if (text === "苹果" && /iphone|apple|苹果/i.test(base)) return;
        if (base.includes(text)) return;
        extras.push(text);
        return;
      }

      if (key === "model") {
        if (modelExactInBase(base, text)) return;
        base = base.replace(/(?:iphone|苹果)\s*(?:iphone)?\s*\d{1,2}\s*(?:pro\s*max|pro|plus|mini|air)?/ig, " ").trim();
        extras.push(text);
        return;
      }

      if (key === "storage") {
        if (base.toLowerCase().includes(text.toLowerCase())) return;
        base = base.replace(/\b\d{1,4}\s*(?:gb|tb|g)\b/ig, " ").replace(/\s+/g, " ").trim();
        extras.push(text);
        return;
      }

      if (key === "memory") {
        if (base.toLowerCase().includes(text.toLowerCase())) return;
        base = base.replace(/\b\d{2,3}\s*gb\b/ig, " ").replace(/\s+/g, " ").trim();
        extras.push(text);
        return;
      }

      if (key === "color") {
        if (base.includes(text)) return;
        base = stripColors(base);
        extras.push(text);
        return;
      }

      if (key === "size") {
        if (base.includes(text)) return;
        base = base.replace(/\b\d+(?:\.\d+)?\s*英寸\b/ig, " ").replace(/\s+/g, " ").trim();
        extras.push(text);
        return;
      }

      if (key === "weight") {
        if (base.includes(text)) return;
        base = base.replace(/\b\d+(?:\.\d+)?\s*(?:kg|g|斤|克)\b/ig, " ").replace(/\s+/g, " ").trim();
        extras.push(text);
        return;
      }

      if (base.includes(text)) return;
      extras.push(text);
    });

    return [base, ...extras].join(" ").replace(/\s+/g, " ").trim();
  }

  const modal = document.getElementById("classifyModal");
  const backdrop = document.getElementById("classifyBackdrop");
  const queryText = document.getElementById("classifyQueryText");
  const categoryText = document.getElementById("classifyCategory");
  const groupsBox = document.getElementById("classifyGroups");
  const closeBtn = document.getElementById("classifyClose");
  const cancelBtn = document.getElementById("classifyCancel");
  const startBtn = document.getElementById("classifyStart");

  let resolver = null;
  let plan = null;
  let selected = {};

  function hide() {
    if (modal) modal.hidden = true;
    if (backdrop) backdrop.hidden = true;
  }

  function finish(result) {
    hide();
    const resolve = resolver;
    resolver = null;
    if (resolve) resolve(result);
  }

  function renderGroups() {
    if (!groupsBox) return;
    groupsBox.replaceChildren();
    if (!plan.groups.length) {
      const empty = document.createElement("p");
      empty.className = "smart-empty";
      empty.textContent = "这个关键词没有识别到可分类属性，可以直接开始比价。";
      groupsBox.append(empty);
      return;
    }

    plan.groups.forEach((group) => {
      const wrap = document.createElement("div");
      wrap.className = "smart-group";
      const label = document.createElement("div");
      label.className = "smart-group-label";
      label.textContent = group.label;
      const chips = document.createElement("div");
      chips.className = "smart-chips";

      const all = document.createElement("button");
      all.type = "button";
      all.className = `smart-chip${selected[group.key] ? "" : " is-active"}`;
      all.textContent = "不限";
      all.addEventListener("click", () => {
        delete selected[group.key];
        renderGroups();
      });
      chips.append(all);

      group.values.forEach((entry) => {
        const value = typeof entry === "string" ? entry : entry.value;
        const count = typeof entry === "string" ? 0 : entry.count;
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = `smart-chip${selected[group.key] === value ? " is-active" : ""}`;
        chip.append(document.createTextNode(value));
        if (count) {
          const countNode = document.createElement("small");
          countNode.textContent = String(count);
          chip.append(countNode);
        }
        chip.addEventListener("click", () => {
          if (selected[group.key] === value) delete selected[group.key];
          else selected[group.key] = value;
          renderGroups();
        });
        chips.append(chip);
      });

      wrap.append(label, chips);
      groupsBox.append(wrap);
    });
  }

  function open(query) {
    if (!modal || !groupsBox) {
      return Promise.resolve({ query, selections: {}, category: "商品" });
    }
    plan = buildPlan(query);
    selected = { ...plan.selected };
    if (queryText) queryText.textContent = `搜索词：${query}`;
    if (categoryText) categoryText.textContent = `识别类型：${plan.category}`;
    renderGroups();
    modal.hidden = false;
    if (backdrop) backdrop.hidden = false;
    if (startBtn) startBtn.focus();
    return new Promise((resolve) => {
      resolver = resolve;
    });
  }

  if (closeBtn) closeBtn.addEventListener("click", () => finish(null));
  if (cancelBtn) cancelBtn.addEventListener("click", () => finish(null));
  if (backdrop) backdrop.addEventListener("click", () => finish(null));
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modal && !modal.hidden) finish(null);
  });
  if (startBtn) {
    startBtn.addEventListener("click", () => {
      finish({
        query: buildSearchQuery(plan ? plan.query : "", selected),
        selections: { ...selected },
        category: plan ? plan.category : "商品"
      });
    });
  }

  window.PriceLensClassify = {
    detectCategory,
    buildPlan,
    buildFromItems,
    buildSearchQuery,
    isRelevantItem,
    filterItems,
    open
  };
})();
