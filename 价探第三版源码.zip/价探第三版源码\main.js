const { app, BrowserWindow, ipcMain, shell, Menu } = require("electron");
const path = require("node:path");
const fs = require("node:fs/promises");

const APP_NAME = "价探";
const NORMAL_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36";
const PDD_MOBILE_USER_AGENT =
  "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36";

app.setName(APP_NAME);
app.userAgentFallback = NORMAL_USER_AGENT;

let mainWindow = null;
const platformWindows = new Map();
const PLATFORM_TITLES = {
  jd: "京东 · 登录 / 浏览",
  taobao: "淘宝 · 登录 / 浏览",
  pdd: "拼多多 · 登录 / 浏览"
};

function openPlatformWindow(platform, url) {
  if (!PLATFORM_TITLES[platform]) throw new Error("不支持的平台");
  if (!/^https?:\/\//i.test(String(url || ""))) throw new Error("不支持的链接");

  const existing = platformWindows.get(platform);
  if (existing && !existing.isDestroyed()) {
    existing.loadURL(url).catch(() => {});
    existing.show();
    existing.focus();
    return true;
  }

  const win = new BrowserWindow({
    width: 1280,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: PLATFORM_TITLES[platform],
    backgroundColor: "#ffffff",
    autoHideMenuBar: true,
    webPreferences: {
      partition: `persist:pricelens-${platform}`,
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });

  win.webContents.setUserAgent(platform === "pdd" ? PDD_MOBILE_USER_AGENT : NORMAL_USER_AGENT);
  win.loadURL(url).catch(() => {});
  win.webContents.setWindowOpenHandler(({ url: target }) => {
    if (/^https?:\/\//i.test(target)) shell.openExternal(target);
    return { action: "deny" };
  });
  win.on("closed", () => platformWindows.delete(platform));
  platformWindows.set(platform, win);
  return true;
}

function dataFilePath() {
  return path.join(app.getPath("userData"), "records.json");
}

async function loadRecords() {
  try {
    const raw = await fs.readFile(dataFilePath(), "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    if (error.code !== "ENOENT") console.warn("读取记录失败：", error.message);
    return [];
  }
}

async function saveRecords(records) {
  if (!Array.isArray(records)) throw new Error("记录格式不正确");
  const clean = records.slice(0, 5000);
  const file = dataFilePath();
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.tmp`;
  await fs.writeFile(temp, JSON.stringify(clean, null, 2), "utf8");
  await fs.rename(temp, file);
  return true;
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 940,
    minWidth: 1080,
    minHeight: 680,
    title: "价探 · 桌面采集工作台",
    backgroundColor: "#f3eee3",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      spellcheck: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, "app", "index.html"));
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

app.on("web-contents-created", (_event, contents) => {
  if (contents.getType() === "webview") {
    // PDD must use a mobile UA; otherwise the H5 page may render an incomplete shell.
    const currentUrl = contents.getURL() || "";
    if (currentUrl) {
      contents.setUserAgent(/yangkeduo|pinduoduo/i.test(currentUrl) ? PDD_MOBILE_USER_AGENT : NORMAL_USER_AGENT);
    }
    contents.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//i.test(url)) shell.openExternal(url);
      return { action: "deny" };
    });
  }
});

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  ipcMain.handle("records:load", () => loadRecords());
  ipcMain.handle("records:save", (_event, records) => saveRecords(records));
  ipcMain.handle("shell:openExternal", async (_event, url) => {
    if (!/^https?:\/\//i.test(String(url || ""))) throw new Error("不支持的链接");
    await shell.openExternal(url);
    return true;
  });
  ipcMain.handle("platform:open", (_event, payload = {}) => {
    return openPlatformWindow(payload.platform, payload.url);
  });
  ipcMain.handle("app:dataPath", () => dataFilePath());
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
