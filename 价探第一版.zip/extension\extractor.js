/*
 * 价探采集器 · 页面信息提取
 * 这个文件不依赖任何 chrome.* API，可单独在页面中运行，便于测试。
 * 它只读取当前页面已经展示的信息，不读取 Cookie、账号资料或本地存储。
 */
(() => {
  "use strict";

  const PRICE_PATTERN = /(?:¥|￥|RMB|CNY)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/gi;
  const STORAGE_PATTERN = /(?:64|128|256|512)\s*GB|\b[124]\s*TB\b/i;
  const COLOR_WORDS = [
    "深空黑", "原色钛金属", "沙漠色钛金属", "宇宙橙", "星光色", "午夜色",
    "远峰蓝", "苍岭绿", "银色", "黑色", "白色", "蓝色", "紫色", "绿色",
    "橙色", "粉色", "金色", "钛金属", "石墨色", "红色", "灰色"
  ];
  const UI_NOISE = /^(首页|关注|推荐|购物车|客服|分享|收藏|评价|详情|参数|立即购买|加入购物车|领券|促销|补贴|直播|宝贝|店铺|进店|关注店铺|已售|包邮|退货|保障|选择|已选择|数量|件)$/;

  const PLATFORM_BY_HOST = [
    { test: /(^|\.)douyin\.com$|(^|\.)jinritemai\.com$/, key: "douyin" },
    { test: /(^|\.)jd\.com$/, key: "jd" },
    { test: /(^|\.)taobao\.com$|(^|\.)tmall\.com$/, key: "taobao" },
    { test: /(^|\.)yangkeduo\.com$|(^|\.)pinduoduo\.com$/, key: "pdd" }
  ];

  function normalizeSpace(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function metaContent(property) {
    const element =
      document.querySelector(`meta[property="${property}"]`) ||
      document.querySelector(`meta[name="${property}"]`);
    return element ? normalizeSpace(element.getAttribute("content")) : "";
  }

  function firstVisibleText(selectors) {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (!element) continue;
      const text = normalizeSpace(element.innerText || element.textContent);
      if (text && text.length <= 180) return text;
    }
    return "";
  }

  function cleanTitle(value) {
    return normalizeSpace(value)
      .replace(/\s*[-_|｜]\s*(抖音商城|抖音|Douyin|douyin).*$/i, "")
      .replace(/\s*[-_|｜]\s*抖音.*$/i, "")
      .slice(0, 160);
  }

  function pageText() {
    const bodyText = document.body ? document.body.innerText : "";
    return normalizeSpace(bodyText).slice(0, 220000);
  }

  function decodeJsonLdNode(node, found) {
    if (!node || found.length > 12) return;
    if (Array.isArray(node)) {
      node.forEach((item) => decodeJsonLdNode(item, found));
      return;
    }
    if (typeof node !== "object") return;

    const type = String(node["@type"] || "").toLowerCase();
    if (type.includes("product") || type.includes("offer") || node.price !== undefined) {
      const offer = Array.isArray(node.offers) ? node.offers[0] : node.offers;
      const price = node.price ?? offer?.price ?? offer?.lowPrice;
      const currency = node.priceCurrency ?? offer?.priceCurrency ?? "";
      if (price !== undefined) {
        found.push({
          value: Number(String(price).replace(/,/g, "")),
          source: "json-ld",
          context: currency || "结构化商品数据"
        });
      }
      if (node.brand) {
        const brand = typeof node.brand === "string" ? node.brand : node.brand.name;
        if (brand) found.brand = normalizeSpace(brand);
      }
    }

    Object.values(node).forEach((value) => {
      if (value && typeof value === "object") decodeJsonLdNode(value, found);
    });
  }

  function getJsonLd() {
    const found = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach((script) => {
      try {
        decodeJsonLdNode(JSON.parse(script.textContent || "null"), found);
      } catch {
        // Ignore malformed structured data.
      }
    });
    return found;
  }

  function getPriceCandidates(text, jsonLd) {
    const candidates = [];
    const seen = new Set();

    function add(value, source, context) {
      const numeric = Number(value);
      if (!Number.isFinite(numeric) || numeric <= 0 || numeric > 2000000) return;
      const key = numeric.toFixed(2);
      if (seen.has(key)) return;
      seen.add(key);
      candidates.push({
        value: Math.round(numeric * 100) / 100,
        source,
        context: normalizeSpace(context).slice(0, 80)
      });
    }

    jsonLd.forEach((item) => add(item.value, item.source, item.context));

    const metaPrice =
      metaContent("product:price:amount") ||
      metaContent("og:price:amount") ||
      document.querySelector('[itemprop="price"]')?.getAttribute("content") ||
      "";
    if (metaPrice) add(metaPrice, "meta", "页面商品价格元信息");

    let match;
    PRICE_PATTERN.lastIndex = 0;
    while ((match = PRICE_PATTERN.exec(text)) && candidates.length < 10) {
      const start = Math.max(0, match.index - 32);
      const end = Math.min(text.length, match.index + match[0].length + 38);
      add(match[1].replace(/,/g, ""), "text", text.slice(start, end));
    }

    return candidates.slice(0, 8);
  }

  function getSelectedTexts() {
    const selectors = [
      '[aria-checked="true"]',
      '[aria-selected="true"]',
      '[class*="sku"] [class*="selected"]',
      '[class*="sku"] [class*="active"]',
      '[class*="Sku"] [class*="selected"]',
      '[class*="Sku"] [class*="active"]',
      '[class*="selected"]',
      '[class*="Selected"]',
      '[class*="active"]'
    ];
    const texts = [];
    const seen = new Set();

    document.querySelectorAll(selectors.join(",")).forEach((element) => {
      if (texts.length >= 40) return;
      const text = normalizeSpace(element.innerText || element.textContent);
      if (!text || text.length > 24 || UI_NOISE.test(text)) return;
      if (/[¥￥]/.test(text)) return;
      if (seen.has(text)) return;
      seen.add(text);
      texts.push(text);
    });

    return texts;
  }

  function getShop(text, jsonLd) {
    const shopMatch = text.match(/([\u4e00-\u9fa5A-Za-z0-9·（）()\-\s]{2,40}(?:旗舰店|专营店|专卖店|官方店|店铺))/);
    if (shopMatch) return normalizeSpace(shopMatch[1]).slice(0, 60);
    if (jsonLd.brand) return normalizeSpace(jsonLd.brand).slice(0, 60);
    return "";
  }

  function getOriginalPrice(text, currentPrice) {
    const match = text.match(/(?:原价|划线价|市场价|专柜价)[^\d¥￥]{0,12}[¥￥]?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/);
    if (!match) return null;
    const value = Number(match[1].replace(/,/g, ""));
    if (!Number.isFinite(value) || value <= currentPrice) return null;
    return Math.round(value * 100) / 100;
  }

  function inferPlatform(host) {
    const item = PLATFORM_BY_HOST.find((entry) => entry.test.test(host));
    return item ? item.key : "other";
  }

  function extract() {
    const text = pageText();
    const jsonLd = getJsonLd();
    const selectedTexts = getSelectedTexts();

    const heading =
      firstVisibleText([
        'h1[class*="title"]',
        'h1',
        '[class*="product"] [class*="title"]',
        '[class*="goods"] [class*="title"]'
      ]) || "";

    const title = cleanTitle(
      metaContent("og:title") ||
      heading ||
      document.title ||
      document.querySelector("h1")?.innerText ||
      ""
    );

    const candidates = getPriceCandidates(text, jsonLd);
    const price = candidates.length ? candidates[0].value : null;
    const capacityFromSelected = selectedTexts.find((item) => STORAGE_PATTERN.test(item)) || "";
    const colorFromSelected = selectedTexts.find((item) => COLOR_WORDS.some((color) => item.includes(color))) || "";
    const capacityFromPage = text.match(STORAGE_PATTERN)?.[0] || "";
    const colorFromPage = COLOR_WORDS.find((color) => text.includes(color)) || "";

    const notes = [];
    if (candidates.length > 1) notes.push("检测到多个价格，请选择你当前看到的实际售价");
    if (!capacityFromSelected && !colorFromSelected) notes.push("未确认已选规格，请手动核对容量/颜色");
    if (!price) notes.push("没有自动识别到价格，请手动填写");

    return {
      url: location.href,
      host: location.hostname,
      platform: inferPlatform(location.hostname),
      pageTitle: cleanTitle(document.title),
      productName: title,
      heading,
      shop: getShop(text, jsonLd),
      price,
      priceCandidates: candidates,
      originalPrice: price ? getOriginalPrice(text, price) : null,
      capacity: capacityFromSelected || capacityFromPage,
      color: colorFromSelected || colorFromPage,
      selectedTexts,
      capturedAt: new Date().toISOString(),
      notes
    };
  }

  globalThis.PriceLensExtractor = { extract };
})();
