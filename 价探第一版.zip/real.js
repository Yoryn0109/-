(() => {
  "use strict";

  const STORAGE_KEY = "price-lens:real-records:v1";
  const PLATFORM_META = {
    douyin: { name: "抖音商城", short: "抖", color: "#1c252c", soft: "#eceff0" },
    jd: { name: "京东", short: "京", color: "#df2f28", soft: "#fdecea" },
    taobao: { name: "淘宝", short: "淘", color: "#f25c1d", soft: "#fff0e7" },
    pdd: { name: "拼多多", short: "拼", color: "#d9364a", soft: "#fdecef" },
    other: { name: "其他平台", short: "其", color: "#5f6d64", soft: "#f1f3ee" }
  };

  const els = {
    importBtn: document.getElementById("importBtn"),
    installBtn: document.getElementById("installBtn"),
    emptyImportBtn: document.getElementById("emptyImportBtn"),
    emptyInstallBtn: document.getElementById("emptyInstallBtn"),
    importMoreBtn: document.getElementById("importMoreBtn"),
    backupBtn: document.getElementById("backupBtn"),
    clearBtn: document.getElementById("clearBtn"),
    emptyState: document.getElementById("emptyState"),
    dashboard: document.getElementById("dashboard"),
    boardSub: document.getElementById("boardSub"),
    statProducts: document.getElementById("statProducts"),
    statSkus: document.getElementById("statSkus"),
    statRecords: document.getElementById("statRecords"),
    statLatest: document.getElementById("statLatest"),
    statLatestNote: document.getElementById("statLatestNote"),
    productChips: document.getElementById("productChips"),
    platformChips: document.getElementById("platformChips"),
    matrixWrap: document.getElementById("matrixWrap"),
    matrixMeta: document.getElementById("matrixMeta"),
    skuChart: document.getElementById("skuChart"),
    chartMeta: document.getElementById("chartMeta"),
    recordsWrap: document.getElementById("recordsWrap"),
    recordsMeta: document.getElementById("recordsMeta"),
    importInput: document.getElementById("importInput"),
    installDialog: document.getElementById("installDialog"),
    clearDialog: document.getElementById("clearDialog"),
    clearCount: document.getElementById("clearCount"),
    toast: document.getElementById("toast"),
    toastText: document.getElementById("toastText")
  };

  let records = [];
  let selectedProduct = "";
  let selectedPlatform = "all";
  let toastTimer = null;

  const priceFormatter = new Intl.NumberFormat("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (character) => {
      const entities = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
      return entities[character];
    });
  }

  function formatPrice(value) {
    return `¥${priceFormatter.format(Math.max(0, Number(value) || 0))}`;
  }

  function formatShortTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "时间未知";
    return `${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
  }

  function formatFullTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "时间未知";
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
  }

  function makeId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    return `real-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function safeUrl(rawUrl) {
    try {
      const url = new URL(String(rawUrl || ""));
      if (url.protocol === "http:" || url.protocol === "https:") return url.href;
    } catch {
      return "";
    }
    return "";
  }

  function normalizePlatform(value) {
    const text = String(value || "").toLowerCase();
    if (value === "抖音" || text.includes("douyin") || text.includes("jinritemai")) return "douyin";
    if (value === "京东" || text.includes("jd")) return "jd";
    if (value === "淘宝" || text.includes("taobao") || text.includes("tmall")) return "taobao";
    if (value === "拼多多" || text.includes("pdd") || text.includes("pinduoduo")) return "pdd";
    return PLATFORM_META[text] ? text : "other";
  }

  function normalizeVariants(rawVariants) {
    if (Array.isArray(rawVariants)) {
      return rawVariants
        .map((variant) => ({
          name: String(variant?.name || "").trim().slice(0, 20),
          value: String(variant?.value || "").trim().slice(0, 50)
        }))
        .filter((variant) => variant.name && variant.value);
    }

    if (rawVariants && typeof rawVariants === "object") {
      return Object.entries(rawVariants)
        .map(([name, value]) => ({
          name: String(name).trim().slice(0, 20),
          value: String(value).trim().slice(0, 50)
        }))
        .filter((variant) => variant.name && variant.value);
    }

    return [];
  }

  function normalizeRecord(raw) {
    if (!raw || typeof raw !== "object") return null;

    const product = String(raw.product || raw.name || raw.title || "").trim().slice(0, 120);
    const price = Number(String(raw.price ?? "").replace(/[¥￥,\s]/g, ""));
    if (!product || !Number.isFinite(price) || price <= 0) return null;

    const capturedAt = new Date(raw.capturedAt || raw.time || Date.now());
    const platform = normalizePlatform(raw.platform);

    return {
      id: String(raw.id || makeId()),
      platform,
      product,
      title: String(raw.title || "").trim().slice(0, 160),
      price: Math.round(price * 100) / 100,
      originalPrice: (() => {
        const original = Number(String(raw.originalPrice ?? "").replace(/[¥￥,\s]/g, ""));
        return Number.isFinite(original) && original > price ? Math.round(original * 100) / 100 : null;
      })(),
      variants: normalizeVariants(raw.variants),
      shop: String(raw.shop || "").trim().slice(0, 100),
      note: String(raw.note || "").trim().slice(0, 160),
      url: safeUrl(raw.url),
      capturedAt: Number.isNaN(capturedAt.getTime()) ? new Date().toISOString() : capturedAt.toISOString()
    };
  }

  function loadRecords() {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.map(normalizeRecord).filter(Boolean) : [];
    } catch {
      return [];
    }
  }

  function saveRecords() {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
      return true;
    } catch {
      showToast("浏览器本地存储不可用，记录无法保存");
      return false;
    }
  }

  function platformMeta(key) {
    return PLATFORM_META[key] || PLATFORM_META.other;
  }

  function showToast(message) {
    window.clearTimeout(toastTimer);
    els.toastText.textContent = message;
    els.toast.hidden = false;
    window.requestAnimationFrame(() => els.toast.classList.add("is-visible"));
    toastTimer = window.setTimeout(() => {
      els.toast.classList.remove("is-visible");
      window.setTimeout(() => {
        els.toast.hidden = true;
      }, 220);
    }, 3000);
  }

  function getProductGroups() {
    const map = new Map();
    records.forEach((record) => {
      if (!map.has(record.product)) {
        map.set(record.product, {
          name: record.product,
          count: 0,
          latest: 0
        });
      }
      const group = map.get(record.product);
      group.count += 1;
      group.latest = Math.max(group.latest, new Date(record.capturedAt).getTime());
    });
    return [...map.values()].sort((left, right) => right.latest - left.latest);
  }

  function getPlatformGroups(productRecords) {
    const map = new Map();
    productRecords.forEach((record) => {
      map.set(record.platform, (map.get(record.platform) || 0) + 1);
    });
    return [...map.entries()]
      .sort((left, right) => right[1] - left[1])
      .map(([key, count]) => ({ key, count }));
  }

  function getVariantValue(record, name) {
    const variant = record.variants.find((item) => item.name === name);
    return variant ? variant.value : "";
  }

  function getVariantAxes(productRecords) {
    const names = [];
    productRecords.forEach((record) => {
      record.variants.forEach((variant) => {
        if (!names.includes(variant.name)) names.push(variant.name);
      });
    });
    return names;
  }

  function uniqueValues(productRecords, axisName) {
    const values = [];
    let hasMissing = false;
    productRecords.forEach((record) => {
      const value = getVariantValue(record, axisName);
      if (!value) {
        hasMissing = true;
      } else if (!values.includes(value)) {
        values.push(value);
      }
    });
    if (hasMissing) values.push("未填写");
    return values;
  }

  function variantLabel(record) {
    if (!record.variants.length) return "默认规格";
    return record.variants.map((variant) => variant.value).join(" / ");
  }

  function skuSignature(record) {
    if (!record.variants.length) return "default";
    return record.variants
      .map((variant) => `${variant.name}:${variant.value}`)
      .sort()
      .join("|");
  }

  function getSkuGroups(productRecords) {
    const map = new Map();
    productRecords.forEach((record) => {
      const key = skuSignature(record);
      if (!map.has(key)) {
        map.set(key, {
          key,
          variants: record.variants,
          label: variantLabel(record),
          offers: []
        });
      }
      map.get(key).offers.push(record);
    });

    const groups = [...map.values()];
    groups.forEach((group) => {
      group.offers.sort((left, right) => left.price - right.price);
      group.lowest = group.offers[0];
    });
    return groups;
  }

  function renderSummary(productGroups) {
    const uniqueProducts = productGroups.length;
    const skuCount = new Set(records.map((record) => `${record.product}|${skuSignature(record)}`)).size;
    const latest = records.reduce((newest, record) => {
      return new Date(record.capturedAt).getTime() > new Date(newest || 0).getTime() ? record.capturedAt : newest;
    }, "");

    els.statProducts.textContent = String(uniqueProducts);
    els.statSkus.textContent = String(skuCount);
    els.statRecords.textContent = String(records.length);
    els.statLatest.textContent = latest ? formatShortTime(latest) : "—";
    const latestRecord = latest
      ? records.find((record) => record.capturedAt === latest) || records[0]
      : null;
    els.statLatestNote.textContent = latestRecord
      ? `${latestRecord.product}${latestRecord.shop ? ` · ${latestRecord.shop}` : ""}`
      : "尚未采集";
    els.boardSub.textContent = latest
      ? `共 ${records.length} 条真实快照 · 最近采集于 ${formatFullTime(latest)}`
      : "—";
  }

  function renderFilters(productGroups, productRecords) {
    els.productChips.replaceChildren();
    productGroups.forEach((group) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `filter-chip${group.name === selectedProduct ? " is-active" : ""}`;
      button.dataset.product = group.name;
      button.innerHTML = `${escapeHTML(group.name)} <b>${group.count}</b>`;
      button.addEventListener("click", () => {
        selectedProduct = group.name;
        selectedPlatform = "all";
        render();
      });
      els.productChips.append(button);
    });

    const platformGroups = getPlatformGroups(productRecords);
    if (selectedPlatform !== "all" && !platformGroups.some((group) => group.key === selectedPlatform)) {
      selectedPlatform = "all";
    }

    els.platformChips.replaceChildren();
    const allButton = document.createElement("button");
    allButton.type = "button";
    allButton.className = `filter-chip${selectedPlatform === "all" ? " is-active" : ""}`;
    allButton.dataset.platform = "all";
    allButton.innerHTML = `全部 <b>${productRecords.length}</b>`;
    allButton.addEventListener("click", () => {
      selectedPlatform = "all";
      render();
    });
    els.platformChips.append(allButton);

    platformGroups.forEach((group) => {
      const meta = platformMeta(group.key);
      const button = document.createElement("button");
      button.type = "button";
      button.className = `filter-chip${selectedPlatform === group.key ? " is-active" : ""}`;
      button.dataset.platform = group.key;
      button.innerHTML = `${escapeHTML(meta.name)} <b>${group.count}</b>`;
      button.addEventListener("click", () => {
        selectedPlatform = group.key;
        render();
      });
      els.platformChips.append(button);
    });
  }

  function lowestOf(offers) {
    return offers.slice().sort((left, right) => left.price - right.price)[0] || null;
  }

  function matrixCellHTML(cell, isLowest) {
    if (!cell || !cell.lowest) {
      return '<td><span class="matrix-empty">未采集</span></td>';
    }

    const record = cell.lowest;
    const meta = platformMeta(record.platform);
    const linkTag = record.url ? "a" : "div";
    const href = record.url ? ` href="${escapeHTML(record.url)}" target="_blank" rel="noopener noreferrer"` : "";
    return `
      <td>
        <${linkTag} class="matrix-cell${isLowest ? " is-lowest" : ""}"${href} title="${escapeHTML(`${record.product} ${variantLabel(record)}`)}">
          ${isLowest ? '<span class="matrix-best-tag">最低</span>' : ""}
          <span class="matrix-price">${formatPrice(record.price)}</span>
          <span class="matrix-shop">${escapeHTML(record.shop || meta.name)}</span>
          <span class="matrix-meta">${escapeHTML(meta.name)} · ${formatShortTime(record.capturedAt)}${cell.offers.length > 1 ? ` · ${cell.offers.length} 条` : ""}</span>
        </${linkTag}>
      </td>
    `;
  }

  function renderMatrix(productRecords) {
    const filtered = selectedPlatform === "all"
      ? productRecords
      : productRecords.filter((record) => record.platform === selectedPlatform);
    const axes = getVariantAxes(productRecords);

    if (!filtered.length) {
      els.matrixMeta.textContent = "当前筛选下没有记录";
      els.matrixWrap.innerHTML = '<p class="record-empty">当前筛选下还没有采集记录，切换平台或继续采集。</p>';
      return;
    }

    if (axes.length > 2) {
      const groups = getSkuGroups(filtered).sort((left, right) => left.lowest.price - right.lowest.price);
      const lowestPrice = groups[0]?.lowest.price ?? null;
      const rows = groups.map((group) => {
        const isLowest = group.lowest.price === lowestPrice;
        return `<tr><td>${escapeHTML(group.label)}</td>${matrixCellHTML({ lowest: group.lowest, offers: group.offers }, isLowest)}</tr>`;
      }).join("");
      els.matrixMeta.textContent = `${groups.length} 个 SKU 组合 · ${filtered.length} 条记录`;
      els.matrixWrap.innerHTML = `
        <table class="matrix-table">
          <thead><tr><th>规格组合</th><th>最低价</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      `;
      return;
    }

    const rowAxis = axes[0] || "";
    const colAxis = axes[1] || "";
    const rowValues = rowAxis ? uniqueValues(productRecords, rowAxis) : ["默认规格"];
    const colValues = colAxis ? uniqueValues(productRecords, colAxis) : ["最低价"];
    const cellMap = new Map();

    filtered.forEach((record) => {
      const row = rowAxis ? getVariantValue(record, rowAxis) || "未填写" : "默认规格";
      const col = colAxis ? getVariantValue(record, colAxis) || "未填写" : "最低价";
      const key = `${row}\u0000${col}`;
      if (!cellMap.has(key)) cellMap.set(key, { offers: [] });
      cellMap.get(key).offers.push(record);
    });

    cellMap.forEach((cell) => {
      cell.lowest = lowestOf(cell.offers);
    });

    const allCells = [...cellMap.values()].filter((cell) => cell.lowest);
    const lowestPrice = allCells.length ? Math.min(...allCells.map((cell) => cell.lowest.price)) : null;
    const headerCells = colValues.map((value) => `<th scope="col">${escapeHTML(value)}</th>`).join("");
    const bodyRows = rowValues.map((rowValue) => {
      const cells = colValues.map((colValue) => {
        const cell = cellMap.get(`${rowValue}\u0000${colValue}`);
        const isLowest = Boolean(cell?.lowest && cell.lowest.price === lowestPrice);
        return matrixCellHTML(cell, isLowest);
      }).join("");
      return `<tr><th scope="row">${escapeHTML(rowValue)}</th>${cells}</tr>`;
    }).join("");

    const rowHeader = rowAxis || "商品";
    const cornerLabel = colAxis ? `${rowHeader} \\ ${colAxis}` : rowHeader;
    els.matrixMeta.textContent = colAxis
      ? `${rowValues.length} 个${rowAxis} × ${colValues.length} 个${colAxis} · ${allCells.length} 个 SKU 有数据`
      : `${rowValues.length} 个 SKU · ${filtered.length} 条记录`;

    els.matrixWrap.innerHTML = `
      <table class="matrix-table">
        <thead>
          <tr><th scope="col">${escapeHTML(cornerLabel)}</th>${headerCells}</tr>
        </thead>
        <tbody>${bodyRows}</tbody>
      </table>
    `;
  }

  function renderChart(productRecords) {
    const filtered = selectedPlatform === "all"
      ? productRecords
      : productRecords.filter((record) => record.platform === selectedPlatform);

    if (!filtered.length) {
      els.chartMeta.textContent = "暂无数据";
      els.skuChart.innerHTML = '<p class="record-empty">当前筛选下没有可绘制的价格。</p>';
      return;
    }

    const groups = getSkuGroups(filtered)
      .sort((left, right) => left.lowest.price - right.lowest.price)
      .slice(0, 12);
    const maxPrice = Math.max(...groups.map((group) => group.lowest.price), 1);
    const lowestPrice = groups[0]?.lowest.price ?? 0;
    const platformText = selectedPlatform === "all" ? "全部平台" : platformMeta(selectedPlatform).name;

    els.chartMeta.textContent = `${platformText} · ${groups.length} 个 SKU · 最低价升序`;
    els.skuChart.innerHTML = groups.map((group) => {
      const width = Math.max(6, (group.lowest.price / maxPrice) * 100);
      const isLowest = group.lowest.price === lowestPrice;
      return `
        <div class="sku-row${isLowest ? " is-lowest" : ""}">
          <span class="sku-label" title="${escapeHTML(group.label)}">${escapeHTML(group.label)}</span>
          <div class="sku-track" aria-hidden="true"><span class="sku-bar" style="width:${width.toFixed(2)}%"></span></div>
          <span class="sku-value">${formatPrice(group.lowest.price)}</span>
        </div>
      `;
    }).join("");
  }

  function renderRecords(productRecords) {
    const filtered = selectedPlatform === "all"
      ? productRecords
      : productRecords.filter((record) => record.platform === selectedPlatform);
    const sorted = filtered.slice().sort((left, right) => new Date(right.capturedAt) - new Date(left.capturedAt));

    els.recordsMeta.textContent = `${sorted.length} 条 · ${selectedPlatform === "all" ? "全部平台" : platformMeta(selectedPlatform).name}`;

    if (!sorted.length) {
      els.recordsWrap.innerHTML = '<p class="record-empty">当前筛选下还没有采集记录。</p>';
      return;
    }

    const rows = sorted.map((record) => {
      const meta = platformMeta(record.platform);
      const variants = record.variants
        .map((variant) => `<span class="variant-pill">${escapeHTML(variant.name)} ${escapeHTML(variant.value)}</span>`)
        .join("");
      const original = record.originalPrice ? `<del>${formatPrice(record.originalPrice)}</del>` : "";
      return `
        <tr>
          <td class="record-time">${formatFullTime(record.capturedAt)}</td>
          <td><span class="platform-label" style="--brand:${meta.color}"><i></i>${escapeHTML(meta.name)}</span></td>
          <td>
            <div class="record-product" title="${escapeHTML(record.product)}">${escapeHTML(record.product)}</div>
            <div class="record-variants">${variants || '<span class="variant-pill">默认规格</span>'}</div>
          </td>
          <td>${escapeHTML(record.shop || "—")}</td>
          <td><span class="record-price">${formatPrice(record.price)}</span> ${original}</td>
          <td>${record.url ? `<a class="record-link" href="${escapeHTML(record.url)}" target="_blank" rel="noopener noreferrer">查看页面</a>` : "—"}</td>
          <td><button class="record-delete" type="button" data-delete="${escapeHTML(record.id)}" title="删除这条记录" aria-label="删除这条记录"><svg class="icon" aria-hidden="true"><use href="#ri-trash"></use></svg></button></td>
        </tr>
      `;
    }).join("");

    els.recordsWrap.innerHTML = `
      <table class="record-table">
        <thead>
          <tr><th>采集时间</th><th>平台</th><th>商品 / 规格</th><th>店铺</th><th>价格</th><th>来源</th><th>操作</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

  function render() {
    const productGroups = getProductGroups();

    if (records.length === 0) {
      els.emptyState.hidden = false;
      els.dashboard.hidden = true;
      selectedProduct = "";
      selectedPlatform = "all";
      return;
    }

    if (!productGroups.some((group) => group.name === selectedProduct)) {
      selectedProduct = productGroups[0]?.name || "";
    }

    const productRecords = records.filter((record) => record.product === selectedProduct);
    els.emptyState.hidden = true;
    els.dashboard.hidden = false;
    renderSummary(productGroups);
    renderFilters(productGroups, productRecords);
    renderMatrix(productRecords);
    renderChart(productRecords);
    renderRecords(productRecords);
  }

  async function importFile(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const payload = JSON.parse(text);
      const incoming = Array.isArray(payload) ? payload : payload.records;
      if (!Array.isArray(incoming) || incoming.length === 0) {
        throw new Error("JSON 中没有 records 数组");
      }

      const normalized = incoming.map(normalizeRecord).filter(Boolean);
      if (normalized.length === 0) throw new Error("没有有效的真实采集记录");

      const existingIds = new Set(records.map((record) => record.id));
      const existingSignatures = new Set(records.map((record) => {
        return `${record.platform}|${record.product}|${skuSignature(record)}|${record.price}|${record.capturedAt}`;
      }));
      const incomingUnique = [];

      normalized.forEach((record) => {
        const signature = `${record.platform}|${record.product}|${skuSignature(record)}|${record.price}|${record.capturedAt}`;
        if (existingIds.has(record.id) || existingSignatures.has(signature)) return;
        existingIds.add(record.id);
        existingSignatures.add(signature);
        incomingUnique.push(record);
      });

      const skipped = normalized.length - incomingUnique.length;
      if (incomingUnique.length === 0) {
        showToast(`没有新增记录${skipped ? `，已跳过 ${skipped} 条重复数据` : ""}`);
        return;
      }

      records = [...incomingUnique, ...records];
      if (!selectedProduct || !records.some((record) => record.product === selectedProduct)) {
        selectedProduct = incomingUnique[0].product;
        selectedPlatform = "all";
      }
      saveRecords();
      render();

      window.setTimeout(() => {
        els.dashboard.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);

      showToast(`已导入 ${incomingUnique.length} 条真实记录${skipped ? `，跳过 ${skipped} 条重复` : ""}`);
    } catch (error) {
      console.error(error);
      showToast(`导入失败：${error.message || "JSON 格式不正确"}`);
    } finally {
      els.importInput.value = "";
    }
  }

  function downloadJSON() {
    if (records.length === 0) return;
    const payload = {
      app: "price-lens-capture",
      version: 1,
      exportedAt: new Date().toISOString(),
      records
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const now = new Date();
    const filename = `价探真实数据备份-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}.json`;
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 3000);
    showToast(`已备份 ${records.length} 条真实记录`);
  }

  function openInstallDialog() {
    if (typeof els.installDialog.showModal === "function") {
      if (!els.installDialog.open) els.installDialog.showModal();
    } else {
      els.installDialog.setAttribute("open", "");
    }
  }

  function closeInstallDialog() {
    if (typeof els.installDialog.close === "function" && els.installDialog.open) {
      els.installDialog.close();
    } else {
      els.installDialog.removeAttribute("open");
    }
  }

  function openClearDialog() {
    if (records.length === 0) return;
    els.clearCount.textContent = String(records.length);
    if (typeof els.clearDialog.showModal === "function") {
      if (!els.clearDialog.open) els.clearDialog.showModal();
    } else if (window.confirm(`清空全部 ${records.length} 条真实记录？`)) {
      clearAll();
    }
  }

  function clearAll() {
    records = [];
    selectedProduct = "";
    selectedPlatform = "all";
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore storage failures.
    }
    render();
    showToast("真实采集记录已清空");
  }

  function bindEvents() {
    [els.importBtn, els.emptyImportBtn, els.importMoreBtn].forEach((button) => {
      button.addEventListener("click", () => els.importInput.click());
    });
    [els.installBtn, els.emptyInstallBtn].forEach((button) => {
      button.addEventListener("click", openInstallDialog);
    });

    els.importInput.addEventListener("change", () => {
      const file = els.importInput.files?.[0];
      if (file) importFile(file);
    });

    els.backupBtn.addEventListener("click", downloadJSON);
    els.clearBtn.addEventListener("click", openClearDialog);

    document.querySelectorAll("[data-close-install]").forEach((button) => {
      button.addEventListener("click", closeInstallDialog);
    });

    els.installDialog.addEventListener("click", (event) => {
      const rect = els.installDialog.getBoundingClientRect();
      const outside = event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom;
      if (outside) closeInstallDialog();
    });

    els.clearDialog.addEventListener("close", () => {
      if (els.clearDialog.returnValue === "confirm") clearAll();
      els.clearDialog.returnValue = "";
    });

    els.recordsWrap.addEventListener("click", (event) => {
      const button = event.target.closest("[data-delete]");
      if (!button) return;
      const id = button.dataset.delete;
      const record = records.find((item) => item.id === id);
      if (!record) return;
      if (!window.confirm(`删除这条真实记录？\n${record.product} · ${variantLabel(record)}`)) return;
      records = records.filter((item) => item.id !== id);
      saveRecords();
      render();
      showToast("已删除这条采集记录");
    });

    window.addEventListener("resize", () => {
      // 表格和图表都使用流式布局；resize 时无需重新计算。
    });
  }

  function init() {
    records = loadRecords();
    bindEvents();
    render();
  }

  init();
})();
