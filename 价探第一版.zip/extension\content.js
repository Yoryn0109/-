/* 内容脚本只负责响应“读取当前页”的请求，不会自动采集或上传。 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "PRICE_LENS_EXTRACT") return false;

  try {
    if (!globalThis.PriceLensExtractor) {
      sendResponse({ ok: false, error: "页面提取器未加载" });
      return false;
    }
    sendResponse({ ok: true, data: globalThis.PriceLensExtractor.extract() });
  } catch (error) {
    sendResponse({ ok: false, error: error?.message || "页面读取失败" });
  }
  return false;
});
