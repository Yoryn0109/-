(() => {
  "use strict";

  const STORAGE_KEY = "captures";
  const PLATFORM_NAMES = {
    douyin: "抖音商城",
    jd: "京东",
    taobao: "淘宝",
    pdd: "拼多多",
    other: "其他平台"
  };

  const els = {
    pageBadge: document.getElementById("pageBadge"),
    pageHost: document.getElementById("pageHost"),
    pageTitle: document.getElementById("pageTitle"),
    pageLink: document.getElementById("pageLink"),
    refreshBtn: document.getElementById("refreshBtn"),
    extractStatus: document.getElementById("extractStatus"),
    product: document.getElementById("product"),
    platform: document.getElementById("platform"),
    shop: document.getElementById("shop"),
    price: document.getElementById("price"),
    originalPrice: document.getElementById("originalPrice"),
    priceCandidates: document.getElementById("priceCandidates"),
    priceChipList: document.getElementById("priceChipList"),
    variantName1: document.getElementById("variantName1"),
    variantValue1: document.getElementById("variantValue1"),
    variantName2: document.getElementById("variantName2"),
    variantValue2: document.getElementById("variantValue2"),
    note: document.getElementById("note"),
    pageUrl: document.getElementById("pageUrl"),
    saveBtn: document.getElementById("saveBtn"),
    recordCount: document.getElementById("recordCount"),
    recordList: document.getElementById("recordList"),
    exportBtn: document.getElementById("exportBtn"),
    clearBtn: document.getElementById("clearBtn"),
    toast: document.getElementById("toast"),
    toastText: document.getElementById("toastText")
  };

  let captures = [];
  let currentExtraction = null;
  let toastTimer = null;
  let activePrice = null;

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (character) => {
      const entities = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
      return entities[character];
    });
  }

  function formatPrice(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return "—";
    return `¥${numeric.toLocaleString("zh-CN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  }

  function formatTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return `${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
  }

  function setStatus(message, state = "") {
    els.extractStatus.textContent = message;
    els.extractStatus.classList.toggle("is-error", state === "error");
    els.pageBadge.classList.remove("is-ready", "is-error");
    if (state) els.pageBadge.classList.add(`is-${state}`);
    els.pageBadge.innerHTML = `<i></i>${state === "ready" ? "已读取" : state === "error" ? "读取失败" : "读取中"}`;
  }

  function showToast(message) {
    window.clearTimeout(toastTimer);
    els.toastText.textContent = message;
    els.toast.hidden = false;
    window.requestAnimationFrame(() => els.toast.classList.add("is-visible"));
    toastTimer = window.setTimeout(() => {
      els.toast.classList.remove("is-visible");
      window.setTimeout(() => {
        els.toast.hidden = true;
      }, 200);
    }, 2400);
  }

  function getCaptures(callback) {
    chrome.storage.local.get({ [STORAGE_KEY]: [] }, (result) => {
      const stored = result && Array.isArray(result[STORAGE_KEY]) ? result[STORAGE_KEY] : [];
      callback(stored);
    });
  }

  function setCaptures(nextCaptures, callback) {
    captures = nextCaptures;
    chrome.storage.local.set({ [STORAGE_KEY]: captures }, () => {
      if (callback) callback();
    });
  }

  function renderCandidates(candidates, selectedPrice) {
    const usable = (candidates || []).slice(0, 6);
    els.priceChipList.replaceChildren();

    if (usable.length <= 1) {
      els.priceCandidates.hidden = true;
      return;
    }

    usable.forEach((candidate) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "price-chip";
      button.textContent = formatPrice(candidate.value);
      button.title = candidate.context || "页面价格候选";
      if (Number(candidate.value) === Number(selectedPrice)) button.classList.add("is-active");
      button.addEventListener("click", () => {
        els.price.value = String(candidate.value);
        activePrice = candidate.value;
        els.priceChipList.querySelectorAll(".price-chip").forEach((item) => item.classList.remove("is-active"));
        button.classList.add("is-active");
      });
      els.priceChipList.append(button);
    });

    els.priceCandidates.hidden = false;
  }

  function setPageMeta(data) {
    let host = "";
    try {
      host = new URL(data.url).hostname.replace(/^www\./, "");
    } catch {
      host = data.host || "";
    }

    els.pageHost.textContent = host || "当前页面";
    els.pageTitle.textContent = data.pageTitle || data.productName || "未识别到页面标题";
    if (data.url) {
      els.pageLink.href = data.url;
      els.pageLink.hidden = false;
    } else {
      els.pageLink.hidden = true;
    }
  }

  function fillForm(data) {
    currentExtraction = data;
    setPageMeta(data);

    els.product.value = data.productName || "";
    els.shop.value = data.shop || "";
    els.price.value = data.price ? String(data.price) : "";
    els.originalPrice.value = data.originalPrice ? String(data.originalPrice) : "";
    els.variantValue1.value = data.capacity || "";
    els.variantValue2.value = data.color || "";
    els.pageUrl.value = data.url || "";

    activePrice = data.price || null;
    renderCandidates(data.priceCandidates, activePrice);

    const notes = Array.isArray(data.notes) ? data.notes.filter(Boolean) : [];
    if (!data.productName) {
      setStatus("没有识别到商品标题，请手动填写商品名称和价格", "error");
    } else if (!data.price) {
      setStatus("没有自动识别到价格，请手动填写当前售价", "error");
    } else if (notes.length) {
      setStatus(notes.join(" · "), "ready");
    } else {
      setStatus("已读取页面信息，请核对价格和规格后保存", "ready");
    }

    if (data.platform && PLATFORM_NAMES[data.platform]) {
      els.platform.value = data.platform;
    }
  }

  function requestExtraction(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, { type: "PRICE_LENS_EXTRACT" }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message || "内容脚本未响应"));
          return;
        }
        if (!response || !response.ok || !response.data) {
          reject(new Error(response?.error || "没有读取到页面数据"));
          return;
        }
        resolve(response.data);
      });
    });
  }

  function injectExtractor(tabId) {
    return new Promise((resolve, reject) => {
      chrome.scripting.executeScript(
        { target: { tabId }, files: ["extractor.js", "content.js"] },
        () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message || "无法注入页面脚本"));
            return;
          }
          resolve();
        }
      );
    });
  }

  async function readPage() {
    setStatus("正在读取页面上的可见价格和规格…");
    els.refreshBtn.disabled = true;

    try {
      const tabs = await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, resolve);
      });
      const tab = tabs && tabs[0];
      if (!tab || !tab.id) throw new Error("没有找到当前标签页");

      let data;
      try {
        data = await requestExtraction(tab.id);
      } catch {
        await injectExtractor(tab.id);
        data = await requestExtraction(tab.id);
      }

      fillForm(data);
    } catch (error) {
      setStatus(`读取失败：${error.message || "请等页面加载完成后重试"}`, "error");
    } finally {
      els.refreshBtn.disabled = false;
    }
  }

  function renderRecords() {
    els.recordCount.textContent = String(captures.length);
    els.exportBtn.disabled = captures.length === 0;
    els.clearBtn.disabled = captures.length === 0;
    els.recordList.replaceChildren();

    if (captures.length === 0) {
      const empty = document.createElement("p");
      empty.className = "record-empty";
      empty.textContent = "还没有采集记录。核对上方价格和 SKU 后，保存第一条真实价格。";
      els.recordList.append(empty);
      return;
    }

    captures.slice(0, 5).forEach((record) => {
      const item = document.createElement("div");
      item.className = "record-item";

      const main = document.createElement("div");
      main.className = "record-main";
      const title = document.createElement("strong");
      title.textContent = record.product;
      const meta = document.createElement("span");
      const variantText = (record.variants || [])
        .map((variant) => `${variant.name} ${variant.value}`)
        .join(" · ");
      meta.textContent = [variantText, record.shop, formatTime(record.capturedAt)].filter(Boolean).join(" · ");
      main.append(title, meta);

      const price = document.createElement("span");
      price.className = "record-price";
      price.textContent = formatPrice(record.price);

      const remove = document.createElement("button");
      remove.className = "record-delete";
      remove.type = "button";
      remove.title = "删除这条记录";
      remove.setAttribute("aria-label", "删除这条记录");
      remove.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"></path><path d="M10 11v5M14 11v5"></path></svg>';
      remove.addEventListener("click", () => {
        const next = captures.filter((entry) => entry.id !== record.id);
        setCaptures(next, () => {
          renderRecords();
          showToast("已删除一条采集记录");
        });
      });

      item.append(main, price, remove);
      els.recordList.append(item);
    });
  }

  function readForm() {
    const product = els.product.value.trim();
    const price = Number(els.price.value);
    const originalPrice = Number(els.originalPrice.value);
    const url = (currentExtraction && currentExtraction.url) || els.pageUrl.value.trim();
    const platform = els.platform.value in PLATFORM_NAMES ? els.platform.value : "other";

    if (!product) {
      els.product.focus();
      showToast("请填写商品名称");
      return null;
    }
    if (!Number.isFinite(price) || price <= 0) {
      els.price.focus();
      showToast("请填写大于 0 的价格");
      return null;
    }

    const variants = [];
    const name1 = els.variantName1.value.trim() || "规格1";
    const value1 = els.variantValue1.value.trim();
    const name2 = els.variantName2.value.trim() || "规格2";
    const value2 = els.variantValue2.value.trim();
    if (value1) variants.push({ name: name1, value: value1 });
    if (value2) variants.push({ name: name2, value: value2 });

    return {
      id: crypto.randomUUID ? crypto.randomUUID() : `capture-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      platform,
      platformName: PLATFORM_NAMES[platform],
      product,
      title: (currentExtraction && currentExtraction.pageTitle) || "",
      price: Math.round(price * 100) / 100,
      originalPrice: Number.isFinite(originalPrice) && originalPrice > price
        ? Math.round(originalPrice * 100) / 100
        : null,
      variants,
      shop: els.shop.value.trim(),
      note: els.note.value.trim(),
      url,
      capturedAt: new Date().toISOString(),
      source: "pricelens-extension"
    };
  }

  function saveCapture() {
    const record = readForm();
    if (!record) return;

    setCaptures([record, ...captures], () => {
      renderRecords();
      const variantText = record.variants.map((variant) => `${variant.name} ${variant.value}`).join(" / ");
      showToast(`已保存：${record.product}${variantText ? ` · ${variantText}` : ""}`);
      els.saveBtn.classList.remove("is-loading");
    });
  }

  function exportCaptures() {
    if (captures.length === 0) return;

    const payload = {
      app: "price-lens-capture",
      version: 1,
      exportedAt: new Date().toISOString(),
      records: captures
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const now = new Date();
    const filename = `价探真实采集-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}-${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}.json`;

    chrome.downloads.download(
      { url, filename, saveAs: true },
      () => {
        if (chrome.runtime.lastError) {
          const anchor = document.createElement("a");
          anchor.href = url;
          anchor.download = filename;
          anchor.click();
        }
        window.setTimeout(() => URL.revokeObjectURL(url), 5000);
        showToast(`已导出 ${captures.length} 条真实采集记录`);
      }
    );
  }

  function clearCaptures() {
    if (captures.length === 0) return;
    if (!window.confirm(`确定清空全部 ${captures.length} 条采集记录吗？此操作无法撤销。`)) return;
    setCaptures([], () => {
      renderRecords();
      showToast("采集本已清空");
    });
  }

  function bindEvents() {
    els.refreshBtn.addEventListener("click", readPage);
    els.saveBtn.addEventListener("click", saveCapture);
    els.exportBtn.addEventListener("click", exportCaptures);
    els.clearBtn.addEventListener("click", clearCaptures);
    els.pageLink.addEventListener("click", (event) => {
      if (!els.pageLink.href) event.preventDefault();
    });
  }

  function init() {
    bindEvents();
    getCaptures((stored) => {
      captures = stored;
      renderRecords();
      readPage();
    });
  }

  init();
})();
