(() => {
  "use strict";

  /* ============================================================
     价探 PriceLens
     演示模式：数据由本地模拟器生成，不请求四个电商平台。
     真实数据接入见 README.md，核心入口在 fetchLiveResults()。
     ============================================================ */

  const DEFAULT_QUERY = "无线蓝牙耳机";
  const STORAGE_KEYS = {
    recent: "price-radar:recent:v1",
    lastQuery: "price-radar:last-query:v1"
  };
  const MAX_RECENT = 5;
  const MAX_IMAGE_SIZE = 8 * 1024 * 1024;

  const runtimeConfig = window.PRICE_LENS_CONFIG || {};
  const APP_CONFIG = Object.assign(
    {
      dataMode: "demo",
      apiBaseUrl: "",
      requestTimeout: 15000
    },
    runtimeConfig
  );

  const PLATFORMS = {
    jd: {
      key: "jd",
      name: "京东",
      short: "京",
      cta: "去京东看看",
      brand: "#df2f28",
      soft: "#fdecea",
      factor: 1.06,
      shop: "京东自营",
      badge: "自营正品",
      delivery: "次日达",
      shipping: 0,
      searchUrl: (query) => `https://search.jd.com/Search?keyword=${encodeURIComponent(query)}&enc=utf-8`
    },
    taobao: {
      key: "taobao",
      name: "淘宝",
      short: "淘",
      cta: "去淘宝看看",
      brand: "#f25c1d",
      soft: "#fff0e7",
      factor: 0.98,
      shop: "品牌官方旗舰店",
      badge: "官方立减",
      delivery: "48小时内发货",
      shipping: 0,
      searchUrl: (query) => `https://s.taobao.com/search?q=${encodeURIComponent(query)}`
    },
    pdd: {
      key: "pdd",
      name: "拼多多",
      short: "拼",
      cta: "去拼多多看看",
      brand: "#d9364a",
      soft: "#fdecef",
      factor: 0.88,
      shop: "品牌官方店",
      badge: "百亿补贴",
      delivery: "极速退款",
      shipping: 0,
      searchUrl: (query) => `https://mobile.yangkeduo.com/search_result.html?search_key=${encodeURIComponent(query)}`
    },
    douyin: {
      key: "douyin",
      name: "抖音商城",
      short: "抖",
      cta: "去抖音商城看看",
      brand: "#1c252c",
      soft: "#eceff0",
      factor: 0.94,
      shop: "品牌旗舰店",
      badge: "商城正品",
      delivery: "48小时发货",
      shipping: 0,
      searchUrl: (query) => `https://haohuo.jinritemai.com/views/search/index?search_key=${encodeURIComponent(query)}`
    }
  };

  const PLATFORM_KEYS = Object.keys(PLATFORMS);

  const PRODUCT_CATALOG = [
    {
      category: "earbuds",
      keywords: ["耳机", "耳麦", "airpods", "earbuds", "蓝牙耳机", "降噪"],
      displayTitle: "主动降噪真无线耳机",
      variant: "星云黑 · 蓝牙5.3 · 30小时续航",
      basePrice: 799,
      exampleQuery: "无线蓝牙耳机"
    },
    {
      category: "tissue",
      keywords: ["抽纸", "纸巾", "卷纸", "卫生纸"],
      displayTitle: "3层100抽家庭装",
      variant: "原生木浆 · 24包整箱",
      basePrice: 54.9,
      exampleQuery: "抽纸"
    },
    {
      category: "coffee",
      keywords: ["咖啡", "咖啡液", "浓缩液"],
      displayTitle: "浓缩咖啡液组合装",
      variant: "25g×30条 · 中深烘焙 · 0糖",
      basePrice: 109,
      exampleQuery: "咖啡液"
    },
    {
      category: "keyboard",
      keywords: ["键盘", "机械键盘", "keychron"],
      displayTitle: "87键热插拔机械键盘",
      variant: "蓝牙双模 · 热插拔轴座 · 复古灰",
      basePrice: 699,
      exampleQuery: "机械键盘"
    },
    {
      category: "shoes",
      keywords: ["运动鞋", "跑鞋", "球鞋", "鞋"],
      displayTitle: "轻量缓震运动鞋",
      variant: "透气网面 · 日常通勤 · 云灰",
      basePrice: 399,
      exampleQuery: "运动鞋"
    },
    {
      category: "bottle",
      keywords: ["保温杯", "水杯", "杯子", "杯"],
      displayTitle: "316不锈钢保温杯",
      variant: "500ml · 24小时保温 · 雾银",
      basePrice: 129,
      exampleQuery: "保温杯"
    },
    {
      category: "phone",
      keywords: ["手机", "iphone", "华为", "小米", "荣耀", "oppo", "vivo"],
      displayTitle: "5G 旗舰智能手机",
      variant: "256GB · 影像旗舰 · 钛金属边框",
      basePrice: 3999,
      exampleQuery: "智能手机"
    },
    {
      category: "shampoo",
      keywords: ["洗发", "洗发水", "护发"],
      displayTitle: "控油蓬松洗发水",
      variant: "500ml · 无硅油 · 清爽型",
      basePrice: 79,
      exampleQuery: "洗发水"
    },
    {
      category: "snack",
      keywords: ["坚果", "零食", "饼干", "薯片"],
      displayTitle: "每日坚果混合装",
      variant: "750g · 30小包 · 独立包装",
      basePrice: 89,
      exampleQuery: "每日坚果"
    }
  ];

  /* 商品线稿：无外部图片依赖，离线也能完整显示。 */
  const ART = {
    earbuds: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="98" rx="28" ry="5" fill="currentColor" stroke="none" opacity=".09"></ellipse>
          <path d="M38 32c-7 1-11 8-10 16 1 12 8 20 16 19 8-1 11-10 8-20-2-7-7-12-14-15Z"></path>
          <path d="M82 32c7 1 11 8 10 16-1 12-8 20-16 19-8-1-11-10-8-20 2-7 7-12 14-15Z"></path>
          <path d="M45 67v15M75 67v15"></path>
          <rect x="37" y="80" width="46" height="18" rx="8"></rect>
          <path d="M53 80v18M67 80v18" opacity=".45"></path>
        </g>
      </svg>`,
    tissue: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="101" rx="30" ry="4" fill="currentColor" stroke="none" opacity=".09"></ellipse>
          <rect x="27" y="52" width="66" height="45" rx="5"></rect>
          <path d="M27 64h66" opacity=".55"></path>
          <path d="M44 52c0-9 7-15 16-15 9 0 16 6 16 15"></path>
          <path d="M48 52V38c0-7 5-12 12-12s12 5 12 12v14"></path>
          <path d="M52 38c0-5 3-8 8-8s8 3 8 8" opacity=".4"></path>
          <path d="M39 82h18M39 89h29" opacity=".5"></path>
        </g>
      </svg>`,
    coffee: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="103" rx="25" ry="4" fill="currentColor" stroke="none" opacity=".09"></ellipse>
          <path d="M48 19h24l-3 18H51l-3-18Z"></path>
          <path d="M47 37h26l7 58H40l7-58Z"></path>
          <path d="M44 57h32" opacity=".55"></path>
          <circle cx="60" cy="78" r="9"></circle>
          <path d="M56 72c2-3 6-3 8 0M56 84c2 3 6 3 8 0" opacity=".55"></path>
          <path d="M52 19V9h16v10" opacity=".45"></path>
        </g>
      </svg>`,
    keyboard: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="96" rx="38" ry="5" fill="currentColor" stroke="none" opacity=".08"></ellipse>
          <rect x="17" y="38" width="86" height="47" rx="7"></rect>
          <path d="M28 52h8M43 52h8M58 52h8M73 52h8M88 52h5M28 65h8M43 65h8M58 65h8M73 65h8M88 65h5M37 78h46" opacity=".8"></path>
        </g>
      </svg>`,
    shoes: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="59" cy="98" rx="39" ry="4" fill="currentColor" stroke="none" opacity=".08"></ellipse>
          <path d="M20 78c2-9 9-17 16-27l13 8c8 5 16 9 27 11l21 4c7 1 10 6 8 12-2 5-7 8-15 8H33c-10 0-15-7-13-16Z"></path>
          <path d="M36 51l8 14M49 45l8 15"></path>
          <path d="M22 86h77" opacity=".45"></path>
        </g>
      </svg>`,
    bottle: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="104" rx="22" ry="4" fill="currentColor" stroke="none" opacity=".09"></ellipse>
          <path d="M47 23h26v13l6 9v49c0 5-4 8-9 8H50c-5 0-9-3-9-8V45l6-9V23Z"></path>
          <path d="M44 57h32M44 87h32" opacity=".5"></path>
          <rect x="53" y="15" width="14" height="9" rx="3"></rect>
          <path d="M52 68h16" opacity=".45"></path>
        </g>
      </svg>`,
    phone: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="108" rx="22" ry="4" fill="currentColor" stroke="none" opacity=".08"></ellipse>
          <rect x="37" y="13" width="46" height="95" rx="9"></rect>
          <path d="M51 21h18" opacity=".55"></path>
          <rect x="46" y="34" width="28" height="43" rx="3" opacity=".45"></rect>
          <circle cx="60" cy="94" r="2.5" fill="currentColor" stroke="none"></circle>
          <circle cx="43" cy="17" r="1.5" fill="currentColor" stroke="none" opacity=".5"></circle>
        </g>
      </svg>`,
    generic: `
      <svg viewBox="0 0 120 120" aria-hidden="true">
        <g fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">
          <ellipse cx="60" cy="104" rx="28" ry="4" fill="currentColor" stroke="none" opacity=".08"></ellipse>
          <path d="M32 42h56l6 58H26l6-58Z"></path>
          <path d="M45 49V36a15 15 0 0 1 30 0v13"></path>
          <path d="M49 67c5 4 17 4 22 0M53 81h14" opacity=".55"></path>
        </g>
      </svg>`
  };

  const state = {
    query: "",
    result: null,
    mode: "text",
    chartMode: "bars",
    searching: false,
    searchToken: 0,
    imageToken: 0,
    imageDataUrl: null,
    imagePreviewQuery: "",
    recent: [],
    progressTimer: null,
    toastTimer: null,
    toastHideTimer: null,
    resizeFrame: null,
    fallbackNotified: false
  };

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const byId = (id) => document.getElementById(id);

  const els = {
    searchConsole: byId("searchConsole"),
    textTab: byId("textTab"),
    imageTab: byId("imageTab"),
    textPane: byId("textPane"),
    imagePane: byId("imagePane"),
    searchForm: byId("searchForm"),
    searchInput: byId("searchInput"),
    clearQuery: byId("clearQuery"),
    searchBtn: byId("searchBtn"),
    searchBtnText: byId("searchBtnText"),
    searchError: byId("searchError"),
    consoleStatus: byId("consoleStatus"),
    consoleStatusText: byId("consoleStatusText"),
    popularChips: byId("popularChips"),
    recentRow: byId("recentRow"),
    recentChips: byId("recentChips"),
    dropzone: byId("dropzone"),
    imageInput: byId("imageInput"),
    imagePreview: byId("imagePreview"),
    previewVisual: byId("previewVisual"),
    previewKicker: byId("previewKicker"),
    recognizedText: byId("recognizedText"),
    recognitionHint: byId("recognitionHint"),
    replaceImage: byId("replaceImage"),
    imageToText: byId("imageToText"),
    imageError: byId("imageError"),
    sourcePills: Array.from(document.querySelectorAll(".source-pill")),
    searchProgress: byId("searchProgress"),
    searchProgressBar: byId("searchProgress")?.querySelector("span"),
    searchHint: byId("searchHint"),
    searchHintText: byId("searchHintText"),
    results: byId("results"),
    productArt: byId("productArt"),
    sourceCount: byId("sourceCount"),
    productName: byId("productName"),
    productVariant: byId("productVariant"),
    matchCount: byId("matchCount"),
    updatedAt: byId("updatedAt"),
    resultDemoBtn: byId("resultDemoBtn"),
    copyBtn: byId("copyBtn"),
    againBtn: byId("againBtn"),
    winnerCard: byId("winnerCard"),
    winnerPlatform: byId("winnerPlatform"),
    winnerPrice: byId("winnerPrice"),
    winnerNote: byId("winnerNote"),
    winnerSavings: byId("winnerSavings"),
    winnerPercent: byId("winnerPercent"),
    statHighest: byId("statHighest"),
    statHighestNote: byId("statHighestNote"),
    statAverage: byId("statAverage"),
    statPlatforms: byId("statPlatforms"),
    statMatched: byId("statMatched"),
    statBelowAverage: byId("statBelowAverage"),
    platformGrid: byId("platformGrid"),
    adviceTitle: byId("adviceTitle"),
    adviceText: byId("adviceText"),
    trendTitle: byId("trendTitle"),
    trendText: byId("trendText"),
    chartPanel: byId("chartPanel"),
    chartTabs: Array.from(document.querySelectorAll("[data-chart]")),
    barsPanel: byId("barsPanel"),
    trendPanel: byId("trendPanel"),
    barsChart: byId("barsChart"),
    trendCanvas: byId("trendCanvas"),
    trendLowest: byId("trendLowest"),
    trendNote: byId("trendNote"),
    trendSummary: byId("trendSummary"),
    demoPill: byId("demoPill"),
    demoPillText: byId("demoPillText"),
    demoMini: byId("demoMini"),
    dataDialog: byId("dataDialog"),
    dataDialogTitle: byId("dataDialogTitle"),
    dataDialogIntro: byId("dataDialogIntro"),
    dataOpeners: [byId("demoPill"), byId("dataBtn"), byId("resultDemoBtn"), byId("techDataBtn")].filter(Boolean),
    toast: byId("toast"),
    toastText: byId("toastText")
  };

  const moneyFormatter = new Intl.NumberFormat("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const integerFormatter = new Intl.NumberFormat("zh-CN", {
    maximumFractionDigits: 0
  });

  /* ============================================================
     基础工具
     ============================================================ */

  function sleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (character) => {
      const entities = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
      return entities[character];
    });
  }

  function hashString(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function mulberry32(seed) {
    let value = seed >>> 0;
    return function random() {
      value = (value + 0x6d2b79f5) >>> 0;
      let result = value;
      result = Math.imul(result ^ (result >>> 15), result | 1);
      result ^= result + Math.imul(result ^ (result >>> 7), result | 61);
      return ((result ^ (result >>> 14)) >>> 0) / 4294967296;
    };
  }

  function roundMoney(value) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
  }

  function roundPrice(value) {
    if (!Number.isFinite(value) || value <= 0) return 9.9;
    return Math.max(9.9, Math.round(value) - 0.1);
  }

  function money(value) {
    return `¥${moneyFormatter.format(Math.max(0, value))}`;
  }

  function moneyNumber(value) {
    return moneyFormatter.format(Math.max(0, value));
  }

  function moneyShort(value) {
    return `¥${integerFormatter.format(Math.max(0, value))}`;
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function formatSales(value) {
    if (value >= 10000) {
      return `${(value / 10000).toFixed(1).replace(/\.0$/, "")}万+`;
    }
    return `${integerFormatter.format(value)}+`;
  }

  function safeHttpUrl(rawUrl, fallback) {
    try {
      const url = new URL(String(rawUrl), window.location.href);
      if (url.protocol === "http:" || url.protocol === "https:") return url.href;
    } catch {
      // Fall through to the platform search URL.
    }
    return fallback;
  }

  function artSvg(category) {
    return ART[category] || ART.generic;
  }

  function todayLabel() {
    try {
      return new Intl.DateTimeFormat("zh-CN", {
        timeZone: "Asia/Shanghai",
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23"
      }).format(new Date());
    } catch {
      const now = new Date();
      return `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    }
  }

  function setText(element, value) {
    if (element) element.textContent = value;
  }

  function readStorage(key, fallback = "") {
    try {
      return window.localStorage.getItem(key) ?? fallback;
    } catch {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch {
      // localStorage is optional for the demo.
    }
  }

  /* ============================================================
     数据生成与真实接口适配
     ============================================================ */

  function genericBasePrice(query) {
    const hash = hashString(query || "商品");
    return 39 + (hash % 760) + 0.9;
  }

  function resolveProduct(query) {
    const cleanQuery = String(query || "").trim().slice(0, 40);
    const lowerQuery = cleanQuery.toLowerCase();
    const isAccessory = /(手机壳|手机膜|耳机套|耳机壳|保护套|数据线|充电器|支架|贴膜|杯套)/.test(cleanQuery);
    const catalogItem = isAccessory
      ? null
      : PRODUCT_CATALOG.find((item) => item.keywords.some((keyword) => lowerQuery.includes(keyword)));

    return {
      name: cleanQuery,
      displayTitle: catalogItem ? catalogItem.displayTitle : "同款热销商品",
      variant: catalogItem ? catalogItem.variant : "官方旗舰店 · 多规格可选",
      category: catalogItem ? catalogItem.category : "generic",
      basePrice: catalogItem ? catalogItem.basePrice : genericBasePrice(cleanQuery)
    };
  }

  function generateDemoOffers(product, query) {
    const random = mulberry32(hashString(`${query}|offers|v1`));
    const usedPrices = new Set();

    return PLATFORM_KEYS.map((key) => {
      const platform = PLATFORMS[key];
      const noise = 0.96 + random() * 0.08;
      let price = roundPrice(product.basePrice * platform.factor * noise);
      while (usedPrices.has(price)) price = roundPrice(price + 1);
      usedPrices.add(price);

      const originalPrice = roundPrice(Math.max(price + 12, price * (1.12 + random() * 0.2)));
      const discount = Math.max(1, Math.round(originalPrice - price));
      const shipping = platform.shipping;
      const total = roundMoney(price + shipping);

      return {
        platform: key,
        name: platform.name,
        short: platform.short,
        brand: platform.brand,
        soft: platform.soft,
        price: roundMoney(price),
        total,
        originalPrice,
        shipping,
        coupon: `已减 ${moneyShort(discount)}`,
        badge: platform.badge,
        shop: platform.shop,
        delivery: platform.delivery,
        match: 95 + Math.floor(random() * 5),
        sales: formatSales(1200 + Math.floor(random() * 82000)),
        found: 3 + Math.floor(random() * 20),
        url: platform.searchUrl(query),
        cta: platform.cta
      };
    });
  }

  function buildTrend(query, currentPrice) {
    const random = mulberry32(hashString(`${query}|trend|v1`));
    const labels = [];
    const values = [];
    const today = new Date();

    for (let offset = 6; offset >= 0; offset -= 1) {
      const date = new Date(today);
      date.setDate(today.getDate() - offset);
      labels.push(`${date.getMonth() + 1}/${date.getDate()}`);
    }

    for (let index = 0; index < 6; index += 1) {
      values.push(roundPrice(currentPrice * (1 + (random() - 0.52) * 0.09)));
    }
    values.push(currentPrice);

    // 让部分商品的“历史低点”低于今天，方便演示价格观察。
    if (random() > 0.43) {
      values[3] = roundPrice(Math.min(values[3], currentPrice * 0.97));
    }

    const min = Math.min(...values);
    const minIndex = values.indexOf(min);
    const currentGap = Math.max(0, roundMoney(currentPrice - min));
    return {
      labels,
      values,
      min,
      minIndex,
      current: currentPrice,
      currentGap,
      currentIsLow: currentGap < 0.01
    };
  }

  function buildResult(product, offers, query, options = {}) {
    const sorted = [...offers].sort((left, right) => left.total - right.total);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    const average = offers.reduce((sum, offer) => sum + offer.total, 0) / offers.length;
    const totalFound = offers.reduce((sum, offer) => sum + (Number(offer.found) || 1), 0);
    const trend = options.trend || buildTrend(query, min.total);

    return {
      query,
      product,
      offers,
      min,
      max,
      average: roundMoney(average),
      savings: roundMoney(max.total - min.total),
      totalFound,
      trend,
      source: options.source || "demo",
      fromImage: Boolean(options.fromImage),
      imageDataUrl: options.imageDataUrl || null
    };
  }

  function createDemoResult(query, options = {}) {
    const product = resolveProduct(query);
    const offers = generateDemoOffers(product, query);
    return buildResult(product, offers, query, {
      ...options,
      source: "demo"
    });
  }

  async function fetchLiveResults(query, options = {}) {
    if (!APP_CONFIG.apiBaseUrl) {
      throw new Error("未配置真实数据 API 地址");
    }

    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), APP_CONFIG.requestTimeout);

    try {
      const response = await fetch(`${APP_CONFIG.apiBaseUrl.replace(/\/$/, "")}/search`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query,
          image: options.imageDataUrl || null
        }),
        signal: controller.signal
      });

      if (!response.ok) {
        throw new Error(`真实接口返回 ${response.status}`);
      }

      return normalizeApiResult(await response.json(), query, options);
    } finally {
      window.clearTimeout(timeout);
    }
  }

  /*
   * 真实接口统一返回格式（README 中有完整示例）：
   * {
   *   product: { name, displayTitle, variant, category },
   *   offers: [{ platform:"jd", price, shipping, originalPrice, coupon,
   *              shop, badge, delivery, match, sales, found, url }],
   *   trend: [{ date:"10/22", price: 819.9 }]
   * }
   */
  function normalizeApiResult(payload, query, options = {}) {
    if (!payload || !Array.isArray(payload.offers) || payload.offers.length === 0) {
      throw new Error("真实接口返回格式不正确");
    }

    const baseProduct = resolveProduct(query);
    const productPayload = payload.product && typeof payload.product === "object" ? payload.product : {};
    const validCategories = new Set(Object.keys(ART));
    const product = {
      ...baseProduct,
      name: String(productPayload.name || query).slice(0, 60),
      displayTitle: String(productPayload.displayTitle || baseProduct.displayTitle).slice(0, 80),
      variant: String(productPayload.variant || baseProduct.variant).slice(0, 120),
      category: validCategories.has(productPayload.category) ? productPayload.category : baseProduct.category
    };

    const offers = PLATFORM_KEYS.map((key) => {
      const item = payload.offers.find((offer) => offer && offer.platform === key);
      if (!item) return null;

      const price = Number(item.price);
      if (!Number.isFinite(price) || price <= 0) return null;

      const platform = PLATFORMS[key];
      const shipping = Number.isFinite(Number(item.shipping)) ? Math.max(0, Number(item.shipping)) : 0;
      const originalPrice = Number.isFinite(Number(item.originalPrice)) && Number(item.originalPrice) > price
        ? Number(item.originalPrice)
        : price;

      return {
        platform: key,
        name: platform.name,
        short: platform.short,
        brand: platform.brand,
        soft: platform.soft,
        price: roundMoney(price),
        total: roundMoney(price + shipping),
        originalPrice: roundMoney(originalPrice),
        shipping,
        coupon: String(item.coupon || "平台优惠").slice(0, 40),
        badge: String(item.badge || platform.badge).slice(0, 20),
        shop: String(item.shop || platform.shop).slice(0, 40),
        delivery: String(item.delivery || platform.delivery).slice(0, 30),
        match: clamp(Math.round(Number(item.match) || 96), 0, 100),
        sales: String(item.sales || "—").slice(0, 24),
        found: Math.max(1, Math.round(Number(item.found) || 1)),
        url: safeHttpUrl(item.url, platform.searchUrl(query)),
        cta: platform.cta
      };
    }).filter(Boolean);

    if (offers.length === 0) {
      throw new Error("真实接口没有返回有效的平台报价");
    }

    let trend = null;
    if (Array.isArray(payload.trend) && payload.trend.length >= 2) {
      const values = payload.trend
        .map((point) => Number(point && point.price))
        .filter((value) => Number.isFinite(value) && value > 0);
      if (values.length === payload.trend.length && values.length >= 2) {
        const labels = payload.trend.map((point, index) => String(point.date || `${index + 1}`).slice(0, 10));
        const min = Math.min(...values);
        const minIndex = values.indexOf(min);
        const current = values[values.length - 1];
        const currentGap = Math.max(0, roundMoney(current - min));
        trend = {
          labels,
          values,
          min,
          minIndex,
          current,
          currentGap,
          currentIsLow: currentGap < 0.01
        };
      }
    }

    return buildResult(product, offers, query, {
      ...options,
      source: "api",
      trend
    });
  }

  /* ============================================================
     搜索界面状态
     ============================================================ */

  function switchSearchMode(mode, { focus = false } = {}) {
    if (mode !== "text" && mode !== "image") return;
    state.mode = mode;

    [els.textTab, els.imageTab].forEach((tab) => {
      const active = tab.dataset.mode === mode;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
      tab.tabIndex = active ? 0 : -1;
    });

    els.textPane.hidden = mode !== "text";
    els.imagePane.hidden = mode !== "image";
    clearSearchError();
    clearImageError();

    if (focus) {
      if (mode === "text") {
        els.searchInput.focus();
      } else if (els.imagePreview.hidden) {
        els.dropzone.focus();
      }
    }
  }

  function updateClearButton() {
    els.clearQuery.hidden = els.searchInput.value.length === 0;
  }

  function showSearchError(message) {
    setText(els.searchError, message);
    els.searchConsole.classList.add("has-error");
    els.searchInput.setAttribute("aria-invalid", "true");
    els.searchHint.classList.add("is-error");
    setText(els.searchHintText, "请输入商品名称，或切换到「拍照搜同款」上传图片");
    els.consoleStatus.classList.remove("is-searching");
    setText(els.consoleStatusText, "等待输入");
  }

  function clearSearchError() {
    const hadError = els.searchHint.classList.contains("is-error");
    setText(els.searchError, "");
    els.searchConsole.classList.remove("has-error");
    els.searchInput.removeAttribute("aria-invalid");
    els.searchHint.classList.remove("is-error");

    if (hadError && !state.searching) {
      setText(els.searchHintText, "演示模式：输入商品名或上传图片，自动生成四个平台的比价结果");
    }
  }

  function showImageError(message) {
    setText(els.imageError, message);
    els.imagePane.classList.add("has-error");
  }

  function clearImageError() {
    setText(els.imageError, "");
    els.imagePane.classList.remove("has-error");
  }

  function setProgress(value) {
    if (els.searchProgressBar) els.searchProgressBar.style.width = `${clamp(value, 0, 100)}%`;
  }

  function setSourceState(key, status) {
    const pill = els.sourcePills.find((item) => item.dataset.source === key);
    if (!pill) return;
    pill.classList.remove("is-searching", "is-done");
    if (status) pill.classList.add(`is-${status}`);
  }

  function resetSources() {
    els.sourcePills.forEach((pill) => pill.classList.remove("is-searching", "is-done"));
  }

  function beginSearchUI() {
    window.clearTimeout(state.progressTimer);
    state.searching = true;
    els.searchBtn.disabled = true;
    els.searchBtn.classList.add("is-loading");
    els.searchInput.readOnly = true;
    setText(els.searchBtnText, "搜索中");
    els.consoleStatus.classList.add("is-searching");
    setText(els.consoleStatusText, "搜索中");
    els.searchHint.classList.remove("is-error");
    setText(els.searchHintText, "正在匹配四个平台的同款商品…");
    els.results.setAttribute("aria-busy", "true");
    els.searchProgress.classList.add("is-active");
    setProgress(6);
    resetSources();
  }

  function endSearchUI(result) {
    state.searching = false;
    els.searchBtn.disabled = false;
    els.searchBtn.classList.remove("is-loading");
    els.searchInput.readOnly = false;
    setText(els.searchBtnText, "重新比价");
    els.consoleStatus.classList.remove("is-searching");
    setText(els.consoleStatusText, "已更新");
    els.searchHint.classList.remove("is-error");
    setText(
      els.searchHintText,
      result.source === "api"
        ? `已聚合 ${result.offers.length} 个平台 · 共 ${result.totalFound} 个同款`
        : `演示搜索完成 · ${result.offers.length} 个平台 · ${result.totalFound} 个同款`
    );
    els.results.setAttribute("aria-busy", "false");
    setProgress(100);

    window.clearTimeout(state.progressTimer);
    state.progressTimer = window.setTimeout(() => {
      if (!state.searching) {
        els.searchProgress.classList.remove("is-active");
        setProgress(0);
      }
    }, 450);
  }

  /* ============================================================
     搜索流程
     ============================================================ */

  async function runSearch(rawQuery, options = {}) {
    const query = String(rawQuery || "").trim().slice(0, 40);
    if (!query) {
      switchSearchMode("text");
      showSearchError("请先输入商品名称");
      els.searchInput.focus();
      return;
    }

    const token = ++state.searchToken;
    const fromImage = Boolean(options.fromImage);
    if (!fromImage) state.imageToken += 1;
    state.query = query;
    state.imageDataUrl = fromImage ? options.imageDataUrl || null : null;
    state.imagePreviewQuery = fromImage ? query : "";
    els.searchInput.value = query;
    updateClearButton();
    clearSearchError();
    clearImageError();

    if (fromImage) {
      switchSearchMode("image");
    } else if (state.mode === "image") {
      switchSearchMode("text");
    }

    beginSearchUI();

    const delayScale = reducedMotion ? 0.3 : 1;
    const sourceTimings = { jd: 230, taobao: 190, pdd: 170, douyin: 220 };
    let completed = 0;

    for (const key of PLATFORM_KEYS) {
      if (token !== state.searchToken) return;
      setSourceState(key, "searching");
      setText(els.searchHintText, `正在搜索「${PLATFORMS[key].name}」的同款商品…`);
      await sleep(sourceTimings[key] * delayScale);
      if (token !== state.searchToken) return;
      setSourceState(key, "done");
      completed += 1;
      setProgress(10 + completed * 20);
    }

    let result;
    try {
      if (APP_CONFIG.dataMode === "api" && APP_CONFIG.apiBaseUrl) {
        result = await fetchLiveResults(query, {
          fromImage,
          imageDataUrl: fromImage ? options.imageDataUrl || null : null
        });
      } else {
        result = createDemoResult(query, {
          fromImage,
          imageDataUrl: fromImage ? options.imageDataUrl || null : null
        });
      }
    } catch (error) {
      if (token !== state.searchToken) return;
      console.warn("[PriceLens] 真实接口请求失败，回退到演示数据：", error);
      if (!state.fallbackNotified) {
        state.fallbackNotified = true;
        showToast("真实接口暂不可用，已切换为演示数据");
      }
      result = createDemoResult(query, {
        fromImage,
        imageDataUrl: fromImage ? options.imageDataUrl || null : null
      });
    }

    if (token !== state.searchToken) return;

    state.result = result;
    renderResult(result);
    endSearchUI(result);
    if (!options.initial) addRecent(query);
    writeStorage(STORAGE_KEYS.lastQuery, query);

    if (!options.initial) {
      updateUrl(query);
      scrollToResults();
    }
  }

  function scrollToResults() {
    if (!els.results || els.results.hidden) return;
    window.setTimeout(() => {
      els.results.scrollIntoView({
        behavior: reducedMotion ? "auto" : "smooth",
        block: "start"
      });
    }, 120);
  }

  function updateUrl(query) {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("q", query);
      window.history.replaceState({}, "", url);
    } catch {
      // file:// 或旧浏览器可能不允许修改 URL，忽略即可。
    }
  }

  /* ============================================================
     渲染
     ============================================================ */

  function renderProductArt(result) {
    els.productArt.className = "product-art";
    els.productArt.replaceChildren();

    if (result.fromImage && result.imageDataUrl) {
      const image = document.createElement("img");
      image.src = result.imageDataUrl;
      image.alt = "上传的商品图片";
      els.productArt.append(image);
      return;
    }

    els.productArt.classList.add(`art-${result.product.category}`);
    els.productArt.innerHTML = artSvg(result.product.category);
  }

  function renderResult(result) {
    const { product, offers, min, max, average, totalFound, trend } = result;

    renderProductArt(result);

    setText(els.sourceCount, `${offers.length} 个平台`);
    setText(els.productName, product.name);
    setText(els.productVariant, `${product.displayTitle} · ${product.variant}`);
    setText(els.matchCount, String(totalFound));
    setText(els.updatedAt, todayLabel());

    const isLive = result.source === "api";
    setText(els.resultDemoBtn, isLive ? "实时数据" : "演示数据");
    setText(els.demoPillText, isLive ? "实时接口" : "演示数据");
    setText(els.demoMini, isLive ? "LIVE" : "DEMO");
    els.demoPill.classList.toggle("is-live", isLive);
    els.demoMini.classList.toggle("is-live", isLive);

    setText(els.winnerPlatform, min.name);
    setText(els.winnerPrice, moneyNumber(min.total));
    setText(els.winnerNote, `${min.badge} · ${min.shop} · ${min.shipping > 0 ? `运费 ${money(min.shipping)}` : "包邮"} · ${min.delivery}`);
    setText(els.winnerSavings, money(result.savings));
    setText(els.winnerPercent, `约 ${max.total > 0 ? Math.round((result.savings / max.total) * 100) : 0}%`);

    setText(els.statHighest, money(max.total));
    setText(els.statHighestNote, `${max.name} · ${max.shop}`);
    setText(els.statAverage, money(average));
    setText(els.statPlatforms, String(offers.length));
    setText(els.statMatched, String(totalFound));
    setText(els.statBelowAverage, `${average > 0 ? (((average - min.total) / average) * 100).toFixed(1) : "0.0"}%`);

    const second = [...offers].sort((left, right) => left.total - right.total)[1];
    const jdOffer = offers.find((offer) => offer.platform === "jd");
    const adviceParts = [
      `${min.name} 券后 ${money(min.total)}，匹配度 ${min.match}%，${min.shipping > 0 ? `含运费 ${money(min.shipping)}` : "包邮"}。`
    ];
    if (second) {
      adviceParts.push(`${second.name} 次之，比最低价高 ${money(second.total - min.total)}。`);
    }
    if (jdOffer) {
      adviceParts.push(
        jdOffer.platform === min.platform
          ? "京东自营同时也是当前最低价，适合看重配送和售后的用户。"
          : `如果更看重自营售后，京东自营报价 ${money(jdOffer.total)}，比最低价高 ${money(jdOffer.total - min.total)}。`
      );
    }
    setText(els.adviceTitle, `${min.name} 目前最低，最多省 ${money(result.savings)}`);
    setText(els.adviceText, adviceParts.join(" "));

    const trendGap = Math.max(0, roundMoney(trend.current - trend.min));
    if (trendGap < 0.01) {
      setText(els.trendTitle, "现在就是近 7 日低点");
      setText(els.trendText, `近 7 日最低价为 ${money(trend.min)}，当前 ${min.name} 的价格与低点持平，是相对合适的入手窗口。`);
      setText(els.trendNote, "当前为 7 日低点");
    } else {
      setText(els.trendTitle, `比近 7 日低点高 ${money(trendGap)}`);
      setText(els.trendText, `近 7 日最低价出现在 ${trend.labels[trend.minIndex]}（${money(trend.min)}），当前最低价为 ${money(trend.current)}。`);
      setText(els.trendNote, `比低点高 ${money(trendGap)}`);
    }

    setText(els.trendLowest, money(trend.min));
    setText(
      els.trendSummary,
      `近 7 日最低价 ${money(trend.min)}，出现在 ${trend.labels[trend.minIndex]}；当前最低价 ${money(trend.current)}。`
    );

    if (result.fromImage) {
      setText(els.recognitionHint, `演示识别完成 · 已生成 ${offers.length} 个平台的比价结果`);
    }

    renderPlatformCards(result);
    renderBars(result);
    renderChartPanels();
    els.results.hidden = false;
    document.title = `${result.query} 比价 · 价探 PriceLens`;
  }

  function renderPlatformCards(result) {
    const minPlatform = result.min.platform;

    els.platformGrid.innerHTML = result.offers.map((offer) => {
      const isLowest = offer.platform === minPlatform;
      const priceLabel = moneyNumber(offer.total);
      const originalLabel = offer.originalPrice > offer.total ? `<del>${money(offer.originalPrice)}</del>` : "";
      const shippingLabel = offer.shipping > 0 ? `运费 ${money(offer.shipping)}` : "包邮";
      const tags = [
        `<span class="pc-tag">${escapeHTML(offer.badge)}</span>`,
        `<span class="pc-tag is-neutral">${escapeHTML(offer.coupon)}</span>`
      ].join("");

      return `
        <article class="platform-card${isLowest ? " is-lowest" : ""}" data-platform="${escapeHTML(offer.platform)}" data-total="${offer.total}" style="--brand:${offer.brand};--brand-soft:${offer.soft}">
          <div class="pc-head">
            <span class="pc-logo" aria-hidden="true">${escapeHTML(offer.short)}</span>
            <span class="pc-name">${escapeHTML(offer.name)}</span>
            ${isLowest ? '<span class="pc-lowest"><svg class="icon" aria-hidden="true"><use href="#i-check"></use></svg>最低</span>' : ""}
            <span class="pc-match">匹配 ${offer.match}%</span>
          </div>
          <div class="pc-price">
            <span class="currency">¥</span><strong>${priceLabel}</strong>${originalLabel}
          </div>
          <div class="pc-tags">${tags}</div>
          <p class="pc-shop">${escapeHTML(offer.shop)} · 已售 ${escapeHTML(offer.sales)}</p>
          <p class="pc-sales">同款 ${offer.found} 个 · 匹配度 ${offer.match}%</p>
          <div class="pc-meta">
            <span>${shippingLabel}</span>
            <span>${escapeHTML(offer.delivery)}</span>
          </div>
          <a class="pc-link" href="${escapeHTML(offer.url)}" target="_blank" rel="noopener noreferrer" title="打开平台搜索页；演示价格并非实时成交价">
            ${escapeHTML(offer.cta)}
            <svg class="icon" aria-hidden="true"><use href="#i-external"></use></svg>
          </a>
        </article>
      `;
    }).join("");
  }

  function renderBars(result) {
    const sorted = [...result.offers].sort((left, right) => left.total - right.total);
    const maximum = Math.max(...sorted.map((offer) => offer.total), 1);
    const lowestPlatform = result.min.platform;

    els.barsChart.innerHTML = sorted.map((offer) => {
      const width = Math.max(6, (offer.total / maximum) * 100);
      const isLowest = offer.platform === lowestPlatform;
      return `
        <div class="bar-row${isLowest ? " is-lowest" : ""}" data-platform="${escapeHTML(offer.platform)}" style="--brand:${offer.brand}">
          <div class="bar-label">
            <i aria-hidden="true"></i>
            <span>${escapeHTML(offer.name)}</span>
            ${isLowest ? "<em>最低</em>" : ""}
          </div>
          <div class="bar-track" aria-hidden="true"><span class="bar-fill" style="width:${width.toFixed(2)}%"></span></div>
          <div class="bar-value">${money(offer.total)}</div>
        </div>
      `;
    }).join("");

    els.barsChart.setAttribute("role", "img");
    els.barsChart.setAttribute(
      "aria-label",
      `四个平台到手价对比：${sorted.map((offer) => `${offer.name}${money(offer.total)}`).join("，")}`
    );
  }

  function renderChartPanels() {
    const isTrend = state.chartMode === "trend";
    els.barsPanel.hidden = isTrend;
    els.trendPanel.hidden = !isTrend;
    els.chartTabs.forEach((button) => {
      const active = button.dataset.chart === state.chartMode;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", String(active));
    });

    if (isTrend) {
      window.requestAnimationFrame(drawTrend);
    }
  }

  function setChartMode(mode) {
    if (mode !== "bars" && mode !== "trend") return;
    state.chartMode = mode;
    renderChartPanels();
  }

  /* ============================================================
     趋势图 Canvas
     ============================================================ */

  function drawTrend() {
    const result = state.result;
    const canvas = els.trendCanvas;
    if (!result || !canvas || els.trendPanel.hidden) return;

    const rect = canvas.getBoundingClientRect();
    if (rect.width < 40 || rect.height < 40) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    const context = canvas.getContext("2d");
    if (!context) return;
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, rect.width, rect.height);

    const prices = result.trend.values;
    const labels = result.trend.labels;
    const width = rect.width;
    const height = rect.height;
    const padding = {
      left: width < 480 ? 42 : 52,
      right: 14,
      top: 22,
      bottom: 27
    };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;
    const rawMin = Math.min(...prices);
    const rawMax = Math.max(...prices);
    const range = Math.max(rawMax - rawMin, rawMax * 0.02, 1);
    const yMin = rawMin - range * 0.18;
    const yMax = rawMax + range * 0.18;
    const xFor = (index) => padding.left + (chartWidth * index) / (prices.length - 1);
    const yFor = (value) => padding.top + ((yMax - value) / (yMax - yMin)) * chartHeight;

    context.font = '9px "PingFang SC", "Microsoft YaHei", sans-serif';
    context.textBaseline = "middle";

    for (let tick = 0; tick < 4; tick += 1) {
      const ratio = tick / 3;
      const y = padding.top + chartHeight * ratio;
      const value = yMax - (yMax - yMin) * ratio;
      context.beginPath();
      context.strokeStyle = "#e9e4d8";
      context.lineWidth = 1;
      context.setLineDash([3, 4]);
      context.moveTo(padding.left, y);
      context.lineTo(width - padding.right, y);
      context.stroke();
      context.setLineDash([]);
      context.fillStyle = "#97a098";
      context.textAlign = "left";
      context.fillText(`¥${integerFormatter.format(Math.round(value))}`, 2, y);
    }

    context.beginPath();
    context.moveTo(xFor(0), yFor(prices[0]));
    for (let index = 1; index < prices.length; index += 1) {
      context.lineTo(xFor(index), yFor(prices[index]));
    }
    context.lineTo(xFor(prices.length - 1), height - padding.bottom);
    context.lineTo(xFor(0), height - padding.bottom);
    context.closePath();
    const gradient = context.createLinearGradient(0, padding.top, 0, height - padding.bottom);
    gradient.addColorStop(0, "rgba(15, 93, 66, 0.18)");
    gradient.addColorStop(1, "rgba(15, 93, 66, 0)");
    context.fillStyle = gradient;
    context.fill();

    context.beginPath();
    context.moveTo(xFor(0), yFor(prices[0]));
    for (let index = 1; index < prices.length; index += 1) {
      context.lineTo(xFor(index), yFor(prices[index]));
    }
    context.strokeStyle = "#0f5d42";
    context.lineWidth = 2.4;
    context.lineJoin = "round";
    context.lineCap = "round";
    context.stroke();

    const lowestIndex = prices.indexOf(Math.min(...prices));
    prices.forEach((price, index) => {
      const x = xFor(index);
      const y = yFor(price);
      const isLast = index === prices.length - 1;
      const isLowest = index === lowestIndex;

      context.beginPath();
      context.arc(x, y, isLowest || isLast ? 4 : 2.8, 0, Math.PI * 2);
      context.fillStyle = "#fffefa";
      context.fill();
      context.strokeStyle = isLowest ? "#0f5d42" : "#6f8d7d";
      context.lineWidth = isLowest || isLast ? 2.2 : 1.4;
      context.stroke();
    });

    context.fillStyle = "#0f5d42";
    context.font = '9px "PingFang SC", "Microsoft YaHei", sans-serif';
    context.textAlign = "right";
    context.fillText("当前", width - padding.right, yFor(prices[prices.length - 1]) - 12);

    const labelIndexes = [0, 3, prices.length - 1];
    labelIndexes.forEach((index, position) => {
      context.fillStyle = "#8c968e";
      context.textAlign = position === 0 ? "left" : position === labelIndexes.length - 1 ? "right" : "center";
      context.fillText(labels[index], xFor(index), height - 9);
    });
  }

  function scheduleTrendDraw() {
    if (state.chartMode !== "trend") return;
    window.cancelAnimationFrame(state.resizeFrame);
    state.resizeFrame = window.requestAnimationFrame(drawTrend);
  }

  /* ============================================================
     搜索结果辅助信息
     ============================================================ */

  function addRecent(query) {
    const clean = String(query || "").trim();
    if (!clean) return;
    state.recent = [clean, ...state.recent.filter((item) => item !== clean)].slice(0, MAX_RECENT);
    writeStorage(STORAGE_KEYS.recent, JSON.stringify(state.recent));
    renderRecent();
  }

  function loadRecent() {
    try {
      const raw = readStorage(STORAGE_KEYS.recent, "[]");
      const parsed = JSON.parse(raw);
      state.recent = Array.isArray(parsed)
        ? parsed.filter((item) => typeof item === "string" && item.trim()).slice(0, MAX_RECENT)
        : [];
    } catch {
      state.recent = [];
    }
    renderRecent();
  }

  function renderRecent() {
    els.recentRow.hidden = state.recent.length === 0;
    els.recentChips.innerHTML = state.recent
      .map((query) => `<button type="button" data-query="${escapeHTML(query)}">${escapeHTML(query)}</button>`)
      .join("");
  }

  async function copyResult() {
    if (!state.result) return;
    const result = state.result;
    const lines = [
      "价探 PriceLens · 四平台比价",
      `商品：${result.product.name}`,
      ...result.offers
        .slice()
        .sort((left, right) => left.total - right.total)
        .map((offer) => `${offer.name} ${money(offer.total)}${offer.platform === result.min.platform ? "（最低）" : ""}`),
      `共匹配 ${result.totalFound} 个同款 · ${result.source === "demo" ? "演示数据，非实时价格" : "实时接口数据"}`
    ];

    try {
      await copyText(lines.join("\n"));
      showToast("比价结果已复制");
    } catch {
      showToast("复制失败，请手动选择页面文字");
    }
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return;
    }

    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.append(textarea);
    textarea.select();
    const copied = document.execCommand("copy");
    textarea.remove();
    if (!copied) throw new Error("copy failed");
  }

  function showToast(message) {
    window.clearTimeout(state.toastTimer);
    window.clearTimeout(state.toastHideTimer);
    setText(els.toastText, message);
    els.toast.hidden = false;
    window.requestAnimationFrame(() => els.toast.classList.add("is-visible"));
    state.toastTimer = window.setTimeout(() => {
      els.toast.classList.remove("is-visible");
      state.toastHideTimer = window.setTimeout(() => {
        els.toast.hidden = true;
      }, 220);
    }, 2800);
  }

  /* ============================================================
     图片上传与演示识别
     ============================================================ */

  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(new Error("图片读取失败"));
      reader.readAsDataURL(file);
    });
  }

  function recognizeFromFile(file) {
    const name = String(file.name || "").toLowerCase();
    const match = PRODUCT_CATALOG.find((item) => item.keywords.some((keyword) => name.includes(keyword)));
    if (match) {
      return {
        query: match.exampleQuery,
        category: match.category,
        reason: `演示识别：从图片文件名匹配到「${match.exampleQuery}」`
      };
    }

    const demoPool = ["earbuds", "tissue", "coffee"];
    const pickedCategory = demoPool[hashString(`${file.name}|${file.size}`) % demoPool.length];
    const picked = PRODUCT_CATALOG.find((item) => item.category === pickedCategory) || PRODUCT_CATALOG[0];
    return {
      query: picked.exampleQuery,
      category: picked.category,
      reason: "演示识别：根据图片特征匹配到该类目"
    };
  }

  function showImagePreview({ dataUrl = null, category = "generic" } = {}) {
    els.previewVisual.replaceChildren();

    if (dataUrl) {
      const image = document.createElement("img");
      image.src = dataUrl;
      image.alt = "上传的商品图片";
      els.previewVisual.append(image);
    } else {
      const art = document.createElement("div");
      art.className = `product-art art-${category}`;
      art.innerHTML = artSvg(category);
      els.previewVisual.append(art);
    }

    els.dropzone.hidden = true;
    els.imagePreview.hidden = false;
    els.imagePreview.classList.remove("is-scanning");
    els.imagePreview.classList.add("is-scanning");
    setText(els.previewKicker, "正在识别（演示）");
    setText(els.recognizedText, "正在识别商品…");
    setText(els.recognitionHint, "正在提取商品特征，随后自动搜索四个平台");
    clearImageError();
  }

  function finishImageRecognition(recognized) {
    els.imagePreview.classList.remove("is-scanning");
    setText(els.previewKicker, "图片识别（演示）");
    setText(els.recognizedText, `识别为：${recognized.query}`);
    setText(els.recognitionHint, `${recognized.reason} · 正在比价`);
    state.imagePreviewQuery = recognized.query;
    els.searchInput.value = recognized.query;
    updateClearButton();
  }

  async function handleImageFile(file) {
    if (!file) return;
    clearImageError();

    if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) {
      showImageError("请上传 JPG、PNG 或 WEBP 图片");
      return;
    }

    if (file.size > MAX_IMAGE_SIZE) {
      showImageError("图片不能超过 8MB，请压缩后再试");
      return;
    }

    const token = ++state.imageToken;

    try {
      const dataUrl = await readFileAsDataUrl(file);
      if (token !== state.imageToken) return;

      state.imageDataUrl = dataUrl;
      showImagePreview({ dataUrl });
      await sleep(reducedMotion ? 280 : 760);
      if (token !== state.imageToken) return;

      const recognized = recognizeFromFile(file);
      finishImageRecognition(recognized);
      await sleep(reducedMotion ? 120 : 300);
      if (token !== state.imageToken) return;

      await runSearch(recognized.query, {
        fromImage: true,
        imageDataUrl: dataUrl,
        userInitiated: true
      });
    } catch {
      showImageError("图片读取失败，请换一张图片再试");
    }
  }

  async function useSampleImage(category) {
    const sample = PRODUCT_CATALOG.find((item) => item.category === category) || PRODUCT_CATALOG[0];
    const token = ++state.imageToken;
    state.imageDataUrl = null;

    showImagePreview({ category: sample.category });
    await sleep(reducedMotion ? 200 : 560);
    if (token !== state.imageToken) return;

    const recognized = {
      query: sample.exampleQuery,
      category: sample.category,
      reason: "示例图演示识别"
    };
    finishImageRecognition(recognized);
    await sleep(reducedMotion ? 100 : 260);
    if (token !== state.imageToken) return;

    await runSearch(sample.exampleQuery, {
      fromImage: true,
      imageDataUrl: null,
      userInitiated: true
    });
  }

  function resetImageState() {
    state.imageDataUrl = null;
    state.imagePreviewQuery = "";
    els.imagePreview.hidden = true;
    els.dropzone.hidden = false;
    els.imagePreview.classList.remove("is-scanning");
    els.previewVisual.replaceChildren();
    clearImageError();
  }

  function openDataDialog() {
    if (!els.dataDialog) return;
    const isLive = state.result?.source === "api";
    setText(els.dataDialogTitle, isLive ? "当前数据来自真实接口" : "这是演示数据，不是实时价格");
    setText(
      els.dataDialogIntro,
      isLive
        ? "当前页面已经通过你配置的后端接口获取数据。不同平台的权限、返回字段和更新频率可能不同，实际价格仍以平台结算页为准。"
        : "为了让课程演示在没有平台账号和 API 密钥的情况下也能完整运行，当前价格、优惠、销量和趋势由本地模拟器根据商品名称生成。页面不会请求四个平台，也不会上传你选择的图片。"
    );

    if (typeof els.dataDialog.showModal === "function") {
      if (!els.dataDialog.open) els.dataDialog.showModal();
    } else {
      els.dataDialog.setAttribute("open", "");
    }
  }

  function closeDataDialog() {
    if (!els.dataDialog) return;
    if (typeof els.dataDialog.close === "function" && els.dataDialog.open) {
      els.dataDialog.close();
    } else {
      els.dataDialog.removeAttribute("open");
    }
  }

  /* ============================================================
     事件绑定与初始化
     ============================================================ */

  function bindEvents() {
    els.searchForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const query = els.searchInput.value.trim();
      if (!query) {
        switchSearchMode("text");
        showSearchError("请先输入商品名称");
        els.searchInput.focus();
        return;
      }
      runSearch(query, { userInitiated: true });
    });

    els.searchInput.addEventListener("input", () => {
      updateClearButton();
      clearSearchError();
    });

    els.clearQuery.addEventListener("click", () => {
      els.searchInput.value = "";
      updateClearButton();
      clearSearchError();
      els.searchInput.focus();
    });

    [els.textTab, els.imageTab].forEach((tab) => {
      tab.addEventListener("click", () => switchSearchMode(tab.dataset.mode, { focus: true }));
      tab.addEventListener("keydown", (event) => {
        if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
        event.preventDefault();
        const nextMode = tab.dataset.mode === "text" ? "image" : "text";
        switchSearchMode(nextMode, { focus: true });
      });
    });

    const handleChipClick = (event) => {
      const button = event.target.closest("[data-query]");
      if (!button) return;
      const query = button.dataset.query;
      els.searchInput.value = query;
      updateClearButton();
      switchSearchMode("text");
      runSearch(query, { userInitiated: true });
    };

    els.popularChips.addEventListener("click", handleChipClick);
    els.recentChips.addEventListener("click", handleChipClick);

    els.chartTabs.forEach((button) => {
      button.addEventListener("click", () => setChartMode(button.dataset.chart));
    });

    els.dropzone.addEventListener("click", () => els.imageInput.click());
    els.dropzone.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        els.imageInput.click();
      }
    });

    ["dragenter", "dragover"].forEach((eventName) => {
      els.dropzone.addEventListener(eventName, (event) => {
        event.preventDefault();
        els.dropzone.classList.add("is-dragging");
      });
    });

    ["dragleave", "dragend"].forEach((eventName) => {
      els.dropzone.addEventListener(eventName, () => els.dropzone.classList.remove("is-dragging"));
    });

    els.dropzone.addEventListener("drop", (event) => {
      event.preventDefault();
      els.dropzone.classList.remove("is-dragging");
      const file = event.dataTransfer?.files?.[0];
      if (file) handleImageFile(file);
    });

    els.imageInput.addEventListener("change", () => {
      const file = els.imageInput.files?.[0];
      els.imageInput.value = "";
      if (file) handleImageFile(file);
    });

    els.replaceImage.addEventListener("click", () => els.imageInput.click());

    els.imageToText.addEventListener("click", () => {
      const query = state.imagePreviewQuery || els.searchInput.value;
      switchSearchMode("text", { focus: true });
      if (query) {
        els.searchInput.value = query;
        updateClearButton();
        els.searchInput.select();
      }
    });

    document.querySelectorAll("[data-sample]").forEach((button) => {
      button.addEventListener("click", () => useSampleImage(button.dataset.sample));
    });

    els.againBtn.addEventListener("click", () => {
      switchSearchMode("text", { focus: true });
      els.searchConsole.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "center" });
      window.setTimeout(() => els.searchInput.select(), reducedMotion ? 0 : 300);
    });

    els.copyBtn.addEventListener("click", copyResult);

    els.dataOpeners.forEach((button) => {
      button.addEventListener("click", openDataDialog);
    });

    document.querySelectorAll("[data-close-dialog]").forEach((button) => {
      button.addEventListener("click", closeDataDialog);
    });

    if (els.dataDialog) {
      els.dataDialog.addEventListener("click", (event) => {
        const rect = els.dataDialog.getBoundingClientRect();
        const clickedBackdrop =
          event.clientX < rect.left ||
          event.clientX > rect.right ||
          event.clientY < rect.top ||
          event.clientY > rect.bottom;
        if (clickedBackdrop) closeDataDialog();
      });
    }

    window.addEventListener("resize", () => {
      if (state.chartMode === "trend") scheduleTrendDraw();
    });
  }

  function initSampleArt() {
    document.querySelectorAll(".sample-art").forEach((element) => {
      const artClass = Array.from(element.classList).find((className) => className.startsWith("art-"));
      const category = artClass ? artClass.slice(4) : "generic";
      element.innerHTML = artSvg(category);
    });
  }

  function init() {
    initSampleArt();
    loadRecent();
    bindEvents();

    const urlQuery = new URLSearchParams(window.location.search).get("q");
    const lastQuery = readStorage(STORAGE_KEYS.lastQuery, "");
    const initialQuery = String(urlQuery || lastQuery || DEFAULT_QUERY).trim().slice(0, 40) || DEFAULT_QUERY;

    els.searchInput.value = initialQuery;
    updateClearButton();
    switchSearchMode("text");
    runSearch(initialQuery, { initial: true });
  }

  init();
})();
