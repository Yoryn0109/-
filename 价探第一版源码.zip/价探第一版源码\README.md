# 价探 · Windows 桌面采集工作台

价探的 Windows 桌面版源码：京东、淘宝、拼多多三个面板并排，手动登录、搜索、选择规格，然后点「采集当前页」保存价格。

不需要浏览器扩展、不需要本机后端；打包后的程序自带运行环境，最终用户不需要安装 Node.js。

## 源码结构

```text
价探第一版源码/
├── package.json         项目信息、启动与打包脚本、Electron 依赖
├── main.js              Electron 主进程：窗口、IPC、记录读写
├── preload.js           预加载脚本：把受控的桌面能力暴露给页面
├── app/
│   ├── index.html       界面结构：三平台面板、采集弹窗、采集记录
│   ├── styles.css       界面样式（米白纸张 + 墨绿主色）
│   └── app.js           渲染进程逻辑：搜索、页面提取、记录渲染
├── 使用说明.txt          给最终用户的简版说明（随便携版分发）
└── README.md
```

进程分工：

- **主进程（`main.js`）**：创建 1500×940 的窗口，加载 `app/index.html`；负责读写 `records.json`；把外链交给系统浏览器。
- **渲染进程（`app/app.js`）**：管理三个 `<webview>` 面板；点「采集当前页」时通过 `executeJavaScript` 注入 `extractPage()`，只读取当前页可见信息，填进确认弹窗；用户确认后经 IPC 落盘。
- **桥接（`preload.js`）**：`contextIsolation: true`、`nodeIntegration: false`，页面只能调用白名单里的四个方法。

## 开发运行

需要 Node.js 18+（建议 20/22 LTS），包管理器用 pnpm 或 npm 均可：

```bash
pnpm install
pnpm start
```

或：

```bash
npm install
npm start
```

首次安装会下载对应平台的 Electron 运行时（约 100 MB）。

## 打包 Windows 便携版

```bash
pnpm run pack:win
```

产物在 `dist/价探-win32-x64/`，双击其中的 `价探.exe` 即可运行，整个文件夹可以直接压缩分发。打包脚本等价于：

```bash
npx electron-packager . 价探 --platform=win32 --arch=x64 --out=dist --overwrite --app-version=1.0.0
```

未做代码签名，Windows 可能提示「已保护你的电脑」，点「更多信息」→「仍要运行」。

## 功能与实现要点

### 三平台同屏

三个 `<webview>` 分别使用独立的持久化分区，登录状态互不干扰、下次启动仍在：

| 平台 | 搜索地址 | 分区 |
| --- | --- | --- |
| 京东 | `search.jd.com/Search?keyword=…` | `persist:pricelens-jd` |
| 淘宝 | `s.taobao.com/search?q=…` | `persist:pricelens-taobao` |
| 拼多多 | `mobile.yangkeduo.com/search_result.html?search_key=…` | `persist:pricelens-pdd` |

所有 webview 统一使用普通桌面 Chrome 的 User-Agent，顶栏会显示当前页面域名；面板标题栏提供「刷新」和「采集当前页」。

### 采集当前页

`app.js` 里的 `extractPage()` 在目标页面上下文执行，按优先级汇总价格：

1. `application/ld+json` 结构化数据里的 `offers.price` / `lowPrice`（优先级 0–1）
2. `product:price:amount`、`og:price:amount` 等 meta（优先级 0）
3. 平台常见价格选择器，如京东 `.summary-price .price`、淘宝 `.tm-price`、拼多多 `.price`（优先级 2）
4. 页面可见文本中 `¥/￥` 开头的金额，最多 8 个兜底（优先级 3）

结果按「优先级 → 价格」排序取第一个，同时抓取标题、店铺、原价和已选规格（容量/颜色按正则识别），全部填进弹窗由用户核对、修改，**不会自动保存**。

### 采集记录

- 记录按时间倒序展示，统计记录数、商品数、全局最低价；
- 同一商品名下的最低价会打上「低」标记；
- 每条记录可「打开」原链接（交给系统浏览器）或「删除」；支持一键清空；
- 渲染全部用 `createElement` + `textContent`，不拼接 HTML，避免注入。

### 数据存储

主进程把记录写到：

```text
%APPDATA%\价探\records.json
```

写入采用「先写 `.tmp` 再 `rename`」的原子替换，避免中途失败损坏文件；最多保留 5000 条。程序里的「数据位置」按钮会弹出完整路径。记录格式：

```json
{
  "id": "uuid",
  "platform": "jd",
  "product": "Apple iPhone 17 Pro Max 256GB",
  "price": 9999,
  "originalPrice": null,
  "variants": [{ "name": "容量", "value": "256GB" }],
  "shop": "Apple 产品京东自营旗舰店",
  "note": "页面价，未叠加账号券",
  "url": "https://item.jd.com/…",
  "capturedAt": "2026-10-30T02:10:00.000Z",
  "source": "desktop-capture"
}
```

### 安全边界

- `contextIsolation: true` + `nodeIntegration: false`，页面拿不到 Node API；
- preload 只暴露 `loadRecords` / `saveRecords` / `openExternal` / `dataPath` 四个调用；
- 主进程只接受 `http(s)` 外链，并交给系统浏览器打开；窗口内不允许 `window.open` 新开窗口；
- 不读取浏览器 Cookie，不注入第三方脚本，不上传任何数据（本机 JSON 是唯一存储）。

## 不做什么

- 不自动登录；
- 不自动搜索、翻页、切换 SKU；
- 不自动关闭页面；
- 不批量抓取；
- 不读取浏览器 Cookie；
- 不上传第三方。

采集只在你点击时读取当前面板可见的标题、价格、店铺和已选规格；提取不准时可以在弹窗里手动修正。

## 限制

- 页面价格不等于最终结算价；账号券、地区、直播间、满减会影响最终价格。
- 平台可能要求登录、验证码或风控验证，请在面板内手动完成。
- 平台改版后，自动提取字段可能需要手动补充。
- 只采集你有权查看的商品信息，并遵守平台规则。

## 版本

- 源码版本：1.0.0
- 原始便携版运行时：Electron 45.1.0（Windows x64）
- 开发依赖：`electron ^45.1.0`、`@electron/packager ^20.3.0`
